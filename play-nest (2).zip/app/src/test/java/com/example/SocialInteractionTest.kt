package com.example

import com.example.data.model.Comment
import com.example.data.model.User
import com.example.data.model.Video
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SocialInteractionTest {

    @Test
    fun testVideoLikeToggling() {
        val initialVideo = Video(
            id = "vid_101",
            creatorId = "creator_1",
            creatorUsername = "dancepro",
            creatorDisplayName = "Dance Pro",
            creatorAvatarUrl = "",
            videoUrl = "https://example.com/video.mp4",
            caption = "Amazing moves!",
            likesCount = 100L,
            isLiked = false
        )

        // Like video
        val likedVideo = initialVideo.copy(
            isLiked = true,
            likesCount = initialVideo.likesCount + 1
        )
        assertTrue(likedVideo.isLiked)
        assertEquals(101L, likedVideo.likesCount)

        // Unlike video
        val unlikedVideo = likedVideo.copy(
            isLiked = false,
            likesCount = (likedVideo.likesCount - 1).coerceAtLeast(0)
        )
        assertFalse(unlikedVideo.isLiked)
        assertEquals(100L, unlikedVideo.likesCount)
    }

    @Test
    fun testFollowCreatorToggling() {
        val creator = User(
            id = "creator_1",
            username = "elena_v",
            displayName = "Elena Vance",
            avatarUrl = "",
            followersCount = 50,
            isFollowing = false
        )

        // Follow
        val followingState = creator.copy(
            isFollowing = true,
            followersCount = creator.followersCount + 1
        )
        assertTrue(followingState.isFollowing)
        assertEquals(51, followingState.followersCount)

        // Unfollow
        val unfollowedState = followingState.copy(
            isFollowing = false,
            followersCount = (followingState.followersCount - 1).coerceAtLeast(0)
        )
        assertFalse(unfollowedState.isFollowing)
        assertEquals(50, unfollowedState.followersCount)
    }

    @Test
    fun testCommentOwnerCanDelete() {
        val currentUserId = "user_me"
        val otherUserId = "user_other"

        val myComment = Comment(
            id = "c_1",
            videoId = "vid_101",
            userId = currentUserId,
            username = "alex_rivers",
            userAvatarUrl = "",
            text = "Awesome performance!"
        )

        val otherComment = Comment(
            id = "c_2",
            videoId = "vid_101",
            userId = otherUserId,
            username = "stranger",
            userAvatarUrl = "",
            text = "Nice video"
        )

        val canDeleteMine = myComment.userId == currentUserId
        val canDeleteOther = otherComment.userId == currentUserId

        assertTrue("User must be allowed to delete their own comment", canDeleteMine)
        assertFalse("User must NOT be allowed to delete other user's comment", canDeleteOther)
    }

    @Test
    fun testFirestoreKeyFormats() {
        val videoId = "vid_test_1"
        val userId = "user_abc_123"
        val creatorId = "creator_xyz_789"

        val likeDocId = "${videoId}_${userId}"
        val followDocId = "${userId}_${creatorId}"

        assertEquals("vid_test_1_user_abc_123", likeDocId)
        assertEquals("user_abc_123_creator_xyz_789", followDocId)
    }
}
