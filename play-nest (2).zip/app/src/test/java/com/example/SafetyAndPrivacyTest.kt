package com.example

import com.example.data.model.BlockedUserRecord
import com.example.data.model.ContentReport
import com.example.data.model.PrivacyAudience
import com.example.data.model.ReportContentType
import com.example.data.model.ReportReason
import com.example.data.model.UserPrivacySettings
import com.example.data.model.Video
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SafetyAndPrivacyTest {

    @Test
    fun testContentReportingForVariousTypes() {
        val videoReport = ContentReport(
            reporterUserId = "user_me",
            targetId = "video_999",
            reportedUserId = "bad_actor",
            contentType = ReportContentType.VIDEO,
            reason = ReportReason.SPAM.displayName,
            details = "Commercial bot spam",
            status = "PENDING"
        )
        assertEquals("user_me", videoReport.reporterUserId)
        assertEquals(ReportContentType.VIDEO, videoReport.contentType)
        assertEquals("PENDING", videoReport.status)

        val commentReport = ContentReport(
            reporterUserId = "user_me",
            targetId = "comment_42",
            reportedUserId = "toxic_user",
            contentType = ReportContentType.COMMENT,
            reason = ReportReason.HARASSMENT.displayName,
            details = "Abusive comment"
        )
        assertEquals(ReportContentType.COMMENT, commentReport.contentType)
        assertEquals("Harassment or bullying", commentReport.reason)

        val userReport = ContentReport(
            reporterUserId = "user_me",
            targetId = "impersonator_id",
            reportedUserId = "impersonator_id",
            contentType = ReportContentType.USER,
            reason = ReportReason.SCAM.displayName
        )
        assertEquals(ReportContentType.USER, userReport.contentType)

        val msgReport = ContentReport(
            reporterUserId = "user_me",
            targetId = "msg_123",
            reportedUserId = "spammer_dm",
            contentType = ReportContentType.MESSAGE,
            reason = ReportReason.HATE_SPEECH.displayName
        )
        assertEquals(ReportContentType.MESSAGE, msgReport.contentType)
    }

    @Test
    fun testBlockedUserHidesVideosFromFeed() {
        val videos = listOf(
            Video(id = "v1", creatorId = "creator_good", creatorUsername = "creator_good", creatorDisplayName = "Good Creator", creatorAvatarUrl = "", videoUrl = "", caption = "Nice day"),
            Video(id = "v2", creatorId = "creator_blocked", creatorUsername = "creator_blocked", creatorDisplayName = "Blocked Creator", creatorAvatarUrl = "", videoUrl = "", caption = "Spam"),
            Video(id = "v3", creatorId = "creator_another", creatorUsername = "creator_another", creatorDisplayName = "Another Creator", creatorAvatarUrl = "", videoUrl = "", caption = "Cooking")
        )

        val blockedUsers = listOf(
            BlockedUserRecord(
                blockerUserId = "user_me",
                blockedUserId = "creator_blocked",
                blockedUsername = "creator_blocked",
                blockedDisplayName = "Blocked Account"
            )
        )

        val blockedIds = blockedUsers.map { it.blockedUserId }.toSet()
        val visibleVideos = videos.filter { it.creatorId !in blockedIds && it.creatorUsername !in blockedIds }

        assertEquals(2, visibleVideos.size)
        assertTrue(visibleVideos.none { it.creatorId == "creator_blocked" })
        assertEquals("v1", visibleVideos[0].id)
        assertEquals("v3", visibleVideos[1].id)
    }

    @Test
    fun testPrivacySettingsUpdates() {
        val defaultSettings = UserPrivacySettings(
            userId = "user_me",
            isPrivateAccount = false,
            allowComments = PrivacyAudience.EVERYONE,
            allowDirectMessages = PrivacyAudience.EVERYONE,
            pushNotificationsEnabled = true
        )

        assertFalse(defaultSettings.isPrivateAccount)
        assertEquals(PrivacyAudience.EVERYONE, defaultSettings.allowComments)

        // Make account private and restrict DMs
        val updated = defaultSettings.copy(
            isPrivateAccount = true,
            allowComments = PrivacyAudience.FOLLOWERS_ONLY,
            allowDirectMessages = PrivacyAudience.NO_ONE,
            pushNotificationsEnabled = false
        )

        assertTrue(updated.isPrivateAccount)
        assertEquals(PrivacyAudience.FOLLOWERS_ONLY, updated.allowComments)
        assertEquals(PrivacyAudience.NO_ONE, updated.allowDirectMessages)
        assertFalse(updated.pushNotificationsEnabled)
    }

    @Test
    fun testUnblockingRestoresVisibility() {
        val blockedUsers = mutableListOf(
            BlockedUserRecord(
                blockerUserId = "user_me",
                blockedUserId = "user_xyz",
                blockedUsername = "xyz",
                blockedDisplayName = "XYZ"
            )
        )
        assertEquals(1, blockedUsers.size)

        // Unblock
        blockedUsers.removeAll { it.blockedUserId == "user_xyz" }
        assertEquals(0, blockedUsers.size)
    }
}
