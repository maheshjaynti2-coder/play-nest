package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.Video
import com.example.ui.viewmodel.MainTab
import com.example.ui.viewmodel.PlayNestViewModel
import com.example.util.PlayNestVideoPlayerManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class VideoPlaybackExperienceTest {

    private lateinit var context: Context
    private lateinit var testVideo: Video

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        testVideo = Video(
            id = "vid_test_101",
            creatorId = "user_test",
            creatorUsername = "testcreator",
            creatorDisplayName = "Test Creator",
            creatorAvatarUrl = "https://example.com/avatar.jpg",
            caption = "Testing Play Nest Core Playback Experience!",
            videoUrl = "https://example.com/sample.mp4",
            likesCount = 500L,
            commentsCount = 20L,
            sharesCount = 5L,
            savesCount = 12L
        )
        PlayNestVideoPlayerManager.releaseAll()
    }

    @Test
    fun testPlayPauseToggling() {
        // Toggle user play/pause
        val isNowPaused = PlayNestVideoPlayerManager.toggleUserPlayPause()
        assertTrue("First toggle should put player into user-paused state", isNowPaused)
        assertTrue(PlayNestVideoPlayerManager.isUserPaused.value)

        // Toggle again to unpause
        val isPausedSecond = PlayNestVideoPlayerManager.toggleUserPlayPause()
        assertFalse("Second toggle should unpause player", isPausedSecond)
        assertFalse(PlayNestVideoPlayerManager.isUserPaused.value)
    }

    @Test
    fun testMuteUnmuteState() {
        // Initially set mute true
        PlayNestVideoPlayerManager.setMuted(true)
        assertTrue(PlayNestVideoPlayerManager.isMuted.value)

        // Set mute false
        PlayNestVideoPlayerManager.setMuted(false)
        assertFalse(PlayNestVideoPlayerManager.isMuted.value)
    }

    @Test
    fun testFeedIndexPagingBounds() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val viewModel = PlayNestViewModel(app)

        assertEquals(0, viewModel.currentFeedIndex.value)

        // Swipe up to next video
        viewModel.updateFeedIndex(1)
        assertEquals(1, viewModel.currentFeedIndex.value)

        // Swipe to another index
        viewModel.updateFeedIndex(3)
        assertEquals(3, viewModel.currentFeedIndex.value)

        // Swipe back down
        viewModel.updateFeedIndex(2)
        assertEquals(2, viewModel.currentFeedIndex.value)
    }

    @Test
    fun testNavigationAwayFromFeedPausesPlayback() {
        // Simulate feed active
        PlayNestVideoPlayerManager.onFeedVisibilityChanged(true)

        // User navigates away to Discover or Chat
        PlayNestVideoPlayerManager.onFeedVisibilityChanged(false)
        assertFalse(PlayNestVideoPlayerManager.isPlaying.value)

        // User returns to Home feed
        PlayNestVideoPlayerManager.onFeedVisibilityChanged(true)
    }

    @Test
    fun testAppBackgroundAndForegroundLifecycle() {
        // User moves app to background
        PlayNestVideoPlayerManager.onAppBackgrounded()
        assertFalse(PlayNestVideoPlayerManager.isPlaying.value)

        // User returns app to foreground
        PlayNestVideoPlayerManager.onAppForegrounded()
    }

    @Test
    fun testEmptyOrInvalidVideoUrlHandling() {
        val emptyUrlVideo = testVideo.copy(videoUrl = "")

        // Manager should handle empty URL gracefully without crashing
        PlayNestVideoPlayerManager.playVideo(
            context = context,
            video = emptyUrlVideo,
            muted = false
        )

        assertTrue(PlayNestVideoPlayerManager.hasError.value)
        assertFalse(PlayNestVideoPlayerManager.isBuffering.value)
        assertFalse(PlayNestVideoPlayerManager.isPlaying.value)
    }

    @Test
    fun testMuteStatePersistenceAcrossViewModel() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val viewModel = PlayNestViewModel(app)

        val initialMuted = viewModel.isGlobalMuted.value
        viewModel.toggleGlobalMute()

        val toggledMuted = viewModel.isGlobalMuted.value
        assertEquals(!initialMuted, toggledMuted)

        // Verify it was stored in SharedPreferences
        val prefs = app.getSharedPreferences("playnest_playback_prefs", Context.MODE_PRIVATE)
        assertEquals(toggledMuted, prefs.getBoolean("key_global_muted", false))

        // Create a new ViewModel instance to simulate opening the app again
        val secondViewModel = PlayNestViewModel(app)
        assertEquals(toggledMuted, secondViewModel.isGlobalMuted.value)
    }
}
