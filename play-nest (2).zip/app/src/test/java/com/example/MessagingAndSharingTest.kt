package com.example

import com.example.data.model.ChatConversation
import com.example.data.model.ChatMessage
import com.example.data.model.SharedVideoPreview
import com.example.data.model.User
import com.example.data.model.VideoShareRecord
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MessagingAndSharingTest {

    @Test
    fun testSharedVideoPreviewCreation() {
        val preview = SharedVideoPreview(
            videoId = "vid_1",
            thumbnailUrl = "https://example.com/thumb.jpg",
            localThumbnailRes = 1001,
            creatorUsername = "maya_travels",
            caption = "Sunset at Bali beach! #wanderlust"
        )

        assertEquals("vid_1", preview.videoId)
        assertEquals("maya_travels", preview.creatorUsername)
        assertEquals("Sunset at Bali beach! #wanderlust", preview.caption)

        val chatMessage = ChatMessage(
            id = "msg_1",
            senderId = "user_me",
            receiverId = "user_other",
            message = "Check this clip out!",
            timestamp = "10:30 AM",
            isSentByMe = true,
            timestampMs = 1700000000000L,
            sharedVideo = preview
        )

        assertNotNull(chatMessage.sharedVideo)
        assertEquals("vid_1", chatMessage.sharedVideo?.videoId)
        assertTrue(chatMessage.isSentByMe)
    }

    @Test
    fun testVideoShareRecordTracking() {
        val shareRecord = VideoShareRecord(
            id = "share_1",
            videoId = "vid_42",
            userId = "user_123",
            shareType = "PLAYNEST_DM",
            recipientUserId = "user_456",
            timestamp = 1700000500000L
        )

        assertEquals("vid_42", shareRecord.videoId)
        assertEquals("PLAYNEST_DM", shareRecord.shareType)
        assertEquals("user_456", shareRecord.recipientUserId)
    }

    @Test
    fun testConversationsChronologicalOrder() {
        val user1 = User(id = "u1", username = "alex", displayName = "Alex", avatarUrl = "")
        val user2 = User(id = "u2", username = "sam", displayName = "Sam", avatarUrl = "")

        val conv1 = ChatConversation(
            id = "conv_1",
            otherUser = user1,
            lastMessage = "Older message",
            timeAgo = "1h ago",
            unreadCount = 0,
            lastTimestampMs = 1000L
        )

        val conv2 = ChatConversation(
            id = "conv_2",
            otherUser = user2,
            lastMessage = "Newer message",
            timeAgo = "Just now",
            unreadCount = 2,
            lastTimestampMs = 2000L
        )

        val list = listOf(conv1, conv2)
        val sortedDesc = list.sortedByDescending { it.lastTimestampMs }

        assertEquals("conv_2", sortedDesc.first().id)
        assertEquals(2, sortedDesc.first().unreadCount)
    }

    @Test
    fun testDeepLinkFormat() {
        val videoId = "vid_neon_beats"
        val deepLinkUrl = "https://playnest.app/video/$videoId"

        assertTrue(deepLinkUrl.startsWith("https://playnest.app/video/"))
        val extractedId = deepLinkUrl.substringAfter("https://playnest.app/video/")
        assertEquals("vid_neon_beats", extractedId)
    }
}
