package com.example.ui.components

import android.graphics.SurfaceTexture
import android.view.Surface
import android.view.TextureView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.example.data.model.Video
import com.example.ui.theme.PlayNestBlue
import com.example.ui.theme.PlayNestPink
import com.example.ui.theme.PlayNestPrimaryGradient
import com.example.ui.theme.PlayNestPurple
import com.example.util.PlayNestVideoPlayerManager
import kotlinx.coroutines.delay

/**
 * Premium fullscreen video player for Play Nest vertical feed items.
 *
 * Powered by [PlayNestVideoPlayerManager] to ensure:
 * - Ultra-smooth playback with single active decoder pooling.
 * - Tap to play/pause with subtle animated indicator.
 * - Mute/unmute toggle with auto-fading feedback pill.
 * - Double-tap to like with floating animated heart bursts.
 * - Graceful loading and failure fallback states with retry.
 */
@Composable
fun VideoPlayerView(
    video: Video,
    isCurrentPage: Boolean,
    isMuted: Boolean,
    onDoubleTapLike: () -> Unit,
    modifier: Modifier = Modifier,
    onToggleMute: () -> Unit = {}
) {
    val context = LocalContext.current

    // Manager state subscriptions
    val currentVideoId by PlayNestVideoPlayerManager.currentPlayingVideoId.collectAsState()
    val isBuffering by PlayNestVideoPlayerManager.isBuffering.collectAsState()
    val isUserPaused by PlayNestVideoPlayerManager.isUserPaused.collectAsState()
    val hasError by PlayNestVideoPlayerManager.hasError.collectAsState()
    val playbackProgress by PlayNestVideoPlayerManager.playbackProgress.collectAsState()

    // Local transient states
    var heartTrigger by remember { mutableLongStateOf(0L) }
    var surfaceRef by remember { mutableStateOf<Surface?>(null) }
    var showMuteNotice by remember { mutableStateOf(false) }

    val isThisVideoActive = isCurrentPage && currentVideoId == video.id

    // Double-tap like & single-tap play/pause gesture
    val tapModifier = Modifier.pointerInput(video.id) {
        detectTapGestures(
            onDoubleTap = {
                heartTrigger = System.currentTimeMillis()
                onDoubleTapLike()
            },
            onTap = {
                if (isCurrentPage) {
                    PlayNestVideoPlayerManager.toggleUserPlayPause()
                }
            }
        )
    }

    // Playback lifecycle for the active page
    LaunchedEffect(isCurrentPage, video.id) {
        if (isCurrentPage) {
            PlayNestVideoPlayerManager.playVideo(
                context = context,
                video = video,
                muted = isMuted,
                surface = surfaceRef
            )
        }
    }

    // Synchronize mute state changes
    LaunchedEffect(isMuted) {
        if (isCurrentPage) {
            PlayNestVideoPlayerManager.setMuted(isMuted)
        }
    }

    // Transient HUD notification when mute button is clicked
    LaunchedEffect(isMuted) {
        showMuteNotice = true
        delay(1400)
        showMuteNotice = false
    }

    // Clean up surface on disposal
    DisposableEffect(video.id, isCurrentPage) {
        onDispose {
            if (isCurrentPage) {
                PlayNestVideoPlayerManager.clearSurface()
                surfaceRef?.release()
                surfaceRef = null
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .then(tapModifier)
    ) {
        // 1. Poster Thumbnail (shown while buffering, between swipes, or on error)
        if (video.localThumbnailRes != null) {
            Image(
                painter = painterResource(id = video.localThumbnailRes),
                contentDescription = "Video Poster",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else if (video.thumbnailUrl.isNotBlank()) {
            AsyncImage(
                model = video.thumbnailUrl,
                contentDescription = "Video Poster",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }

        // 2. Hardware-accelerated TextureView (mounted only for active or adjacent page)
        if (isCurrentPage) {
            AndroidView(
                factory = { ctx ->
                    TextureView(ctx).apply {
                        surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                            override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                                val surf = Surface(surface)
                                surfaceRef = surf
                                PlayNestVideoPlayerManager.setSurface(surf)
                            }

                            override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}

                            override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                                PlayNestVideoPlayerManager.clearSurface()
                                surfaceRef?.release()
                                surfaceRef = null
                                return true
                            }

                            override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
                        }
                    }
                },
                update = {
                    surfaceRef?.let { surf ->
                        PlayNestVideoPlayerManager.setSurface(surf)
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        // 3. Cinematic Vignette Gradient Overlay (for text readability)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.5f),
                            Color.Transparent,
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.85f)
                        ),
                        startY = 0f,
                        endY = Float.POSITIVE_INFINITY
                    )
                )
        )

        // 4. Buffering Loading Spinner
        if (isBuffering && isCurrentPage && !hasError) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(60.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.45f)),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    color = PlayNestPink,
                    strokeWidth = 3.5.dp,
                    modifier = Modifier.size(36.dp)
                )
            }
        }

        // 5. Subtle Animated Pause Indicator
        AnimatedVisibility(
            visible = isUserPaused && isThisVideoActive && !hasError,
            enter = fadeIn() + scaleIn(spring(dampingRatio = Spring.DampingRatioMediumBouncy)),
            exit = fadeOut() + scaleOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.55f))
                    .border(1.5.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                    .shadow(12.dp, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Video Paused",
                    tint = Color.White.copy(alpha = 0.95f),
                    modifier = Modifier.size(46.dp)
                )
            }
        }

        // 6. Graceful Error & Retry State
        if (hasError && isCurrentPage) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(32.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.Black.copy(alpha = 0.75f))
                    .border(1.dp, PlayNestPink.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                    .padding(horizontal = 24.dp, vertical = 20.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.WarningAmber,
                        contentDescription = "Playback Error",
                        tint = PlayNestPink,
                        modifier = Modifier.size(36.dp)
                    )
                    Text(
                        text = "Video currently unavailable",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Button(
                        onClick = { PlayNestVideoPlayerManager.retryCurrentVideo(context) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(PlayNestPrimaryGradient)
                            .testTag("retry_video_playback_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Retry",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }

        // 7. Floating Heart Animation on Double-Tap
        FloatingHeartsLayer(
            trigger = heartTrigger,
            modifier = Modifier.fillMaxSize()
        )

        // 8. Top-Right Floating Mute/Unmute Control
        IconButton(
            onClick = onToggleMute,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .statusBarsPadding()
                .padding(top = 10.dp, end = 16.dp)
                .size(38.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.5f))
                .border(1.dp, Color.White.copy(alpha = 0.15f), CircleShape)
                .testTag("video_mute_toggle_button")
        ) {
            Icon(
                imageVector = if (isMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                contentDescription = if (isMuted) "Unmute Video" else "Mute Video",
                tint = if (isMuted) PlayNestPink else Color.White,
                modifier = Modifier.size(20.dp)
            )
        }

        // 9. Floating Sound Status Notification Pill (HUD)
        AnimatedVisibility(
            visible = showMuteNotice,
            enter = fadeIn() + scaleIn(),
            exit = fadeOut() + scaleOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(top = 16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black.copy(alpha = 0.7f))
                    .border(1.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Icon(
                    imageVector = if (isMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                    contentDescription = null,
                    tint = if (isMuted) PlayNestPink else PlayNestBlue,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = if (isMuted) "Muted" else "Sound On",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // 10. Thin Playback Progress Indicator at bottom edge
        if (isThisVideoActive) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth(playbackProgress.coerceIn(0f, 1f))
                    .height(3.dp)
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(PlayNestPink, PlayNestPurple, PlayNestBlue)
                        )
                    )
            )
        }
    }
}
