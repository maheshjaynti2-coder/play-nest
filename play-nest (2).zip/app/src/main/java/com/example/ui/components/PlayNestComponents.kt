package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.PlayNestBlue
import com.example.ui.theme.PlayNestGreen
import com.example.ui.theme.PlayNestOrange
import com.example.ui.theme.PlayNestPink
import com.example.ui.theme.PlayNestPrimaryGradient
import com.example.ui.theme.PlayNestPurple
import com.example.ui.theme.PlayNestSunsetGradient
import com.example.ui.theme.PlayNestYellow
import kotlinx.coroutines.delay
import kotlin.random.Random

import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.TextButton
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

/**
 * Top App Logo & Brand Badge
 * Displays the official Play Nest branding with original proportions and crisp quality
 */
@Composable
fun PlayNestLogoBadge(
    modifier: Modifier = Modifier,
    iconSize: Dp = 32.dp,
    showText: Boolean = true
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Image(
            painter = painterResource(id = R.drawable.playnest_symbol_icon),
            contentDescription = "PLAY NEST Logo",
            modifier = Modifier
                .size(iconSize)
                .clip(RoundedCornerShape(8.dp)),
            contentScale = ContentScale.Fit
        )

        if (showText) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "PLAY",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.2.sp
                    ),
                    color = Color.White
                )
                Text(
                    text = "NEST",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.2.sp
                    ),
                    color = Color(0xFFFF2453)
                )
            }
        }
    }
}

/**
 * Spinning Vinyl Record with floating animated musical notes
 */
@Composable
fun SpinningVinyl(
    albumArtUrl: String?,
    modifier: Modifier = Modifier,
    isPlaying: Boolean = true
) {
    val infiniteTransition = rememberInfiniteTransition(label = "vinylRotation")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val noteOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -40f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "notes"
    )

    Box(
        modifier = modifier.size(52.dp),
        contentAlignment = Alignment.Center
    ) {
        // Floating Music Note
        if (isPlaying) {
            Icon(
                imageVector = Icons.Default.MusicNote,
                contentDescription = null,
                tint = PlayNestPink,
                modifier = Modifier
                    .size(16.dp)
                    .offset(x = 12.dp, y = noteOffset.dp)
                    .scale((1f + (noteOffset / 50f)).coerceAtLeast(0.2f))
            )
        }

        // Vinyl Disc
        Box(
            modifier = Modifier
                .size(48.dp)
                .rotate(if (isPlaying) rotation else 0f)
                .clip(CircleShape)
                .background(Color(0xFF161622))
                .border(2.dp, Color(0xFF2C2D3E), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            // Inner groove lines
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .border(1.dp, Color(0x33FFFFFF), CircleShape)
            )

            // Center album art
            if (!albumArtUrl.isNullOrBlank()) {
                AsyncImage(
                    model = albumArtUrl,
                    contentDescription = null,
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(PlayNestPrimaryGradient),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        }
    }
}

/**
 * Creator Avatar with gradient follow '+' overlay button
 */
@Composable
fun CreatorAvatarWithFollow(
    avatarUrl: String,
    isFollowing: Boolean,
    onFollowClick: () -> Unit,
    onAvatarClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.size(54.dp),
        contentAlignment = Alignment.TopCenter
    ) {
        // Avatar with gradient border
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(PlayNestPrimaryGradient)
                .clickable { onAvatarClick() }
                .padding(2.dp)
        ) {
            AsyncImage(
                model = avatarUrl,
                contentDescription = "Creator Avatar",
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape),
                contentScale = ContentScale.Crop
            )
        }

        // Follow '+' badge
        if (!isFollowing) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .offset(y = 4.dp)
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(PlayNestPink)
                    .clickable { onFollowClick() }
                    .testTag("follow_creator_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Follow Creator",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

/**
 * Double Tap Heart Explosion Animation
 */
data class HeartParticle(
    val id: Long,
    val xOffset: Float,
    val yOffset: Float,
    val rotation: Float,
    val scale: Float
)

@Composable
fun FloatingHeartsLayer(
    trigger: Long,
    modifier: Modifier = Modifier
) {
    val hearts = remember { mutableStateListOf<HeartParticle>() }

    LaunchedEffect(trigger) {
        if (trigger > 0) {
            val p = HeartParticle(
                id = trigger,
                xOffset = (Random.nextFloat() - 0.5f) * 60f,
                yOffset = (Random.nextFloat() - 0.5f) * 60f,
                rotation = (Random.nextFloat() - 0.5f) * 40f,
                scale = 1.3f
            )
            hearts.add(p)
            delay(900)
            hearts.remove(p)
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        hearts.forEach { heart ->
            HeartBurst(particle = heart)
        }
    }
}

@Composable
private fun HeartBurst(particle: HeartParticle) {
    val animScale = remember { Animatable(0.2f) }
    val animAlpha = remember { Animatable(1f) }

    LaunchedEffect(particle.id) {
        animScale.animateTo(
            targetValue = particle.scale,
            animationSpec = spring(dampingRatio = 0.4f, stiffness = 400f)
        )
        animAlpha.animateTo(
            targetValue = 0f,
            animationSpec = tween(durationMillis = 400)
        )
    }

    Icon(
        imageVector = Icons.Default.Favorite,
        contentDescription = null,
        tint = PlayNestPink.copy(alpha = animAlpha.value),
        modifier = Modifier
            .offset(x = particle.xOffset.dp, y = particle.yOffset.dp)
            .rotate(particle.rotation)
            .scale(animScale.value)
            .size(90.dp)
    )
}

/**
 * Pill Follow Button with Gradient
 */
@Composable
fun GradientFollowButton(
    isFollowing: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        modifier = modifier
            .height(36.dp)
            .clip(RoundedCornerShape(18.dp))
            .testTag("toggle_follow_btn"),
        color = if (isFollowing) DarkSurfaceElevated else Color.Transparent,
        border = if (isFollowing) BorderStroke(1.dp, DarkBorder) else null
    ) {
        Box(
            modifier = Modifier
                .then(
                    if (!isFollowing) Modifier.background(PlayNestPrimaryGradient)
                    else Modifier.background(DarkSurfaceElevated)
                )
                .padding(horizontal = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (isFollowing) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = PlayNestGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Following",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Follow",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

/**
 * Play Nest Fullscreen Splash Screen with the official branding
 */
@Composable
fun PlayNestSplashScreen(
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 24.dp)
        ) {
            // Official Play Nest Brand Logo Banner
            Image(
                painter = painterResource(id = R.drawable.playnest_brand_banner),
                contentDescription = "PLAY NEST Logo",
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .clip(RoundedCornerShape(16.dp)),
                contentScale = ContentScale.Fit
            )

            Spacer(modifier = Modifier.height(28.dp))

            CircularProgressIndicator(
                color = Color(0xFFFF2453),
                modifier = Modifier.size(32.dp),
                strokeWidth = 3.dp
            )
        }
    }
}

/**
 * Play Nest Real Firebase Authentication Dialog
 * Supports Email/Password Log In, Sign Up with Username & Display Name, and Forgot Password
 */
@Composable
fun PlayNestAuthDialog(
    isLoading: Boolean,
    errorMessage: String?,
    successMessage: String?,
    onSignIn: (email: String, pass: String) -> Unit,
    onSignUp: (email: String, pass: String, username: String, displayName: String) -> Unit,
    onForgotPassword: (email: String) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    // 0 = Login, 1 = Sign Up, 2 = Forgot Password
    var authMode by remember { mutableStateOf(0) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }

    Dialog(onDismissRequest = { if (!isLoading) onDismiss() }) {
        Card(
            modifier = modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Official Play Nest Logo Header
                Image(
                    painter = painterResource(id = R.drawable.playnest_symbol_icon),
                    contentDescription = "PLAY NEST Logo",
                    modifier = Modifier
                        .size(64.dp)
                        .clip(RoundedCornerShape(14.dp)),
                    contentScale = ContentScale.Fit
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Brand Title
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "PLAY",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.2.sp
                        ),
                        color = Color.White
                    )
                    Text(
                        text = "NEST",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.2.sp
                        ),
                        color = Color(0xFFFF2453)
                    )
                }

                Text(
                    text = when (authMode) {
                        1 -> "Create your creator account"
                        2 -> "Reset your account password"
                        else -> "Sign in to like, comment & create"
                    },
                    color = TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )

                // Error / Success Banner
                if (!errorMessage.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF3B121A)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = errorMessage,
                            color = Color(0xFFFF5252),
                            fontSize = 12.sp,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                } else if (!successMessage.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF103322)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = successMessage,
                            color = PlayNestGreen,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Email Field (All modes)
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Address") },
                    singleLine = true,
                    enabled = !isLoading,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFFFF2453),
                        unfocusedBorderColor = DarkBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("auth_email_field")
                )

                // Username & Display Name (Sign Up only)
                if (authMode == 1) {
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it },
                        label = { Text("Username (@handle)") },
                        singleLine = true,
                        enabled = !isLoading,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFFF2453),
                            unfocusedBorderColor = DarkBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().testTag("auth_username_field")
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = displayName,
                        onValueChange = { displayName = it },
                        label = { Text("Display Name") },
                        singleLine = true,
                        enabled = !isLoading,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFFF2453),
                            unfocusedBorderColor = DarkBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().testTag("auth_displayname_field")
                    )
                }

                // Password Field (Sign In & Sign Up)
                if (authMode != 2) {
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password (min 6 characters)") },
                        singleLine = true,
                        enabled = !isLoading,
                        visualTransformation = PasswordVisualTransformation(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFFF2453),
                            unfocusedBorderColor = DarkBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().testTag("auth_password_field")
                    )
                }

                // Forgot Password text link (Sign In only)
                if (authMode == 0) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = { authMode = 2 },
                            enabled = !isLoading
                        ) {
                            Text(
                                text = "Forgot password?",
                                color = PlayNestPink,
                                fontSize = 12.sp
                            )
                        }
                    }
                } else {
                    Spacer(modifier = Modifier.height(16.dp))
                }

                // Submit Action Button
                Button(
                    onClick = {
                        when (authMode) {
                            1 -> onSignUp(email, password, username, displayName)
                            2 -> onForgotPassword(email)
                            else -> onSignIn(email, password)
                        }
                    },
                    enabled = !isLoading,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("auth_submit_btn"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF2453))
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.5.dp
                        )
                    } else {
                        Text(
                            text = when (authMode) {
                                1 -> "Create Account"
                                2 -> "Send Reset Link"
                                else -> "Sign In"
                            },
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Mode switcher footer
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    when (authMode) {
                        1 -> {
                            Text(
                                text = "Already have an account?",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                            TextButton(onClick = { authMode = 0 }, enabled = !isLoading) {
                                Text(
                                    text = "Log In",
                                    color = PlayNestBlue,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        2 -> {
                            TextButton(onClick = { authMode = 0 }, enabled = !isLoading) {
                                Text(
                                    text = "Back to Log In",
                                    color = PlayNestBlue,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        else -> {
                            Text(
                                text = "New to Play Nest?",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                            TextButton(onClick = { authMode = 1 }, enabled = !isLoading) {
                                Text(
                                    text = "Sign Up",
                                    color = PlayNestBlue,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
