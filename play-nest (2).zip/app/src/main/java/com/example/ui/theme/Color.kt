package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Play Nest Signature Vibrant Gradients & Palette
val PlayNestPink = Color(0xFFFF2A6D)
val PlayNestPurple = Color(0xFF9B51E0)
val PlayNestOrange = Color(0xFFFF7A00)
val PlayNestBlue = Color(0xFF00E5FF)
val PlayNestCyan = PlayNestBlue
val PlayNestYellow = Color(0xFFFFD124)
val PlayNestGreen = Color(0xFF00F59B)

// Luxury Dark Backgrounds
val DarkBackground = Color(0xFF0B0C11)
val DarkSurface = Color(0xFF13151F)
val DarkSurfaceElevated = Color(0xFF1B1E2D)
val DarkSurfaceCard = Color(0xFF222638)
val DarkBorder = Color(0x33FFFFFF)
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFA0A5BD)
val TextMuted = Color(0xFF6B728E)

// Gradient Brushes
val PlayNestPrimaryGradient = Brush.horizontalGradient(
    colors = listOf(PlayNestPink, PlayNestPurple, PlayNestBlue)
)

val PlayNestSunsetGradient = Brush.horizontalGradient(
    colors = listOf(PlayNestOrange, PlayNestPink, PlayNestPurple)
)

val PlayNestNeonGradient = Brush.linearGradient(
    colors = listOf(PlayNestGreen, PlayNestYellow, PlayNestBlue)
)

val PlayNestAccentGradient = Brush.sweepGradient(
    colors = listOf(PlayNestPink, PlayNestOrange, PlayNestYellow, PlayNestGreen, PlayNestBlue, PlayNestPurple, PlayNestPink)
)

val GlassCardGradient = Brush.verticalGradient(
    colors = listOf(Color(0x33282C40), Color(0x1A141624))
)
