package com.example.ui

import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Video
import com.example.ui.components.CommentsBottomSheet
import com.example.ui.components.CreatorProfileSheet
import com.example.ui.components.EditProfileDialog
import com.example.ui.components.PlayNestAuthDialog
import com.example.ui.components.PlayNestSplashScreen
import com.example.ui.components.ReportBottomSheet
import com.example.ui.components.SettingsDialog
import com.example.ui.components.ShareBottomSheet
import com.example.ui.components.SoundPickerSheet
import com.example.ui.screens.ChatDetailScreen
import com.example.ui.screens.CreateScreen
import com.example.ui.screens.DiscoverScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.InboxScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.PlayNestBlue
import com.example.ui.theme.PlayNestGreen
import com.example.ui.theme.PlayNestPink
import com.example.ui.theme.PlayNestPrimaryGradient
import com.example.ui.theme.PlayNestPurple
import com.example.ui.theme.PlayNestYellow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainTab
import com.example.ui.viewmodel.PlayNestViewModel

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun PlayNestApp(
    viewModel: PlayNestViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentTab by viewModel.currentTab.collectAsState()
    val videos: List<Video> by viewModel.videos.collectAsState()
    val creators by viewModel.creators.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val currentFeedIndex by viewModel.currentFeedIndex.collectAsState()
    val isGlobalMuted by viewModel.isGlobalMuted.collectAsState()

    val searchQuery by viewModel.searchQuery.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()
    val searchHistory by viewModel.searchHistory.collectAsState()
    val isSearching by viewModel.isSearching.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val trendingHashtags by viewModel.trendingHashtags.collectAsState()

    val inboxTab by viewModel.inboxTab.collectAsState()
    val conversations by viewModel.conversations.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val unreadNotificationCount = notifications.count { !it.isRead }
    val activeConversation by viewModel.activeConversation.collectAsState()
    val chatMessages by viewModel.activeChatMessages.collectAsState()

    val profileTab by viewModel.profileTab.collectAsState()

    val activeCommentsVideo by viewModel.activeCommentsVideo.collectAsState()
    val videoComments by viewModel.videoComments.collectAsState()
    val shareModalVideo by viewModel.shareModalVideo.collectAsState()
    val reportModalVideo by viewModel.reportModalVideo.collectAsState()

    val isSoundPickerOpen by viewModel.isSoundPickerOpen.collectAsState()
    val soundTracks = viewModel.soundTracks
    val selectedSound by viewModel.selectedSound.collectAsState()
    val uploadState by viewModel.uploadState.collectAsState()

    val isEditProfileOpen by viewModel.isEditProfileOpen.collectAsState()
    val isSettingsOpen by viewModel.isSettingsOpen.collectAsState()
    val showAuthDialog by viewModel.showAuthDialog.collectAsState()
    val authLoading by viewModel.authLoading.collectAsState()
    val authError by viewModel.authError.collectAsState()
    val authSuccessMessage by viewModel.authSuccessMessage.collectAsState()
    val isAuthenticated by viewModel.isAuthenticated.collectAsState()
    val activeCreatorProfile by viewModel.activeCreatorProfile.collectAsState()

    val activeReportTarget by viewModel.activeReportTarget.collectAsState()
    val blockedUsers by viewModel.blockedUsers.collectAsState()
    val userReports by viewModel.userReports.collectAsState()
    val privacySettings by viewModel.privacySettings.collectAsState()

    var isSplashVisible by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(1200)
        isSplashVisible = false
    }

    if (isSplashVisible) {
        PlayNestSplashScreen()
        return
    }

    // Fullscreen Direct Message Chat View if active
    if (activeConversation != null) {
        ChatDetailScreen(
            conversation = activeConversation!!,
            messages = chatMessages,
            onBack = { viewModel.closeChat() },
            onSendMessage = { text -> viewModel.sendChatMessage(text) },
            onOpenVideo = { videoId ->
                val index = videos.indexOfFirst { it.id == videoId }
                if (index >= 0) {
                    viewModel.updateFeedIndex(index)
                    viewModel.closeChat()
                    viewModel.selectTab(MainTab.HOME)
                }
            },
            onReportMessage = { msg -> viewModel.openReportForMessage(msg) },
            onReportUser = { otherUser -> viewModel.openReportForUser(otherUser) },
            onBlockUser = { otherUserId ->
                viewModel.blockUser(otherUserId)
                viewModel.closeChat()
            }
        )
    } else {
        Scaffold(
            modifier = modifier.fillMaxSize(),
            containerColor = Color.Black,
            bottomBar = {
                PlayNestBottomNavigationBar(
                    currentTab = currentTab,
                    unreadNotificationCount = unreadNotificationCount,
                    onTabSelected = { tab -> viewModel.selectTab(tab) }
                )
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = if (currentTab == MainTab.HOME) 0.dp else paddingValues.calculateBottomPadding())
            ) {
                when (currentTab) {
                    MainTab.HOME -> {
                        val isFeedActive = (currentTab == MainTab.HOME && activeConversation == null && !isSoundPickerOpen)
                        HomeScreen(
                            videos = videos,
                            currentFeedIndex = currentFeedIndex,
                            isGlobalMuted = isGlobalMuted,
                            onFeedIndexChanged = { index -> viewModel.updateFeedIndex(index) },
                            onToggleMute = { viewModel.toggleGlobalMute() },
                            onLikeVideo = { video -> viewModel.toggleLikeVideo(video) },
                            onSaveVideo = { video -> viewModel.toggleSaveVideo(video) },
                            onFollowCreator = { creatorId -> viewModel.toggleFollowCreator(creatorId) },
                            onOpenComments = { video -> viewModel.openComments(video) },
                            onOpenShare = { video -> viewModel.openShare(video) },
                            onCreatorClick = { creatorId -> viewModel.openCreatorProfileById(creatorId) },
                            isFeedActive = isFeedActive
                        )
                    }
                    MainTab.DISCOVER -> {
                        DiscoverScreen(
                            videos = videos,
                            creators = creators,
                            searchQuery = searchQuery,
                            selectedCategory = selectedCategory,
                            trendingHashtags = trendingHashtags,
                            searchResults = searchResults,
                            searchHistory = searchHistory,
                            isSearching = isSearching,
                            onSearchQueryChange = { query -> viewModel.setSearchQuery(query) },
                            onCategoryChange = { cat -> viewModel.setCategory(cat) },
                            onFollowCreator = { id -> viewModel.toggleFollowCreator(id) },
                            onCreatorClick = { creator -> viewModel.openCreatorProfile(creator) },
                            onVideoClick = { video ->
                                val index = videos.indexOfFirst { it.id == video.id }
                                if (index >= 0) {
                                    viewModel.updateFeedIndex(index)
                                }
                                viewModel.selectTab(MainTab.HOME)
                            },
                            onRemoveHistoryItem = { id -> viewModel.removeSearchHistoryItem(id) },
                            onClearHistory = { viewModel.clearSearchHistory() },
                            onHashtagClick = { tag -> viewModel.selectHashtag(tag) }
                        )
                    }
                    MainTab.CREATE -> {
                        CreateScreen(
                            selectedSound = selectedSound,
                            uploadState = uploadState,
                            onOpenSoundSelector = { viewModel.setSoundPickerOpen(true) },
                            onCancelUpload = { viewModel.cancelUpload() },
                            onResetUploadState = { viewModel.resetUploadState() },
                            onPublish = { caption, tags, location, vidUri, thumbUri, cat, trimStart, trimEnd ->
                                viewModel.publishCreatedVideo(
                                    caption = caption,
                                    hashtags = tags,
                                    videoUri = vidUri,
                                    thumbnailUri = thumbUri,
                                    category = cat,
                                    location = location,
                                    trimStartMs = trimStart,
                                    trimEndMs = trimEnd
                                ) {
                                    Toast.makeText(context, "🎉 Video published to Play Nest feed!", Toast.LENGTH_LONG).show()
                                }
                            }
                        )
                    }
                    MainTab.INBOX -> {
                        InboxScreen(
                            inboxTab = inboxTab,
                            conversations = conversations,
                            notifications = notifications,
                            creators = creators,
                            onTabChange = { tab -> viewModel.setInboxTab(tab) },
                            onOpenConversation = { conv -> viewModel.openChat(conv) },
                            onStartConversationWithUser = { user -> viewModel.startConversationWithUser(user) },
                            onMarkConversationAsRead = { conv -> viewModel.markConversationAsRead(conv.id, conv.otherUser.id) },
                            onDeleteConversation = { conv -> viewModel.deleteConversation(conv.id) },
                            onMarkAllAsRead = { viewModel.markAllNotificationsAsRead() },
                            onNotificationClick = { notif ->
                                viewModel.markNotificationAsRead(notif.id)
                                if (notif.videoId != null) {
                                    val index = videos.indexOfFirst { it.id == notif.videoId }
                                    if (index >= 0) {
                                        viewModel.updateFeedIndex(index)
                                        viewModel.selectTab(MainTab.HOME)
                                    }
                                }
                            }
                        )
                    }
                    MainTab.PROFILE -> {
                        ProfileScreen(
                            user = currentUser,
                            videos = videos,
                            profileTab = profileTab,
                            onTabChange = { tab -> viewModel.setProfileTab(tab) },
                            onEditProfileClick = { viewModel.setEditProfileOpen(true) },
                            onOpenSettings = { viewModel.setSettingsOpen(true) },
                            onLogout = { viewModel.logOut() },
                            onVideoClick = { video ->
                                val index = videos.indexOfFirst { it.id == video.id }
                                if (index >= 0) {
                                    viewModel.updateFeedIndex(index)
                                }
                                viewModel.selectTab(MainTab.HOME)
                            }
                        )
                    }
                }
            }
        }
    }

    // Comments Sheet
    if (activeCommentsVideo != null) {
        CommentsBottomSheet(
            comments = videoComments,
            totalCommentsCount = activeCommentsVideo!!.commentsCount,
            currentUserId = currentUser.id,
            isAuthenticated = isAuthenticated == true,
            onDismiss = { viewModel.closeComments() },
            onAddComment = { text -> viewModel.addComment(text) },
            onAddReply = { commentId, text -> viewModel.addReplyToComment(commentId, text) },
            onLikeComment = { commentId -> viewModel.likeComment(commentId) },
            onDeleteComment = { commentId -> viewModel.deleteComment(commentId) },
            onReportComment = { comment -> viewModel.openReportForComment(comment, activeCommentsVideo!!.id) },
            onRequireAuth = { viewModel.openLogin() }
        )
    }

    // Creator Profile Sheet
    if (activeCreatorProfile != null) {
        CreatorProfileSheet(
            creator = activeCreatorProfile!!,
            videos = videos,
            onFollowToggle = { viewModel.toggleFollowCreator(activeCreatorProfile!!.id) },
            onVideoClick = { video ->
                val index = videos.indexOfFirst { it.id == video.id }
                if (index >= 0) {
                    viewModel.updateFeedIndex(index)
                }
                viewModel.selectTab(MainTab.HOME)
            },
            onDismiss = { viewModel.closeCreatorProfile() },
            onReportCreator = { creator -> viewModel.openReportForUser(creator) },
            onBlockCreator = { creator -> viewModel.blockCreator(creator) }
        )
    }

    // Share Sheet
    if (shareModalVideo != null) {
        val video = shareModalVideo!!
        ShareBottomSheet(
            video = video,
            creators = creators,
            onDismiss = { viewModel.closeShare() },
            onShareExternal = {
                viewModel.shareVideo(video)
                viewModel.closeShare()
            },
            onCopyLink = {
                viewModel.copyVideoLink(video)
            },
            onShareToPlayNestUser = { recipient ->
                viewModel.shareVideoToPlayNestUser(video, recipient)
                viewModel.closeShare()
            },
            onReportClick = {
                val v = video
                viewModel.closeShare()
                viewModel.openReport(v)
            },
            onBlockCreator = {
                viewModel.blockUser(video.creatorId)
            },
            onToggleSave = {
                viewModel.toggleSaveVideo(video)
            }
        )
    }

    // Report Sheet
    if (activeReportTarget != null || reportModalVideo != null) {
        val target = activeReportTarget
        ReportBottomSheet(
            targetTitle = target?.title ?: (if (reportModalVideo != null) "Video by @${reportModalVideo!!.creatorUsername}" else "Content"),
            contentType = target?.contentType ?: com.example.data.model.ReportContentType.VIDEO,
            onDismiss = { viewModel.closeReport() },
            onSubmitReport = { reason, details ->
                viewModel.submitReport(reason, details)
            }
        )
    }

    // Sound Picker Sheet
    if (isSoundPickerOpen) {
        SoundPickerSheet(
            sounds = soundTracks,
            selectedSound = selectedSound,
            onSelectSound = { sound -> viewModel.selectSound(sound) },
            onDismiss = { viewModel.setSoundPickerOpen(false) }
        )
    }

    // Edit Profile Dialog
    if (isEditProfileOpen) {
        EditProfileDialog(
            user = currentUser,
            onDismiss = { viewModel.setEditProfileOpen(false) },
            onSave = { dName, uName, bio, avatar ->
                viewModel.updateProfile(dName, uName, bio, avatar)
            }
        )
    }

    // Settings Dialog
    if (isSettingsOpen) {
        SettingsDialog(
            currentUser = currentUser,
            blockedUsers = blockedUsers,
            userReports = userReports,
            privacySettings = privacySettings,
            onUpdatePrivacySettings = { updated -> viewModel.updatePrivacySettings(updated) },
            onUnblockUser = { userId -> viewModel.unblockUser(userId) },
            onDismiss = { viewModel.setSettingsOpen(false) },
            onSwitchUser = { viewModel.openLogin() },
            onLogout = { viewModel.logOut() },
            onDeleteAccount = { password, callback ->
                viewModel.deleteAccount(password, callback)
            },
            onSendPasswordReset = { email -> viewModel.sendPasswordReset(email) }
        )
    }

    // Login / Auth Dialog with real Firebase Auth
    if (showAuthDialog) {
        PlayNestAuthDialog(
            isLoading = authLoading,
            errorMessage = authError,
            successMessage = authSuccessMessage,
            onSignIn = { email, pass -> viewModel.signInWithEmail(email, pass) },
            onSignUp = { email, pass, username, displayName ->
                viewModel.signUpWithEmail(email, pass, username, displayName)
            },
            onForgotPassword = { email -> viewModel.sendPasswordReset(email) },
            onDismiss = { viewModel.closeLogin() }
        )
    }
}

/**
 * Play Nest Bottom Navigation Bar
 */
@Composable
fun PlayNestBottomNavigationBar(
    currentTab: MainTab,
    unreadNotificationCount: Int = 0,
    onTabSelected: (MainTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color.Black.copy(alpha = 0.0f),
                        Color.Black.copy(alpha = 0.95f),
                        Color.Black
                    )
                )
            )
            .navigationBarsPadding()
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 1. Home
            BottomNavItem(
                icon = if (currentTab == MainTab.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                label = "Home",
                isSelected = currentTab == MainTab.HOME,
                activeColor = PlayNestPink,
                onClick = { onTabSelected(MainTab.HOME) },
                testTag = "nav_home"
            )

            // 2. Discover
            BottomNavItem(
                icon = if (currentTab == MainTab.DISCOVER) Icons.Filled.Explore else Icons.Outlined.Explore,
                label = "Discover",
                isSelected = currentTab == MainTab.DISCOVER,
                activeColor = PlayNestBlue,
                onClick = { onTabSelected(MainTab.DISCOVER) },
                testTag = "nav_discover"
            )

            // 3. Create (+) Button
            CenterCreateButton(
                onClick = { onTabSelected(MainTab.CREATE) }
            )

            // 4. Inbox
            BottomNavItem(
                icon = if (currentTab == MainTab.INBOX) Icons.Filled.ChatBubble else Icons.Outlined.ChatBubbleOutline,
                label = "Inbox",
                isSelected = currentTab == MainTab.INBOX,
                activeColor = PlayNestGreen,
                badgeCount = unreadNotificationCount,
                onClick = { onTabSelected(MainTab.INBOX) },
                testTag = "nav_inbox"
            )

            // 5. Profile
            BottomNavItem(
                icon = if (currentTab == MainTab.PROFILE) Icons.Filled.Person else Icons.Outlined.Person,
                label = "Profile",
                isSelected = currentTab == MainTab.PROFILE,
                activeColor = PlayNestPurple,
                onClick = { onTabSelected(MainTab.PROFILE) },
                testTag = "nav_profile"
            )
        }
    }
}

@Composable
fun BottomNavItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    activeColor: Color,
    badgeCount: Int = 0,
    onClick: () -> Unit,
    testTag: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .testTag(testTag)
    ) {
        Box(contentAlignment = Alignment.TopEnd) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isSelected) activeColor else Color.White.copy(alpha = 0.6f),
                modifier = Modifier.size(24.dp)
            )
            if (badgeCount > 0) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(PlayNestPink)
                )
            }
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            color = if (isSelected) Color.White else Color.White.copy(alpha = 0.5f),
            fontSize = 10.5.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
fun CenterCreateButton(
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .padding(horizontal = 4.dp)
            .size(width = 46.dp, height = 34.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(PlayNestPrimaryGradient)
            .clickable { onClick() }
            .testTag("nav_create_btn"),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.Add,
            contentDescription = "Create Video",
            tint = Color.White,
            modifier = Modifier.size(22.dp)
        )
    }
}
