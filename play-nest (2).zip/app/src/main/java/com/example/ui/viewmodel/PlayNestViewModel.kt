package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.BlockedUserRecord
import com.example.data.model.ChatConversation
import com.example.data.model.ChatMessage
import com.example.data.model.Comment
import com.example.data.model.ContentReport
import com.example.data.model.HashtagItem
import com.example.data.model.NotificationItem
import com.example.data.model.ReportContentType
import com.example.data.model.SearchHistoryItem
import com.example.data.model.SearchResult
import com.example.data.model.SharedVideoPreview
import com.example.data.model.SoundTrack
import com.example.data.model.User
import com.example.data.model.UserPrivacySettings
import com.example.data.model.Video
import com.example.data.repository.PlayNestRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class MainTab {
    HOME, DISCOVER, CREATE, INBOX, PROFILE
}

sealed class VideoUploadState {
    object Idle : VideoUploadState()
    data class Uploading(val progress: Float, val statusMessage: String) : VideoUploadState()
    data class Success(val video: Video) : VideoUploadState()
    data class Error(val errorMessage: String) : VideoUploadState()
}

data class ReportTarget(
    val id: String,
    val contentType: ReportContentType = ReportContentType.VIDEO,
    val reportedUserId: String = "",
    val title: String = "Content",
    val summary: String = ""
)

class PlayNestViewModel(application: Application) : AndroidViewModel(application) {
    val repository = PlayNestRepository(application)
    private val playbackPrefs = application.getSharedPreferences("playnest_playback_prefs", android.content.Context.MODE_PRIVATE)

    // Current navigation tab
    private val _currentTab = MutableStateFlow(MainTab.HOME)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    // Current Playing Video Index in Home Feed
    private val _currentFeedIndex = MutableStateFlow(0)
    val currentFeedIndex: StateFlow<Int> = _currentFeedIndex.asStateFlow()

    // Global sound mute state (remembered across sessions)
    private val _isGlobalMuted = MutableStateFlow(playbackPrefs.getBoolean("key_global_muted", false))
    val isGlobalMuted: StateFlow<Boolean> = _isGlobalMuted.asStateFlow()

    // Modals & Bottom Sheets
    private val _activeCommentsVideo = MutableStateFlow<Video?>(null)
    val activeCommentsVideo: StateFlow<Video?> = _activeCommentsVideo.asStateFlow()

    private val _activeShareVideo = MutableStateFlow<Video?>(null)
    val activeShareVideo: StateFlow<Video?> = _activeShareVideo.asStateFlow()

    private val _activeReportVideo = MutableStateFlow<Video?>(null)
    val activeReportVideo: StateFlow<Video?> = _activeReportVideo.asStateFlow()

    private val _activeReportTarget = MutableStateFlow<ReportTarget?>(null)
    val activeReportTarget: StateFlow<ReportTarget?> = _activeReportTarget.asStateFlow()

    val blockedUsers: StateFlow<List<BlockedUserRecord>> = repository.blockedUsers
    val userReports: StateFlow<List<ContentReport>> = repository.userReports
    val privacySettings: StateFlow<UserPrivacySettings> = repository.privacySettings

    private val _activeChat = MutableStateFlow<ChatConversation?>(null)
    val activeChat: StateFlow<ChatConversation?> = _activeChat.asStateFlow()

    private val _activeCreatorProfile = MutableStateFlow<User?>(null)
    val activeCreatorProfile: StateFlow<User?> = _activeCreatorProfile.asStateFlow()

    private val _showEditProfile = MutableStateFlow(false)
    val showEditProfile: StateFlow<Boolean> = _showEditProfile.asStateFlow()

    private val _showSettings = MutableStateFlow(false)
    val showSettings: StateFlow<Boolean> = _showSettings.asStateFlow()

    private val _showAuthDialog = MutableStateFlow(false)
    val showAuthDialog: StateFlow<Boolean> = _showAuthDialog.asStateFlow()

    private val _showSoundSelector = MutableStateFlow(false)
    val showSoundSelector: StateFlow<Boolean> = _showSoundSelector.asStateFlow()

    private val _selectedSound = MutableStateFlow<SoundTrack?>(null)
    val selectedSound: StateFlow<SoundTrack?> = _selectedSound.asStateFlow()

    // Discover search & category filter
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    // Profile Screen Sub-Tab: 0 = Posts, 1 = Saved, 2 = Liked
    private val _profileTab = MutableStateFlow(0)
    val profileTab: StateFlow<Int> = _profileTab.asStateFlow()

    // Inbox sub-tab: 0 = Messages, 1 = Notifications
    private val _inboxTab = MutableStateFlow(0)
    val inboxTab: StateFlow<Int> = _inboxTab.asStateFlow()

    // Raw streams from repository
    val currentUser: StateFlow<User> = repository.currentUser
    val isAuthenticated: StateFlow<Boolean?> = repository.isAuthenticated
    val allVideos: StateFlow<List<Video>> = repository.videos
    val creators: StateFlow<List<User>> = repository.creators
    val notifications: StateFlow<List<NotificationItem>> = repository.notifications
    val conversations: StateFlow<List<ChatConversation>> = repository.conversations
    val chatMessages: StateFlow<Map<String, List<ChatMessage>>> = repository.chatMessages
    val soundTracks: List<SoundTrack> = repository.soundTracks
    val trendingHashtags = repository.trendingHashtags
    val searchResults: StateFlow<SearchResult> = repository.searchResults
    val searchHistory: StateFlow<List<SearchHistoryItem>> = repository.searchHistory
    val isSearching: StateFlow<Boolean> = repository.isSearching
    val searchError: StateFlow<String?> = repository.searchError
    val trendingHashtagItems: StateFlow<List<HashtagItem>> = repository.trendingHashtagItems

    // Filtered videos for Discover Screen (excluding blocked creators)
    val filteredVideos: StateFlow<List<Video>> = combine(
        allVideos,
        searchQuery,
        selectedCategory,
        blockedUsers
    ) { videos, query, category, blocked ->
        val blockedIds = blocked.map { it.blockedUserId }.toSet()
        val visible = if (blockedIds.isEmpty()) videos else videos.filter { it.creatorId !in blockedIds && it.creatorUsername !in blockedIds }
        visible.filter { video ->
            val matchesCategory = (category == "All" || video.category.equals(category, ignoreCase = true))
            val matchesQuery = query.isBlank() ||
                video.caption.contains(query, ignoreCase = true) ||
                video.creatorUsername.contains(query, ignoreCase = true) ||
                video.creatorDisplayName.contains(query, ignoreCase = true) ||
                video.hashtags.any { it.contains(query, ignoreCase = true) }
            matchesCategory && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Comments for active video
    val activeComments: StateFlow<List<Comment>> = combine(
        activeCommentsVideo,
        repository.comments
    ) { video, map ->
        if (video != null) map[video.id] ?: emptyList() else emptyList()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Navigation
    fun setTab(tab: MainTab) {
        _currentTab.value = tab
    }

    fun setFeedIndex(index: Int) {
        _currentFeedIndex.value = index
    }

    fun toggleGlobalMute() {
        val newMuted = !_isGlobalMuted.value
        _isGlobalMuted.value = newMuted
        playbackPrefs.edit().putBoolean("key_global_muted", newMuted).apply()
    }

    // Likes & Interactions
    fun onLikeVideo(video: Video) {
        repository.toggleLike(video.id)
    }

    fun onSaveVideo(video: Video) {
        repository.toggleSave(video.id)
    }

    fun onFollowCreator(creatorId: String) {
        repository.toggleFollowCreator(creatorId)
        _activeCreatorProfile.update { current ->
            if (current?.id == creatorId) {
                val newFollowing = !current.isFollowing
                val newFollowers = if (newFollowing) current.followersCount + 1 else (current.followersCount - 1).coerceAtLeast(0)
                current.copy(isFollowing = newFollowing, followersCount = newFollowers)
            } else current
        }
    }

    fun openCreatorProfile(user: User) {
        _activeCreatorProfile.value = user
    }

    fun openCreatorProfileById(userId: String) {
        val found = creators.value.find { it.id == userId } 
            ?: allVideos.value.find { it.creatorId == userId }?.let {
                User(
                    id = it.creatorId,
                    username = it.creatorUsername,
                    displayName = it.creatorDisplayName,
                    avatarUrl = it.creatorAvatarUrl,
                    bio = "Content Creator on Play Nest",
                    isVerified = it.isCreatorVerified,
                    followersCount = 1200,
                    followingCount = 85,
                    likesCount = 45000L,
                    isFollowing = it.isFollowingCreator
                )
            }
        _activeCreatorProfile.value = found
    }

    fun closeCreatorProfile() {
        _activeCreatorProfile.value = null
    }

    fun openComments(video: Video) {
        _activeCommentsVideo.value = video
        repository.loadCommentsForVideo(video.id)
    }

    fun closeComments() {
        _activeCommentsVideo.value = null
    }

    fun addComment(text: String) {
        val vid = _activeCommentsVideo.value?.id ?: return
        repository.addComment(vid, text)
    }

    fun deleteComment(commentId: String) {
        val vid = _activeCommentsVideo.value?.id ?: return
        repository.deleteComment(vid, commentId)
    }

    fun addReply(commentId: String, text: String) {
        val vid = _activeCommentsVideo.value?.id ?: return
        repository.addReply(vid, commentId, text)
    }

    fun likeComment(commentId: String) {
        val vid = _activeCommentsVideo.value?.id ?: return
        repository.toggleLikeComment(vid, commentId)
    }

    fun openShare(video: Video) {
        _activeShareVideo.value = video
    }

    fun closeShare() {
        _activeShareVideo.value = null
    }

    fun shareVideo(video: Video) {
        repository.shareVideo(video)
        _activeShareVideo.value = null
    }

    fun openReport(video: Video) {
        _activeReportVideo.value = video
        _activeReportTarget.value = ReportTarget(
            id = video.id,
            contentType = ReportContentType.VIDEO,
            reportedUserId = video.creatorId,
            title = "Video by @${video.creatorUsername}",
            summary = video.caption
        )
        _activeShareVideo.value = null
    }

    fun openReportForComment(comment: Comment, videoId: String) {
        _activeReportTarget.value = ReportTarget(
            id = comment.id,
            contentType = ReportContentType.COMMENT,
            reportedUserId = comment.userId,
            title = "Comment by @${comment.username}",
            summary = comment.text
        )
    }

    fun openReportForUser(user: User) {
        _activeReportTarget.value = ReportTarget(
            id = user.id,
            contentType = ReportContentType.USER,
            reportedUserId = user.id,
            title = "User Profile @${user.username}",
            summary = user.displayName
        )
    }

    fun openReportForMessage(message: ChatMessage) {
        _activeReportTarget.value = ReportTarget(
            id = message.id,
            contentType = ReportContentType.MESSAGE,
            reportedUserId = message.senderId,
            title = "Direct Message from @${message.senderUsername}",
            summary = message.message
        )
    }

    fun closeReport() {
        _activeReportVideo.value = null
        _activeReportTarget.value = null
    }

    fun submitReport(reason: String, details: String, onResult: (Boolean, String) -> Unit = { _, _ -> }) {
        val target = _activeReportTarget.value
        if (target != null) {
            repository.submitReport(
                targetId = target.id,
                contentType = target.contentType,
                reason = reason,
                details = details,
                reportedUserId = target.reportedUserId,
                targetSummary = target.summary.ifBlank { target.title }
            ) { success, msg ->
                onResult(success, msg)
                if (success) {
                    closeReport()
                }
            }
        } else {
            val vid = _activeReportVideo.value?.id
            if (vid != null) {
                repository.reportContent(vid, reason, details)
                closeReport()
                onResult(true, "Thank you for reporting. Our Trust & Safety team is reviewing this.")
            } else {
                onResult(false, "No content selected to report.")
            }
        }
    }

    fun blockUser(userId: String) {
        repository.blockUser(userId)
        _activeShareVideo.value = null
    }

    fun blockCreator(creator: User) {
        repository.blockUser(creator)
        _activeShareVideo.value = null
    }

    fun unblockUser(userId: String, onResult: (Boolean) -> Unit = {}) {
        repository.unblockUser(userId, onResult)
    }

    fun updatePrivacySettings(settings: UserPrivacySettings, onComplete: (Boolean) -> Unit = {}) {
        repository.updatePrivacySettings(settings, onComplete)
    }

    fun deleteAccount(password: String? = null, onResult: (Result<Unit>) -> Unit) {
        viewModelScope.launch {
            val result = repository.deleteAccount(password)
            onResult(result)
        }
    }

    // Direct Messaging
    fun openChat(conversation: ChatConversation) {
        _activeChat.value = conversation
        repository.subscribeToMessages(conversation.id, conversation.otherUser.id)
        repository.markConversationAsRead(conversation.id, conversation.otherUser.id)
    }

    fun startConversationWithUser(user: User) {
        repository.startConversationWithUser(user) { conv ->
            _activeChat.value = conv
        }
    }

    fun closeChat() {
        _activeChat.value = null
    }

    fun sendChatMessage(text: String, sharedVideo: SharedVideoPreview? = null) {
        val otherId = _activeChat.value?.otherUser?.id ?: return
        repository.sendDirectMessage(otherId, text, sharedVideo)
    }

    fun markConversationAsRead(conversationId: String, otherUserId: String) {
        repository.markConversationAsRead(conversationId, otherUserId)
    }

    fun deleteConversation(conversationId: String) {
        if (_activeChat.value?.id == conversationId) {
            _activeChat.value = null
        }
        repository.deleteConversation(conversationId)
    }

    // Video Sharing
    fun copyVideoLink(video: Video) {
        repository.copyVideoLink(video)
    }

    fun shareVideoToPlayNestUser(video: Video, recipientUser: User) {
        repository.shareVideoToPlayNestUser(video, recipientUser)
    }

    // Discover filters & real search
    fun setSearchQuery(query: String) {
        _searchQuery.value = query
        repository.performSearch(query)
    }

    fun selectHashtag(tag: String) {
        val query = if (tag.startsWith("#")) tag else "#$tag"
        _searchQuery.value = query
        repository.performSearch(query)
    }

    fun removeSearchHistoryItem(id: String) {
        repository.removeSearchHistoryItem(id)
    }

    fun clearSearchHistory() {
        repository.clearSearchHistory()
    }

    fun markNotificationAsRead(id: String) {
        repository.markNotificationAsRead(id)
    }

    fun markAllNotificationsAsRead() {
        repository.markAllNotificationsAsRead()
    }

    fun setCategory(category: String) {
        _selectedCategory.value = category
    }

    // Profile & Settings
    fun setProfileTab(tab: Int) {
        _profileTab.value = tab
    }

    fun setInboxTab(tab: Int) {
        _inboxTab.value = tab
    }

    fun openEditProfile() {
        _showEditProfile.value = true
    }

    fun closeEditProfile() {
        _showEditProfile.value = false
    }

    fun saveProfile(displayName: String, username: String, bio: String, avatarUrl: String) {
        repository.updateProfile(displayName, username, bio, avatarUrl)
        _showEditProfile.value = false
    }

    fun openSettings() {
        _showSettings.value = true
    }

    fun closeSettings() {
        _showSettings.value = false
    }

    fun openAuthDialog() {
        _showAuthDialog.value = true
        _showSettings.value = false
    }

    fun closeAuthDialog() {
        _showAuthDialog.value = false
    }

    fun openSoundSelector() {
        _showSoundSelector.value = true
    }

    fun closeSoundSelector() {
        _showSoundSelector.value = false
    }

    fun selectSound(sound: SoundTrack) {
        _selectedSound.value = sound
        _showSoundSelector.value = false
    }

    // Upload State
    private var uploadJob: Job? = null
    private val _uploadState = MutableStateFlow<VideoUploadState>(VideoUploadState.Idle)
    val uploadState: StateFlow<VideoUploadState> = _uploadState.asStateFlow()

    fun resetUploadState() {
        _uploadState.value = VideoUploadState.Idle
    }

    fun cancelUpload() {
        uploadJob?.cancel()
        uploadJob = null
        _uploadState.value = VideoUploadState.Idle
    }

    // Video Creation with real async upload & progress
    fun publishCreatedVideo(
        caption: String,
        hashtags: List<String>,
        videoUri: String,
        thumbnailUri: String,
        category: String,
        location: String = "",
        trimStartMs: Long = 0L,
        trimEndMs: Long = 0L,
        onSuccess: (Video) -> Unit = {}
    ) {
        if (videoUri.isBlank()) {
            _uploadState.value = VideoUploadState.Error("Please select or record a video first.")
            return
        }

        uploadJob?.cancel()
        uploadJob = viewModelScope.launch {
            _uploadState.value = VideoUploadState.Uploading(0.05f, "Preparing video file...")
            val sound = _selectedSound.value
            val result = repository.publishVideoWithProgress(
                caption = caption,
                hashtags = hashtags,
                location = location,
                videoUri = videoUri,
                thumbnailUri = thumbnailUri,
                musicTitle = sound?.title ?: "Original Audio - ${currentUser.value.displayName}",
                musicArtist = sound?.artist ?: currentUser.value.displayName,
                category = category,
                trimStartMs = trimStartMs,
                trimEndMs = trimEndMs
            ) { progress, message ->
                _uploadState.value = VideoUploadState.Uploading(progress, message)
            }

            result.fold(
                onSuccess = { createdVideo ->
                    _uploadState.value = VideoUploadState.Success(createdVideo)
                    _selectedSound.value = null
                    _currentFeedIndex.value = 0
                    _currentTab.value = MainTab.HOME
                    onSuccess(createdVideo)
                },
                onFailure = { err ->
                    _uploadState.value = VideoUploadState.Error(
                        err.message ?: "Failed to upload video. Please try again."
                    )
                }
            )
        }
    }

    // Convenience properties and delegates for UI (feed videos hide blocked creators)
    val videos: StateFlow<List<Video>> = combine(
        allVideos,
        blockedUsers
    ) { vids, blocked ->
        val blockedIds = blocked.map { it.blockedUserId }.toSet()
        if (blockedIds.isEmpty()) vids
        else vids.filter { it.creatorId !in blockedIds && it.creatorUsername !in blockedIds }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val videoComments: StateFlow<List<Comment>> = activeComments
    val shareModalVideo: StateFlow<Video?> = activeShareVideo
    val reportModalVideo: StateFlow<Video?> = activeReportVideo
    val activeConversation: StateFlow<ChatConversation?> = activeChat
    val isSoundPickerOpen: StateFlow<Boolean> = showSoundSelector
    val isEditProfileOpen: StateFlow<Boolean> = showEditProfile
    val isSettingsOpen: StateFlow<Boolean> = showSettings

    val activeChatMessages: StateFlow<List<ChatMessage>> = combine(
        activeChat,
        chatMessages
    ) { chat, map ->
        if (chat != null) map[chat.otherUser.id] ?: emptyList() else emptyList()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectTab(tab: MainTab) = setTab(tab)
    fun updateFeedIndex(index: Int) = setFeedIndex(index)
    fun navigateToVideoById(videoId: String) {
        val index = allVideos.value.indexOfFirst { it.id == videoId }
        if (index >= 0) {
            setFeedIndex(index)
            setTab(MainTab.HOME)
        }
    }
    fun toggleLikeVideo(video: Video) = onLikeVideo(video)
    fun toggleSaveVideo(video: Video) = onSaveVideo(video)
    fun toggleFollowCreator(creatorId: String) = onFollowCreator(creatorId)
    fun blockCreator(creatorId: String) = blockUser(creatorId)
    fun addReplyToComment(commentId: String, text: String) = addReply(commentId, text)
    fun sendMessage(text: String) = sendChatMessage(text)
    fun updateSearchQuery(query: String) = setSearchQuery(query)
    fun selectCategory(category: String) = setCategory(category)
    fun setSoundPickerOpen(open: Boolean) { _showSoundSelector.value = open }
    fun setEditProfileOpen(open: Boolean) { _showEditProfile.value = open }
    fun setSettingsOpen(open: Boolean) { _showSettings.value = open }
    fun updateProfile(displayName: String, username: String, bio: String, avatarUrl: String) =
        saveProfile(displayName, username, bio, avatarUrl)
    // Auth Operation UI State
    private val _authLoading = MutableStateFlow(false)
    val authLoading: StateFlow<Boolean> = _authLoading.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _authSuccessMessage = MutableStateFlow<String?>(null)
    val authSuccessMessage: StateFlow<String?> = _authSuccessMessage.asStateFlow()

    fun clearAuthMessages() {
        _authError.value = null
        _authSuccessMessage.value = null
    }

    fun signInWithEmail(email: String, pass: String) {
        if (email.isBlank() || pass.isBlank()) {
            _authError.value = "Please enter both email and password."
            return
        }
        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            val result = repository.signIn(email.trim(), pass)
            _authLoading.value = false
            if (result.isSuccess) {
                _showAuthDialog.value = false
                _authSuccessMessage.value = "Welcome back!"
            } else {
                _authError.value = result.exceptionOrNull()?.localizedMessage ?: "Sign in failed"
            }
        }
    }

    fun signUpWithEmail(email: String, pass: String, username: String, displayName: String) {
        if (email.isBlank() || pass.isBlank()) {
            _authError.value = "Email and password cannot be empty."
            return
        }
        if (pass.length < 6) {
            _authError.value = "Password must be at least 6 characters."
            return
        }
        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            val cleanUser = if (username.isBlank()) email.substringBefore("@") else username.trim()
            val cleanDisplay = if (displayName.isBlank()) cleanUser.replaceFirstChar { it.uppercase() } else displayName.trim()
            val result = repository.signUp(email.trim(), pass, cleanUser, cleanDisplay)
            _authLoading.value = false
            if (result.isSuccess) {
                _showAuthDialog.value = false
                _authSuccessMessage.value = "Account created successfully!"
            } else {
                _authError.value = result.exceptionOrNull()?.localizedMessage ?: "Registration failed"
            }
        }
    }

    fun sendPasswordReset(email: String) {
        if (email.isBlank()) {
            _authError.value = "Please enter your email to receive reset instructions."
            return
        }
        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            val result = repository.sendPasswordReset(email.trim())
            _authLoading.value = false
            if (result.isSuccess) {
                _authSuccessMessage.value = "Password reset email sent to $email."
            } else {
                _authError.value = result.exceptionOrNull()?.localizedMessage ?: "Failed to send reset email"
            }
        }
    }

    fun logOut() {
        viewModelScope.launch {
            repository.logOut()
            _showSettings.value = false
            _showAuthDialog.value = false
        }
    }

    fun openLogin() {
        clearAuthMessages()
        _showAuthDialog.value = true
        _showSettings.value = false
    }

    fun closeLogin() {
        clearAuthMessages()
        _showAuthDialog.value = false
    }

    fun loginWithUser(username: String) {
        val matched = creators.value.firstOrNull { it.username.equals(username, ignoreCase = true) }
        if (matched != null) {
            repository.updateProfile(matched.displayName, matched.username, matched.bio, matched.avatarUrl)
        } else {
            val dName = username.trim().replaceFirstChar { it.uppercase() }
            val uName = username.trim().lowercase().replace(" ", "_")
            repository.updateProfile(dName, uName, "Creator on Play Nest 🎬", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300")
        }
        _showAuthDialog.value = false
    }
    fun switchAccount() {
        val nextUser = creators.value.firstOrNull { it.id != currentUser.value.id }
        if (nextUser != null) {
            repository.updateProfile(nextUser.displayName, nextUser.username, nextUser.bio, nextUser.avatarUrl)
        }
        _showSettings.value = false
    }
}

class PlayNestViewModelFactory(private val context: android.content.Context) : androidx.lifecycle.ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
        val app = context.applicationContext as Application
        return PlayNestViewModel(app) as T
    }
}
