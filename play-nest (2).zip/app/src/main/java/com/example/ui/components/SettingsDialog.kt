package com.example.ui.components

import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SwitchAccount
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.model.BlockedUserRecord
import com.example.data.model.ContentReport
import com.example.data.model.PrivacyAudience
import com.example.data.model.User
import com.example.data.model.UserPrivacySettings
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.PlayNestBlue
import com.example.ui.theme.PlayNestCyan
import com.example.ui.theme.PlayNestGreen
import com.example.ui.theme.PlayNestOrange
import com.example.ui.theme.PlayNestPink
import com.example.ui.theme.PlayNestPrimaryGradient
import com.example.ui.theme.PlayNestPurple
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class SettingsSubScreen {
    MAIN,
    ACCOUNT,
    PRIVACY_SAFETY,
    BLOCKED_ACCOUNTS,
    REPORT_HISTORY,
    HELP_SUPPORT,
    ABOUT
}

@Composable
fun SettingsDialog(
    currentUser: User,
    blockedUsers: List<BlockedUserRecord> = emptyList(),
    userReports: List<ContentReport> = emptyList(),
    privacySettings: UserPrivacySettings = UserPrivacySettings(),
    onUpdatePrivacySettings: (UserPrivacySettings) -> Unit = {},
    onUnblockUser: (String) -> Unit = {},
    onDismiss: () -> Unit,
    onSwitchUser: () -> Unit,
    onLogout: () -> Unit = {},
    onDeleteAccount: (password: String?, onResult: (Result<Unit>) -> Unit) -> Unit = { _, _ -> },
    onSendPasswordReset: (String) -> Unit = {}
) {
    val context = LocalContext.current
    var currentSubScreen by remember { mutableStateOf(SettingsSubScreen.MAIN) }
    var showLogoutConfirm by remember { mutableStateOf(false) }
    var showDeleteAccountDialog by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.88f)
                .padding(vertical = 12.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 16.dp)
            ) {
                // Top App Bar inside Dialog
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (currentSubScreen == SettingsSubScreen.MAIN) {
                        PlayNestLogoBadge(iconSize = 22.dp, showText = true)
                    } else {
                        IconButton(
                            onClick = { currentSubScreen = SettingsSubScreen.MAIN },
                            modifier = Modifier.size(32.dp).testTag("settings_back_btn")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = TextPrimary
                            )
                        }
                    }

                    Text(
                        text = when (currentSubScreen) {
                            SettingsSubScreen.MAIN -> "Settings"
                            SettingsSubScreen.ACCOUNT -> "Account Details"
                            SettingsSubScreen.PRIVACY_SAFETY -> "Privacy & Safety"
                            SettingsSubScreen.BLOCKED_ACCOUNTS -> "Blocked Accounts"
                            SettingsSubScreen.REPORT_HISTORY -> "Report History"
                            SettingsSubScreen.HELP_SUPPORT -> "Help & Support"
                            SettingsSubScreen.ABOUT -> "About Play Nest"
                        },
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(32.dp).testTag("close_settings_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = DarkBorder, thickness = 0.8.dp)
                Spacer(modifier = Modifier.height(12.dp))

                AnimatedContent(
                    targetState = currentSubScreen,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "settings_subscreen_nav"
                ) { screen ->
                    when (screen) {
                        SettingsSubScreen.MAIN -> {
                            MainSettingsView(
                                currentUser = currentUser,
                                blockedUsersCount = blockedUsers.size,
                                reportsCount = userReports.size,
                                onNavigate = { currentSubScreen = it },
                                onSwitchUser = onSwitchUser,
                                onLogoutClick = { showLogoutConfirm = true },
                                onDeleteAccountClick = { showDeleteAccountDialog = true }
                            )
                        }
                        SettingsSubScreen.ACCOUNT -> {
                            AccountDetailsView(
                                currentUser = currentUser,
                                onSendPasswordReset = onSendPasswordReset
                            )
                        }
                        SettingsSubScreen.PRIVACY_SAFETY -> {
                            PrivacySafetyView(
                                privacySettings = privacySettings,
                                onUpdatePrivacySettings = onUpdatePrivacySettings,
                                onOpenBlocked = { currentSubScreen = SettingsSubScreen.BLOCKED_ACCOUNTS },
                                onOpenReports = { currentSubScreen = SettingsSubScreen.REPORT_HISTORY }
                            )
                        }
                        SettingsSubScreen.BLOCKED_ACCOUNTS -> {
                            BlockedAccountsView(
                                blockedUsers = blockedUsers,
                                onUnblock = onUnblockUser
                            )
                        }
                        SettingsSubScreen.REPORT_HISTORY -> {
                            ReportHistoryView(reports = userReports)
                        }
                        SettingsSubScreen.HELP_SUPPORT -> {
                            HelpSupportView()
                        }
                        SettingsSubScreen.ABOUT -> {
                            AboutPlayNestView()
                        }
                    }
                }
            }
        }
    }

    // Logout Confirmation Dialog
    if (showLogoutConfirm) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirm = false },
            containerColor = DarkSurfaceElevated,
            title = { Text("Log Out?", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to log out of Play Nest? You can log back in anytime.", color = TextSecondary, fontSize = 14.sp) },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutConfirm = false
                        onLogout()
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PlayNestPink)
                ) {
                    Text("Log Out", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutConfirm = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }

    // Delete Account Confirmation Dialog
    if (showDeleteAccountDialog) {
        DeleteAccountConfirmationDialog(
            currentUser = currentUser,
            onDismiss = { showDeleteAccountDialog = false },
            onConfirmDelete = { password, callback ->
                onDeleteAccount(password) { result ->
                    callback(result)
                    if (result.isSuccess) {
                        showDeleteAccountDialog = false
                        onDismiss()
                    }
                }
            }
        )
    }
}

/**
 * Main Settings Navigation View
 */
@Composable
private fun MainSettingsView(
    currentUser: User,
    blockedUsersCount: Int,
    reportsCount: Int,
    onNavigate: (SettingsSubScreen) -> Unit,
    onSwitchUser: () -> Unit,
    onLogoutClick: () -> Unit,
    onDeleteAccountClick: () -> Unit
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Current User Profile Summary Card
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(DarkSurfaceElevated)
                .clickable { onNavigate(SettingsSubScreen.ACCOUNT) }
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(PlayNestPrimaryGradient)
                    .padding(2.dp)
            ) {
                AsyncImage(
                    model = currentUser.avatarUrl.ifBlank { "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400" },
                    contentDescription = currentUser.displayName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = currentUser.displayName,
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "@${currentUser.username}",
                    color = PlayNestPink,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
                if (currentUser.email.isNotBlank()) {
                    Text(
                        text = currentUser.email,
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
            }

            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                contentDescription = null,
                tint = TextMuted,
                modifier = Modifier.size(14.dp)
            )
        }

        // Section: Safety & Privacy
        SettingsSectionHeader(title = "Privacy & Safety")
        SettingsRowItem(
            icon = Icons.Default.Shield,
            iconTint = PlayNestPurple,
            title = "Privacy & Safety Settings",
            subtitle = "Private account, comment & DM permissions",
            onClick = { onNavigate(SettingsSubScreen.PRIVACY_SAFETY) },
            testTag = "settings_privacy_safety_btn"
        )
        SettingsRowItem(
            icon = Icons.Default.Block,
            iconTint = PlayNestPink,
            title = "Blocked Accounts",
            subtitle = if (blockedUsersCount > 0) "$blockedUsersCount user(s) blocked" else "No blocked accounts",
            badge = if (blockedUsersCount > 0) "$blockedUsersCount" else null,
            onClick = { onNavigate(SettingsSubScreen.BLOCKED_ACCOUNTS) },
            testTag = "settings_blocked_accounts_btn"
        )
        SettingsRowItem(
            icon = Icons.Default.History,
            iconTint = PlayNestBlue,
            title = "Report History",
            subtitle = if (reportsCount > 0) "$reportsCount report(s) submitted" else "View status of reports",
            badge = if (reportsCount > 0) "$reportsCount" else null,
            onClick = { onNavigate(SettingsSubScreen.REPORT_HISTORY) },
            testTag = "settings_report_history_btn"
        )

        // Section: App Preferences
        SettingsSectionHeader(title = "App & Storage")
        SettingsRowItem(
            icon = Icons.Default.Delete,
            iconTint = PlayNestOrange,
            title = "Clear Video Cache",
            subtitle = "Frees temporary playback data",
            onClick = {
                Toast.makeText(context, "Video cache cleared (124 MB freed)", Toast.LENGTH_SHORT).show()
            },
            testTag = "clear_cache_btn"
        )
        SettingsRowItem(
            icon = Icons.Default.CloudDone,
            iconTint = PlayNestGreen,
            title = "Firebase Cloud Architecture",
            subtitle = "Live Auth, Firestore & Safety Storage",
            onClick = {
                Toast.makeText(context, "Real Firebase backend is operational", Toast.LENGTH_SHORT).show()
            }
        )

        // Section: Support & About
        SettingsSectionHeader(title = "Support & Legal")
        SettingsRowItem(
            icon = Icons.AutoMirrored.Filled.HelpOutline,
            iconTint = PlayNestCyan,
            title = "Help & Community Guidelines",
            subtitle = "Rules for a safe & creative community",
            onClick = { onNavigate(SettingsSubScreen.HELP_SUPPORT) },
            testTag = "help_support_btn"
        )
        SettingsRowItem(
            icon = Icons.Default.Info,
            iconTint = TextSecondary,
            title = "About Play Nest",
            subtitle = "Version 1.2.0 • Terms & Privacy",
            onClick = { onNavigate(SettingsSubScreen.ABOUT) },
            testTag = "about_playnest_btn"
        )

        // Section: Account Actions
        SettingsSectionHeader(title = "Account Management")
        SettingsRowItem(
            icon = Icons.Default.SwitchAccount,
            iconTint = PlayNestBlue,
            title = "Switch Account / Sign In",
            subtitle = "Log into another Play Nest profile",
            onClick = onSwitchUser,
            testTag = "switch_account_btn"
        )
        SettingsRowItem(
            icon = Icons.AutoMirrored.Filled.Logout,
            iconTint = PlayNestOrange,
            title = "Log Out",
            subtitle = "Sign out of this device",
            onClick = onLogoutClick,
            testTag = "logout_btn"
        )
        SettingsRowItem(
            icon = Icons.Default.DeleteForever,
            iconTint = Color(0xFFFF4B6E),
            title = "Delete Account",
            subtitle = "Permanently remove your account and data",
            onClick = onDeleteAccountClick,
            testTag = "delete_account_btn"
        )

        Spacer(modifier = Modifier.height(16.dp))
    }
}

/**
 * Account Details Subscreen
 */
@Composable
private fun AccountDetailsView(
    currentUser: User,
    onSendPasswordReset: (String) -> Unit
) {
    val context = LocalContext.current
    var emailSent by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "Your Play Nest Account",
            color = TextSecondary,
            fontSize = 13.sp
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                AccountDetailField(label = "User ID", value = currentUser.id)
                HorizontalDivider(color = DarkBorder, thickness = 0.5.dp)
                AccountDetailField(label = "Username", value = "@${currentUser.username}")
                HorizontalDivider(color = DarkBorder, thickness = 0.5.dp)
                AccountDetailField(label = "Display Name", value = currentUser.displayName)
                HorizontalDivider(color = DarkBorder, thickness = 0.5.dp)
                AccountDetailField(label = "Email Address", value = currentUser.email.ifBlank { "Not provided (Guest)" })
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        if (currentUser.email.isNotBlank()) {
            Button(
                onClick = {
                    onSendPasswordReset(currentUser.email)
                    emailSent = true
                    Toast.makeText(context, "Password reset email sent to ${currentUser.email}", Toast.LENGTH_LONG).show()
                },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(24.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PlayNestPink)
            ) {
                Icon(imageVector = Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (emailSent) "Reset Link Sent!" else "Send Password Reset Email", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun AccountDetailField(label: String, value: String) {
    Column {
        Text(text = label, color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

/**
 * Privacy & Safety Subscreen
 */
@Composable
private fun PrivacySafetyView(
    privacySettings: UserPrivacySettings,
    onUpdatePrivacySettings: (UserPrivacySettings) -> Unit,
    onOpenBlocked: () -> Unit,
    onOpenReports: () -> Unit
) {
    var isPrivate by remember(privacySettings) { mutableStateOf(privacySettings.isPrivateAccount) }
    var allowComments by remember(privacySettings) { mutableStateOf(privacySettings.allowComments) }
    var allowDMs by remember(privacySettings) { mutableStateOf(privacySettings.allowDirectMessages) }
    var allowNotifs by remember(privacySettings) { mutableStateOf(privacySettings.pushNotificationsEnabled) }
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Private Account Toggle Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Private Account", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        "When active, only approved followers can watch your videos and view your profile details.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Switch(
                    checked = isPrivate,
                    onCheckedChange = {
                        isPrivate = it
                        val updated = privacySettings.copy(isPrivateAccount = it)
                        onUpdatePrivacySettings(updated)
                        Toast.makeText(context, if (it) "Account set to Private" else "Account set to Public", Toast.LENGTH_SHORT).show()
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = PlayNestPink,
                        uncheckedTrackColor = DarkBorder
                    )
                )
            }
        }

        // Allow Notifications Toggle Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Allow Notifications", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        "Receive push updates for likes, comments, mentions, and new followers.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Switch(
                    checked = allowNotifs,
                    onCheckedChange = {
                        allowNotifs = it
                        val updated = privacySettings.copy(pushNotificationsEnabled = it)
                        onUpdatePrivacySettings(updated)
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = PlayNestPink,
                        uncheckedTrackColor = DarkBorder
                    )
                )
            }
        }

        // Who can comment
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Who can comment on your videos", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text("Choose who is allowed to leave comments on your published videos.", color = TextSecondary, fontSize = 12.sp)

                PrivacyAudience.values().forEach { audience ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                allowComments = audience
                                onUpdatePrivacySettings(privacySettings.copy(allowComments = audience))
                            }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = allowComments == audience,
                            onClick = {
                                allowComments = audience
                                onUpdatePrivacySettings(privacySettings.copy(allowComments = audience))
                            },
                            colors = RadioButtonDefaults.colors(selectedColor = PlayNestPink)
                        )
                        Text(
                            text = when (audience) {
                                PrivacyAudience.EVERYONE -> "Everyone"
                                PrivacyAudience.FOLLOWERS_ONLY -> "Followers Only"
                                PrivacyAudience.NO_ONE -> "No One"
                            },
                            color = TextPrimary,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // Who can send direct messages
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Who can send you Direct Messages", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text("Control who can initiate private conversations with you.", color = TextSecondary, fontSize = 12.sp)

                PrivacyAudience.values().forEach { audience ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                allowDMs = audience
                                onUpdatePrivacySettings(privacySettings.copy(allowDirectMessages = audience))
                            }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = allowDMs == audience,
                            onClick = {
                                allowDMs = audience
                                onUpdatePrivacySettings(privacySettings.copy(allowDirectMessages = audience))
                            },
                            colors = RadioButtonDefaults.colors(selectedColor = PlayNestPink)
                        )
                        Text(
                            text = when (audience) {
                                PrivacyAudience.EVERYONE -> "Everyone"
                                PrivacyAudience.FOLLOWERS_ONLY -> "Followers Only"
                                PrivacyAudience.NO_ONE -> "No One"
                            },
                            color = TextPrimary,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // Shortcuts
        SettingsRowItem(
            icon = Icons.Default.Block,
            iconTint = PlayNestPink,
            title = "Manage Blocked Accounts",
            subtitle = "View and unblock users",
            onClick = onOpenBlocked
        )
        SettingsRowItem(
            icon = Icons.Default.History,
            iconTint = PlayNestBlue,
            title = "View Report History",
            subtitle = "Check moderation status of submitted reports",
            onClick = onOpenReports
        )

        Spacer(modifier = Modifier.height(16.dp))
    }
}

/**
 * Blocked Accounts Subscreen
 */
@Composable
private fun BlockedAccountsView(
    blockedUsers: List<BlockedUserRecord>,
    onUnblock: (String) -> Unit
) {
    val context = LocalContext.current

    if (blockedUsers.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Block,
                    contentDescription = null,
                    tint = TextMuted,
                    modifier = Modifier.size(48.dp)
                )
                Text("No Blocked Accounts", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(
                    "You haven't blocked anyone. You can block users directly from their profiles or from video share sheets.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 16.sp
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(blockedUsers, key = { it.blockedUserId }) { record ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(DarkSurfaceElevated)
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(DarkBorder)
                    ) {
                        AsyncImage(
                            model = record.blockedAvatarUrl.ifBlank { "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400" },
                            contentDescription = record.blockedUsername,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.size(40.dp).clip(CircleShape)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = record.blockedDisplayName.ifBlank { record.blockedUsername },
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "@${record.blockedUsername}",
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                    }

                    Button(
                        onClick = {
                            onUnblock(record.blockedUserId)
                            Toast.makeText(context, "Unblocked @${record.blockedUsername}", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = DarkBorder)
                    ) {
                        Text("Unblock", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

/**
 * Report History Subscreen
 */
@Composable
private fun ReportHistoryView(reports: List<ContentReport>) {
    if (reports.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = null,
                    tint = TextMuted,
                    modifier = Modifier.size(48.dp)
                )
                Text("No Reports Submitted", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(
                    "You haven't submitted any content or safety reports. Reports help keep Play Nest secure and creative.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 16.sp
                )
            }
        }
    } else {
        val dateFormat = SimpleDateFormat("MMM dd, yyyy • h:mm a", Locale.getDefault())
        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(reports, key = { it.id }) { report ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = report.contentType.name.lowercase().replaceFirstChar { it.uppercase() } + " Report",
                                color = PlayNestPink,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )

                            // Status badge
                            val badgeColor = when (report.status.uppercase()) {
                                "PENDING" -> PlayNestOrange
                                "RESOLVED", "ACTION_TAKEN" -> PlayNestGreen
                                else -> PlayNestBlue
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(badgeColor.copy(alpha = 0.15f))
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = report.status,
                                    color = badgeColor,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Text(
                            text = "Reason: ${report.reason}",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )

                        if (report.targetSummary.isNotBlank()) {
                            Text(
                                text = "Target: ${report.targetSummary}",
                                color = TextSecondary,
                                fontSize = 12.sp,
                                maxLines = 1
                            )
                        }

                        if (report.details.isNotBlank()) {
                            Text(
                                text = "\"${report.details}\"",
                                color = TextMuted,
                                fontSize = 12.sp,
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                            )
                        }

                        Text(
                            text = dateFormat.format(Date(report.timestamp)),
                            color = TextMuted,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }
}

/**
 * Help & Support Subscreen
 */
@Composable
private fun HelpSupportView() {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Play Nest Community Safety Guidelines", color = PlayNestPink, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Play Nest is committed to fostering a fun, authentic, and secure platform for all creators and viewers. We maintain a zero-tolerance policy against:",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
                Text("• Harassment, cyberbullying, or hate speech targeting any individual or group.", color = TextPrimary, fontSize = 12.sp)
                Text("• Explicit adult sexual content, nudity, or exploitation.", color = TextPrimary, fontSize = 12.sp)
                Text("• Violent, graphic, dangerous, or illegal activities.", color = TextPrimary, fontSize = 12.sp)
                Text("• Fraud, financial scams, spam, or misleading impersonation.", color = TextPrimary, fontSize = 12.sp)
                Text("• Intellectual property and copyright infringement.", color = TextPrimary, fontSize = 12.sp)
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("How Reporting Works", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text(
                    "When you report a video, comment, profile, or message, it is prioritized by our automated Trust & Safety filters and human moderators. Content violating our standards is swiftly removed, and repetitive offenders face permanent suspension.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
            }
        }

        Button(
            onClick = {
                Toast.makeText(context, "Support ticket opened: support@playnest.app", Toast.LENGTH_LONG).show()
            },
            modifier = Modifier.fillMaxWidth().height(46.dp),
            shape = RoundedCornerShape(23.dp),
            colors = ButtonDefaults.buttonColors(containerColor = PlayNestPink)
        ) {
            Icon(imageVector = Icons.Default.Email, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Contact Trust & Safety Support", fontWeight = FontWeight.Bold)
        }
    }
}

/**
 * About Subscreen
 */
@Composable
private fun AboutPlayNestView() {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(scrollState),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))
        PlayNestLogoBadge(iconSize = 36.dp, showText = true)
        Text(
            text = "Version 1.2.0 (Build 2026.09)",
            color = TextMuted,
            fontSize = 12.sp
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Terms of Service", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text(
                    "By using Play Nest, you agree to respect copyright owners, adhere to community safety guidelines, and refrain from malicious activities.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text("Privacy Policy", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Your personal data is encrypted in transit and stored safely in Google Cloud Firestore. We never sell your personal data to third parties.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

/**
 * Delete Account Confirmation Dialog with Permanent Warning & Password Reauth
 */
@Composable
private fun DeleteAccountConfirmationDialog(
    currentUser: User,
    onDismiss: () -> Unit,
    onConfirmDelete: (password: String?, callback: (Result<Unit>) -> Unit) -> Unit
) {
    val context = LocalContext.current
    var passwordInput by remember { mutableStateOf("") }
    var isDeleting by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = { if (!isDeleting) onDismiss() },
        containerColor = DarkSurfaceElevated,
        icon = {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFF4B6E).copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = Color(0xFFFF4B6E),
                    modifier = Modifier.size(28.dp)
                )
            }
        },
        title = {
            Text(
                text = "Delete Account Permanently?",
                color = TextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "This action is permanent and CANNOT be undone.",
                    color = Color(0xFFFF4B6E),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Deleting your account will:\n• Permanently delete your user profile (@${currentUser.username}).\n• Remove your owned videos and comments.\n• Erase your privacy settings and blocked lists.\n• Sign you out immediately.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )

                if (currentUser.email.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Enter your current password to confirm:",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = { passwordInput = it },
                        placeholder = { Text("Password", color = TextMuted, fontSize = 13.sp) },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth().testTag("delete_account_password_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = DarkSurface,
                            unfocusedContainerColor = DarkSurface,
                            focusedBorderColor = Color(0xFFFF4B6E),
                            unfocusedBorderColor = DarkBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        singleLine = true
                    )
                }

                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = Color(0xFFFF4B6E),
                        fontSize = 12.sp
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    isDeleting = true
                    errorMessage = null
                    onConfirmDelete(passwordInput.ifBlank { null }) { result ->
                        isDeleting = false
                        if (result.isSuccess) {
                            Toast.makeText(context, "Account permanently deleted. Goodbye.", Toast.LENGTH_LONG).show()
                        } else {
                            errorMessage = result.exceptionOrNull()?.message ?: "Account deletion failed. Please verify your password."
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4B6E)),
                enabled = !isDeleting && (currentUser.email.isBlank() || passwordInput.isNotBlank()),
                modifier = Modifier.testTag("confirm_delete_account_btn")
            ) {
                if (isDeleting) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                } else {
                    Text("Delete Forever", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !isDeleting) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}

/**
 * Reusable Settings Row Item
 */
@Composable
private fun SettingsRowItem(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    subtitle: String,
    badge: String? = null,
    onClick: () -> Unit,
    testTag: String = ""
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(DarkSurfaceElevated)
            .clickable { onClick() }
            .padding(12.dp)
            .then(if (testTag.isNotBlank()) Modifier.testTag(testTag) else Modifier),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(iconTint.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(18.dp)
            )
        }

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = subtitle,
                color = TextSecondary,
                fontSize = 12.sp
            )
        }

        if (badge != null) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(PlayNestPink.copy(alpha = 0.2f))
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    text = badge,
                    color = PlayNestPink,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
            contentDescription = null,
            tint = TextMuted,
            modifier = Modifier.size(12.dp)
        )
    }
}

@Composable
private fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        color = TextMuted,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 4.dp, top = 4.dp)
    )
}
