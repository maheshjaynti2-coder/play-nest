package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.model.Video
import com.example.ui.components.CreatorAvatarWithFollow
import com.example.ui.components.PlayNestLogoBadge
import com.example.ui.components.SpinningVinyl
import com.example.ui.components.VideoPlayerView
import com.example.ui.theme.PlayNestBlue
import com.example.ui.theme.PlayNestGreen
import com.example.ui.theme.PlayNestPink
import com.example.ui.theme.PlayNestPrimaryGradient
import com.example.ui.theme.PlayNestYellow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.PlayNestVideoPlayerManager

@Composable
fun HomeScreen(
    videos: List<Video>,
    currentFeedIndex: Int,
    isGlobalMuted: Boolean,
    onFeedIndexChanged: (Int) -> Unit,
    onToggleMute: () -> Unit,
    onLikeVideo: (Video) -> Unit,
    onSaveVideo: (Video) -> Unit,
    onFollowCreator: (String) -> Unit,
    onOpenComments: (Video) -> Unit,
    onOpenShare: (Video) -> Unit,
    onCreatorClick: (String) -> Unit = {},
    isFeedActive: Boolean = true,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val isUserPaused by PlayNestVideoPlayerManager.isUserPaused.collectAsState()

    var selectedTopTab by remember { mutableIntStateOf(1) } // 0 = Following, 1 = For You

    val displayedVideos = remember(videos, selectedTopTab) {
        if (selectedTopTab == 0) {
            val followingList = videos.filter { it.isFollowingCreator }
            if (followingList.isEmpty()) videos else followingList
        } else {
            videos
        }
    }

    val pagerState = rememberPagerState(
        initialPage = currentFeedIndex.coerceIn(0, (displayedVideos.size - 1).coerceAtLeast(0)),
        pageCount = { displayedVideos.size }
    )

    // Handle Android lifecycle (pause when app is backgrounded, resume when foregrounded)
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE, Lifecycle.Event.ON_STOP -> {
                    PlayNestVideoPlayerManager.onAppBackgrounded()
                }
                Lifecycle.Event.ON_RESUME -> {
                    if (isFeedActive) {
                        PlayNestVideoPlayerManager.onAppForegrounded()
                    }
                }
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            PlayNestVideoPlayerManager.pause()
        }
    }

    // Handle tab or modal visibility changes
    LaunchedEffect(isFeedActive) {
        PlayNestVideoPlayerManager.onFeedVisibilityChanged(isFeedActive)
    }

    // Feed index change reporting
    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.currentPage }.collect { page ->
            onFeedIndexChanged(page)
        }
    }

    // Preload next adjacent video for instant swipe transitions
    LaunchedEffect(pagerState.currentPage, displayedVideos) {
        val nextVideo = displayedVideos.getOrNull(pagerState.currentPage + 1)
        PlayNestVideoPlayerManager.preloadNextVideo(context, nextVideo)
    }

    // External jump to video index (e.g. from Discover or Deep Link)
    LaunchedEffect(currentFeedIndex) {
        if (currentFeedIndex in displayedVideos.indices && pagerState.currentPage != currentFeedIndex) {
            pagerState.scrollToPage(currentFeedIndex)
        }
    }

    Box(modifier = modifier.fillMaxSize().background(Color.Black)) {
        if (displayedVideos.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No videos available yet",
                    color = Color.White,
                    fontSize = 16.sp
                )
            }
        } else {
            VerticalPager(
                state = pagerState,
                beyondViewportPageCount = 1,
                modifier = Modifier.fillMaxSize(),
                key = { page -> displayedVideos.getOrNull(page)?.id ?: page.toString() }
            ) { page ->
                val video = displayedVideos[page]
                val isCurrent = pagerState.currentPage == page

                Box(modifier = Modifier.fillMaxSize()) {
                    // Fullscreen Video Player
                    VideoPlayerView(
                        video = video,
                        isCurrentPage = isCurrent && isFeedActive,
                        isMuted = isGlobalMuted,
                        onDoubleTapLike = {
                            if (!video.isLiked) onLikeVideo(video)
                        },
                        onToggleMute = onToggleMute,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Right Side Action Bar
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(end = 12.dp, bottom = 86.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Creator Avatar with Follow '+' button
                        CreatorAvatarWithFollow(
                            avatarUrl = video.creatorAvatarUrl,
                            isFollowing = video.isFollowingCreator,
                            onFollowClick = { onFollowCreator(video.creatorId) },
                            onAvatarClick = { onCreatorClick(video.creatorId) }
                        )

                        // Like Action
                        VideoActionItem(
                            icon = if (video.isLiked) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                            label = formatCount(video.likesCount),
                            tint = if (video.isLiked) PlayNestPink else Color.White,
                            isHighlighted = video.isLiked,
                            onClick = { onLikeVideo(video) },
                            testTag = "like_video_button"
                        )

                        // Comments Action
                        VideoActionItem(
                            icon = Icons.Default.ChatBubble,
                            label = formatCount(video.commentsCount),
                            tint = Color.White,
                            onClick = { onOpenComments(video) },
                            testTag = "comments_video_button"
                        )

                        // Save / Bookmark Action
                        VideoActionItem(
                            icon = if (video.isSaved) Icons.Default.Bookmark else Icons.Outlined.BookmarkBorder,
                            label = formatCount(video.savesCount),
                            tint = if (video.isSaved) PlayNestYellow else Color.White,
                            isHighlighted = video.isSaved,
                            onClick = { onSaveVideo(video) },
                            testTag = "save_video_button"
                        )

                        // Share Action
                        VideoActionItem(
                            icon = Icons.Default.Share,
                            label = formatCount(video.sharesCount),
                            tint = Color.White,
                            onClick = { onOpenShare(video) },
                            testTag = "share_video_button"
                        )

                        // Spinning Vinyl Disc (stops spinning when paused)
                        SpinningVinyl(
                            albumArtUrl = video.creatorAvatarUrl,
                            isPlaying = isCurrent && !isUserPaused && isFeedActive
                        )
                    }

                    // Bottom Left Video Details
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .fillMaxWidth(0.78f)
                            .padding(start = 16.dp, bottom = 86.dp)
                    ) {
                        // Creator Handle & Verified Badge
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.clickable { onCreatorClick(video.creatorId) }
                        ) {
                            Text(
                                text = "@${video.creatorUsername}",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (video.isCreatorVerified) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Verified Creator",
                                    tint = PlayNestBlue,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        // Optional Location Badge
                        if (video.location.isNotBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.Black.copy(alpha = 0.45f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LocationOn,
                                    contentDescription = "Location",
                                    tint = PlayNestPink,
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = video.location,
                                    color = Color.White.copy(alpha = 0.9f),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Caption
                        Text(
                            text = video.caption,
                            color = Color.White,
                            fontSize = 14.sp,
                            lineHeight = 18.sp,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )

                        // Hashtags
                        if (video.hashtags.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                video.hashtags.take(3).forEach { tag ->
                                    Text(
                                        text = tag,
                                        color = PlayNestGreen,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Music Track Marquee Row
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.Black.copy(alpha = 0.35f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.MusicNote,
                                contentDescription = null,
                                tint = PlayNestPink,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "${video.musicTitle} • ${video.musicArtist}",
                                color = Color.White.copy(alpha = 0.9f),
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        // Top Navigation Header (Following | For You + Brand Logo)
        Row(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            PlayNestLogoBadge(iconSize = 30.dp, showText = true)

            // Feeds Tab Toggle
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Following",
                    color = if (selectedTopTab == 0) Color.White else Color.White.copy(alpha = 0.6f),
                    fontSize = 16.sp,
                    fontWeight = if (selectedTopTab == 0) FontWeight.Bold else FontWeight.Medium,
                    modifier = Modifier
                        .clickable { selectedTopTab = 0 }
                        .padding(4.dp)
                )

                Text(
                    text = "For You",
                    color = if (selectedTopTab == 1) Color.White else Color.White.copy(alpha = 0.6f),
                    fontSize = 17.sp,
                    fontWeight = if (selectedTopTab == 1) FontWeight.Black else FontWeight.Medium,
                    modifier = Modifier
                        .clickable { selectedTopTab = 1 }
                        .padding(4.dp)
                )
            }
        }
    }
}

@Composable
fun VideoActionItem(
    icon: ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isHighlighted: Boolean = false,
    testTag: String = ""
) {
    val scaleAnim by animateColorAsState(
        targetValue = tint,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "colorAnim"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clickable { onClick() }
            .testTag(testTag)
            .padding(vertical = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.45f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = tint,
                modifier = Modifier.size(28.dp)
            )
        }
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = label,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

private fun formatCount(count: Long): String {
    return when {
        count >= 1_000_000 -> String.format("%.1fM", count / 1_000_000.0)
        count >= 1_000 -> String.format("%.1fK", count / 1_000.0)
        else -> count.toString()
    }
}
