package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.SoundTrack
import com.example.ui.components.PlayNestLogoBadge
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.PlayNestBlue
import com.example.ui.theme.PlayNestGreen
import com.example.ui.theme.PlayNestPink
import com.example.ui.theme.PlayNestPrimaryGradient
import com.example.ui.theme.PlayNestYellow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.VideoUploadState
import com.example.util.VideoMediaHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CreateScreen(
    selectedSound: SoundTrack?,
    uploadState: VideoUploadState = VideoUploadState.Idle,
    onOpenSoundSelector: () -> Unit,
    onCancelUpload: () -> Unit = {},
    onResetUploadState: () -> Unit = {},
    onPublish: (
        caption: String,
        hashtags: List<String>,
        location: String,
        videoUri: String,
        thumbnailUri: String,
        category: String,
        trimStartMs: Long,
        trimEndMs: Long
    ) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Form states
    var captionText by remember { mutableStateOf("") }
    var locationText by remember { mutableStateOf("") }
    var customTagInput by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Music") }

    // Media states
    var selectedVideoUri by remember { mutableStateOf<Uri?>(null) }
    var selectedThumbnailUri by remember { mutableStateOf<Uri?>(null) }
    var tempCameraVideoUri by remember { mutableStateOf<Uri?>(null) }
    var videoDurationMs by remember { mutableLongStateOf(0L) }

    // Trim states (in milliseconds)
    var trimStartMs by remember { mutableFloatStateOf(0f) }
    var trimEndMs by remember { mutableFloatStateOf(0f) }
    var isTrimmingExpanded by remember { mutableStateOf(false) }

    // Preview Player states
    var isPreviewPlaying by remember { mutableStateOf(true) }
    var isPreviewMuted by remember { mutableStateOf(false) }
    var videoViewRef by remember { mutableStateOf<VideoView?>(null) }

    // Permission dialog state
    var showPermissionDeniedDialog by remember { mutableStateOf(false) }
    var permissionDeniedMessage by remember { mutableStateOf("") }

    val hashtagsList = remember { mutableStateListOf<String>() }
    val quickHashtags = listOf("#PlayNestBeat", "#Viral", "#Dance", "#Trending", "#StreetStyle", "#Shorts", "#MusicProducer")
    val quickLocations = listOf("Play Nest Studio", "Los Angeles, CA", "New York, NY", "Tokyo, Japan", "London, UK")
    val categories = listOf("Music", "Gaming", "Fashion", "Comedy", "Travel", "Sports", "Dance", "Tech")
    val emojis = listOf("✨", "🔥", "🎬", "🚀", "🎧", "⚡", "💃", "🌟", "🎉")

    // Camera Video Capture Launcher
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CaptureVideo()
    ) { success ->
        if (success && tempCameraVideoUri != null) {
            val uri = tempCameraVideoUri!!
            coroutineScope.launch {
                val dur = withContext(Dispatchers.IO) {
                    VideoMediaHelper.getVideoDurationMs(context, uri)
                }
                selectedVideoUri = uri
                videoDurationMs = if (dur > 0L) dur else 15000L
                trimStartMs = 0f
                trimEndMs = videoDurationMs.toFloat()

                // Extract default cover frame
                val frameBitmap = withContext(Dispatchers.IO) {
                    VideoMediaHelper.extractVideoFrame(context, uri, 500L)
                }
                if (frameBitmap != null) {
                    val saved = withContext(Dispatchers.IO) {
                        VideoMediaHelper.saveBitmapToFile(context, frameBitmap, "camera_cover")
                    }
                    if (saved.isNotBlank()) {
                        selectedThumbnailUri = Uri.parse(saved)
                    }
                }
            }
            Toast.makeText(context, "Video recorded successfully!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Video recording cancelled", Toast.LENGTH_SHORT).show()
        }
    }

    fun launchCameraDirectly() {
        try {
            val dir = File(context.cacheDir, "camera_videos").apply { mkdirs() }
            val videoFile = File(dir, "clip_${System.currentTimeMillis()}.mp4")
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                videoFile
            )
            tempCameraVideoUri = uri
            cameraLauncher.launch(uri)
        } catch (e: Exception) {
            Toast.makeText(context, "Could not start camera: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // Permission launcher for Camera & Record Audio
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val cameraGranted = permissions[Manifest.permission.CAMERA] == true
        val audioGranted = permissions[Manifest.permission.RECORD_AUDIO] == true
        if (cameraGranted && audioGranted) {
            launchCameraDirectly()
        } else {
            permissionDeniedMessage = "Camera and microphone permissions are required to record videos. You can grant permissions in device settings, or choose an existing video from your gallery."
            showPermissionDeniedDialog = true
        }
    }

    // Video Picker from Gallery (Modern Photo Picker)
    val galleryVideoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                val dur = withContext(Dispatchers.IO) {
                    VideoMediaHelper.getVideoDurationMs(context, uri)
                }
                selectedVideoUri = uri
                videoDurationMs = if (dur > 0L) dur else 30000L
                trimStartMs = 0f
                trimEndMs = videoDurationMs.toFloat()

                // Generate automatic cover thumbnail from video
                val frameBitmap = withContext(Dispatchers.IO) {
                    VideoMediaHelper.extractVideoFrame(context, uri, 1000L)
                }
                if (frameBitmap != null) {
                    val thumbPath = withContext(Dispatchers.IO) {
                        VideoMediaHelper.saveBitmapToFile(context, frameBitmap, "cover")
                    }
                    if (thumbPath.isNotBlank()) {
                        selectedThumbnailUri = Uri.parse(thumbPath)
                    }
                }
            }
            Toast.makeText(context, "Video selected from gallery", Toast.LENGTH_SHORT).show()
        }
    }

    // Fallback Gallery Picker
    val fallbackVideoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                val dur = withContext(Dispatchers.IO) {
                    VideoMediaHelper.getVideoDurationMs(context, uri)
                }
                selectedVideoUri = uri
                videoDurationMs = if (dur > 0L) dur else 30000L
                trimStartMs = 0f
                trimEndMs = videoDurationMs.toFloat()

                val frameBitmap = withContext(Dispatchers.IO) {
                    VideoMediaHelper.extractVideoFrame(context, uri, 1000L)
                }
                if (frameBitmap != null) {
                    val thumbPath = withContext(Dispatchers.IO) {
                        VideoMediaHelper.saveBitmapToFile(context, frameBitmap, "cover")
                    }
                    if (thumbPath.isNotBlank()) {
                        selectedThumbnailUri = Uri.parse(thumbPath)
                    }
                }
            }
            Toast.makeText(context, "Video selected", Toast.LENGTH_SHORT).show()
        }
    }

    // Thumbnail / Cover Picker from Photos
    val thumbnailPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedThumbnailUri = uri
            Toast.makeText(context, "Custom cover selected", Toast.LENGTH_SHORT).show()
        }
    }

    fun handleRecordClick() {
        val cameraGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val audioGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

        if (cameraGranted && audioGranted) {
            launchCameraDirectly()
        } else {
            permissionLauncher.launch(
                arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            )
        }
    }

    fun handleGalleryClick() {
        try {
            galleryVideoPickerLauncher.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
            )
        } catch (_: Exception) {
            fallbackVideoPickerLauncher.launch("video/*")
        }
    }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .verticalScroll(scrollState)
            .padding(horizontal = 18.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Create Short",
                    color = TextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "Record or import high-quality clips",
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }
            PlayNestLogoBadge()
        }

        // VIDEO SELECTOR / PREVIEW SECTION
        if (selectedVideoUri == null) {
            // Options: 1. Record Video with Camera, 2. Choose Video from Gallery
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("video_source_selection_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Choose Video Source",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Option 1: Record Video with Camera
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(130.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(DarkSurface)
                                .border(1.dp, PlayNestPink.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                                .clickable { handleRecordClick() }
                                .padding(12.dp)
                                .testTag("record_camera_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(PlayNestPink.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Videocam,
                                        contentDescription = "Record Video",
                                        tint = PlayNestPink,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Record Video",
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "With Camera",
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        // Option 2: Choose Video from Gallery
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(130.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(DarkSurface)
                                .border(1.dp, PlayNestBlue.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                                .clickable { handleGalleryClick() }
                                .padding(12.dp)
                                .testTag("choose_gallery_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(PlayNestBlue.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CloudUpload,
                                        contentDescription = "Choose Video",
                                        tint = PlayNestBlue,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Choose Video",
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "From Gallery",
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    // Guidance pill
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.Black.copy(alpha = 0.3f))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "💡 Tip: 9:16 vertical short videos look best on Play Nest feeds",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        } else {
            // VIDEO PREVIEW PLAYER
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("video_preview_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Black)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp)
                            .background(Color.Black)
                    ) {
                        // Native VideoView playback preview
                        AndroidView(
                            factory = { ctx ->
                                VideoView(ctx).apply {
                                    setVideoURI(selectedVideoUri)
                                    setOnPreparedListener { mp ->
                                        mp.isLooping = true
                                        val vol = if (isPreviewMuted) 0f else 1f
                                        mp.setVolume(vol, vol)
                                        if (trimStartMs > 0) {
                                            seekTo(trimStartMs.toInt())
                                        }
                                        start()
                                        isPreviewPlaying = true
                                    }
                                    setOnCompletionListener {
                                        if (trimStartMs > 0) {
                                            seekTo(trimStartMs.toInt())
                                        }
                                        start()
                                    }
                                    videoViewRef = this
                                }
                            },
                            update = { view ->
                                videoViewRef = view
                            },
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                        )

                        // Top controls overlay
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Duration badge
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.Black.copy(alpha = 0.6f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "Duration: ${VideoMediaHelper.formatDurationMs(videoDurationMs)}",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Actions: Replace / Remove
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                IconButton(
                                    onClick = {
                                        isPreviewMuted = !isPreviewMuted
                                        videoViewRef?.let {
                                            // VideoView doesn't expose direct volume, handled during prepare
                                        }
                                    },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.6f))
                                ) {
                                    Icon(
                                        imageVector = if (isPreviewMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                                        contentDescription = "Toggle Mute",
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        selectedVideoUri = null
                                        selectedThumbnailUri = null
                                        videoDurationMs = 0L
                                        trimStartMs = 0f
                                        trimEndMs = 0f
                                        isTrimmingExpanded = false
                                    },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.6f))
                                        .testTag("remove_video_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Remove Video",
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        // Center Play / Pause button overlay
                        Box(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.45f))
                                .clickable {
                                    videoViewRef?.let { view ->
                                        if (view.isPlaying) {
                                            view.pause()
                                            isPreviewPlaying = false
                                        } else {
                                            view.start()
                                            isPreviewPlaying = true
                                        }
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isPreviewPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPreviewPlaying) "Pause" else "Play",
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }

                    // Bottom Preview Status Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DarkSurfaceElevated)
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = PlayNestGreen,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Video Loaded & Ready",
                                color = TextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            // Re-record / Change
                            TextButton(
                                onClick = { handleRecordClick() },
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("Re-record", color = PlayNestPink, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            TextButton(
                                onClick = { handleGalleryClick() },
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("Change", color = PlayNestBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // BASIC VIDEO TRIMMING SECTION
            if (videoDurationMs > 3000L) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("video_trimming_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { isTrimmingExpanded = !isTrimmingExpanded },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCut,
                                    contentDescription = "Trim Video",
                                    tint = PlayNestYellow,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "Trim Video",
                                    color = TextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Text(
                                text = "${VideoMediaHelper.formatDurationMs(trimStartMs.toLong())} - ${VideoMediaHelper.formatDurationMs(trimEndMs.toLong())} (${VideoMediaHelper.formatDurationMs((trimEndMs - trimStartMs).toLong())})",
                                color = PlayNestYellow,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        if (isTrimmingExpanded) {
                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = "Adjust start and end timestamps:",
                                color = TextMuted,
                                fontSize = 11.sp
                            )

                            // Dual Range Slider for trimming
                            RangeSlider(
                                value = trimStartMs..trimEndMs,
                                onValueChange = { range ->
                                    trimStartMs = range.start
                                    trimEndMs = range.endInclusive
                                    videoViewRef?.seekTo(trimStartMs.toInt())
                                },
                                valueRange = 0f..videoDurationMs.toFloat(),
                                colors = SliderDefaults.colors(
                                    thumbColor = PlayNestPink,
                                    activeTrackColor = PlayNestPink,
                                    inactiveTrackColor = DarkBorder
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("trim_range_slider")
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        videoViewRef?.let { view ->
                                            view.seekTo(trimStartMs.toInt())
                                            view.start()
                                            isPreviewPlaying = true
                                        }
                                    },
                                    modifier = Modifier.height(34.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp),
                                        tint = TextPrimary
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Preview Trim", fontSize = 11.sp, color = TextPrimary)
                                }

                                TextButton(
                                    onClick = {
                                        trimStartMs = 0f
                                        trimEndMs = videoDurationMs.toFloat()
                                        videoViewRef?.seekTo(0)
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp),
                                        tint = TextMuted
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Reset Full Length", fontSize = 11.sp, color = TextMuted)
                                }
                            }
                        }
                    }
                }
            }

            // THUMBNAIL / COVER SELECTION CARD
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("cover_selection_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Cover Preview Box
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(DarkSurface)
                            .border(1.dp, DarkBorder, RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (selectedThumbnailUri != null) {
                            AsyncImage(
                                model = selectedThumbnailUri,
                                contentDescription = "Video Cover Thumbnail",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.AddPhotoAlternate,
                                contentDescription = null,
                                tint = TextMuted,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Video Cover Thumbnail",
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (selectedThumbnailUri != null) "Cover selected for feed" else "Auto-generated from first frame",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }

                    // Button to change cover
                    OutlinedButton(
                        onClick = {
                            thumbnailPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier.height(34.dp),
                        shape = RoundedCornerShape(17.dp)
                    ) {
                        Text("Custom Cover", fontSize = 11.sp, color = PlayNestYellow)
                    }
                }
            }
        }

        // SOUND / MUSIC SELECTOR
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(DarkSurfaceElevated)
                .clickable { onOpenSoundSelector() }
                .padding(horizontal = 14.dp, vertical = 12.dp)
                .testTag("create_sound_selector_row"),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(PlayNestPrimaryGradient),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = selectedSound?.title ?: "Add Sound / Soundtrack",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = selectedSound?.artist ?: "Select trending beats or use original audio",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }

            Text(
                text = if (selectedSound != null) "Change" else "Select",
                color = PlayNestPink,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // CAPTION INPUT FIELD
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Caption",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "${captionText.length}/300",
                    color = if (captionText.length > 280) PlayNestPink else TextMuted,
                    fontSize = 11.sp
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = captionText,
                onValueChange = { if (it.length <= 300) captionText = it },
                placeholder = {
                    Text("Write a compelling caption for your video...", color = TextMuted, fontSize = 13.sp)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(95.dp)
                    .testTag("create_caption_input"),
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = DarkSurfaceElevated,
                    unfocusedContainerColor = DarkSurfaceElevated,
                    focusedBorderColor = PlayNestPink,
                    unfocusedBorderColor = DarkBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )

            // Emoji quick bar
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(emojis) { emoji ->
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(DarkSurfaceElevated)
                            .clickable {
                                if (captionText.length + emoji.length <= 300) {
                                    captionText += " $emoji"
                                }
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(text = emoji, fontSize = 14.sp)
                    }
                }
            }
        }

        // HASHTAGS SECTION
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "Hashtags",
                color = TextSecondary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Trending Chips
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                quickHashtags.forEach { tag ->
                    val isAdded = hashtagsList.contains(tag)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isAdded) PlayNestPink else DarkSurfaceElevated)
                            .clickable {
                                if (isAdded) {
                                    hashtagsList.remove(tag)
                                } else {
                                    hashtagsList.add(tag)
                                }
                            }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = tag,
                            color = if (isAdded) Color.White else TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Custom hashtag input
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = customTagInput,
                    onValueChange = { customTagInput = it },
                    placeholder = { Text("Add custom tag (e.g. #creative)", color = TextMuted, fontSize = 12.sp) },
                    modifier = Modifier.weight(1f).height(48.dp),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = DarkSurfaceElevated,
                        unfocusedContainerColor = DarkSurfaceElevated,
                        focusedBorderColor = PlayNestPink,
                        unfocusedBorderColor = DarkBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Button(
                    onClick = {
                        val clean = customTagInput.trim()
                        if (clean.isNotBlank()) {
                            val tag = if (clean.startsWith("#")) clean else "#$clean"
                            if (!hashtagsList.contains(tag)) {
                                hashtagsList.add(tag)
                            }
                            customTagInput = ""
                        }
                    },
                    modifier = Modifier.height(48.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Tag",
                        tint = TextPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        // OPTIONAL LOCATION FIELD
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "Location (Optional)",
                color = TextSecondary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = locationText,
                onValueChange = { locationText = it },
                placeholder = { Text("e.g. Los Angeles, CA or Studio", color = TextMuted, fontSize = 12.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "Location",
                        tint = PlayNestPink,
                        modifier = Modifier.size(18.dp)
                    )
                },
                trailingIcon = {
                    if (locationText.isNotBlank()) {
                        IconButton(onClick = { locationText = "" }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Clear", tint = TextMuted, modifier = Modifier.size(16.dp))
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("create_location_input"),
                shape = RoundedCornerShape(16.dp),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = DarkSurfaceElevated,
                    unfocusedContainerColor = DarkSurfaceElevated,
                    focusedBorderColor = PlayNestPink,
                    unfocusedBorderColor = DarkBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )

            // Quick location suggestions
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(quickLocations) { loc ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(DarkSurfaceElevated)
                            .clickable { locationText = loc }
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = "📍 $loc",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // CATEGORY SELECTION
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "Select Category",
                color = TextSecondary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categories) { cat ->
                    val isSelected = selectedCategory == cat
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .then(
                                if (isSelected) Modifier.background(PlayNestPrimaryGradient)
                                else Modifier.background(DarkSurfaceElevated)
                            )
                            .clickable { selectedCategory = cat }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = cat,
                            color = if (isSelected) Color.White else TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // CLEAR "POST VIDEO" BUTTON
        Button(
            onClick = {
                // Validation: Check that a video is selected
                if (selectedVideoUri == null) {
                    Toast.makeText(context, "⚠️ Please record or choose a video first.", Toast.LENGTH_LONG).show()
                    return@Button
                }

                val finalCaption = captionText.ifBlank { "Check out my new video on Play Nest! ✨" }
                val videoUrl = selectedVideoUri.toString()
                val thumbUrl = selectedThumbnailUri?.toString() ?: ""

                onPublish(
                    finalCaption,
                    hashtagsList.toList(),
                    locationText.trim(),
                    videoUrl,
                    thumbUrl,
                    selectedCategory,
                    trimStartMs.toLong(),
                    trimEndMs.toLong()
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("post_video_button"),
            shape = RoundedCornerShape(27.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            contentPadding = androidx.compose.foundation.layout.PaddingValues()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(PlayNestPrimaryGradient),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CloudUpload,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "Post Video",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(90.dp))
    }

    // UPLOAD PROGRESS OVERLAY MODAL
    if (uploadState is VideoUploadState.Uploading) {
        Dialog(
            onDismissRequest = { /* Cannot dismiss without cancel */ },
            properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = DarkSurfaceElevated,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .testTag("upload_progress_dialog")
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    PlayNestLogoBadge()

                    Text(
                        text = "Posting to Play Nest",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )

                    // Linear progress bar
                    LinearProgressIndicator(
                        progress = { uploadState.progress.coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = PlayNestPink,
                        trackColor = DarkBorder
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = uploadState.statusMessage,
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                        Text(
                            text = "${(uploadState.progress * 100).toInt()}%",
                            color = PlayNestPink,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedButton(
                        onClick = { onCancelUpload() },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Cancel Upload", color = TextMuted)
                    }
                }
            }
        }
    }

    // ERROR DIALOG
    if (uploadState is VideoUploadState.Error) {
        AlertDialog(
            onDismissRequest = { onResetUploadState() },
            title = {
                Text("Video Upload Failed", color = TextPrimary, fontWeight = FontWeight.Bold)
            },
            text = {
                Text(uploadState.errorMessage, color = TextSecondary, fontSize = 14.sp)
            },
            confirmButton = {
                Button(
                    onClick = { onResetUploadState() },
                    colors = ButtonDefaults.buttonColors(containerColor = PlayNestPink)
                ) {
                    Text("OK", color = Color.White)
                }
            },
            containerColor = DarkSurfaceElevated
        )
    }

    // PERMISSION DENIED DIALOG
    if (showPermissionDeniedDialog) {
        AlertDialog(
            onDismissRequest = { showPermissionDeniedDialog = false },
            title = {
                Text(
                    text = "Camera & Audio Access Needed",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = permissionDeniedMessage,
                    color = TextSecondary,
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showPermissionDeniedDialog = false
                        handleGalleryClick()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PlayNestBlue)
                ) {
                    Text("Choose from Gallery", color = Color.White)
                }
            },
            dismissButton = {
                Row {
                    TextButton(
                        onClick = {
                            showPermissionDeniedDialog = false
                            try {
                                val intent = Intent(
                                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.fromParts("package", context.packageName, null)
                                )
                                context.startActivity(intent)
                            } catch (_: Exception) {}
                        }
                    ) {
                        Text("Settings", color = TextMuted)
                    }
                    TextButton(onClick = { showPermissionDeniedDialog = false }) {
                        Text("Dismiss", color = TextMuted)
                    }
                }
            },
            containerColor = DarkSurfaceElevated
        )
    }
}
