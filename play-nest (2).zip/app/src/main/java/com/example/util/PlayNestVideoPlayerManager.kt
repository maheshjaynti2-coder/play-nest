package com.example.util

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.util.Log
import android.view.Surface
import com.example.data.model.Video
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * High-performance Video Player Manager for the Play Nest vertical short-video feed.
 *
 * Responsibilities:
 * 1. Single active player enforcement: Prevents concurrent decoders/audio overlapping.
 * 2. Next-video preloading: Prepares the adjacent video for instant playback when swiping.
 * 3. Lifecycle awareness: Pauses on background/tab navigation, resumes on return.
 * 4. Error tolerance: Graceful failure handling for broken URLs with retry capability.
 * 5. State synchronization: Buffering indicators, progress tracking, and global mute memory.
 */
object PlayNestVideoPlayerManager {
    private const val TAG = "PlayNestPlayerMgr"

    private val scope = CoroutineScope(Dispatchers.Main)
    private var progressJob: Job? = null

    // Player instances
    private var activePlayer: MediaPlayer? = null
    private var preloadPlayer: MediaPlayer? = null
    private var currentSurface: Surface? = null
    private var currentContext: Context? = null
    private var currentVideo: Video? = null
    private var preloadedVideo: Video? = null

    // State flows
    private val _currentPlayingVideoId = MutableStateFlow<String?>(null)
    val currentPlayingVideoId: StateFlow<String?> = _currentPlayingVideoId.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isBuffering = MutableStateFlow(false)
    val isBuffering: StateFlow<Boolean> = _isBuffering.asStateFlow()

    private val _isUserPaused = MutableStateFlow(false)
    val isUserPaused: StateFlow<Boolean> = _isUserPaused.asStateFlow()

    private val _hasError = MutableStateFlow(false)
    val hasError: StateFlow<Boolean> = _hasError.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _playbackProgress = MutableStateFlow(0f)
    val playbackProgress: StateFlow<Float> = _playbackProgress.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    // Internal flags
    private var isPrepared = false
    private var wasPlayingBeforeBackground = false
    private var isFeedVisible = true

    /**
     * Set the rendering surface for the active video.
     */
    fun setSurface(surface: Surface?) {
        currentSurface = surface
        try {
            activePlayer?.setSurface(surface)
        } catch (e: Exception) {
            Log.w(TAG, "Error setting surface on active player: ${e.message}")
        }
    }

    /**
     * Clear the rendering surface.
     */
    fun clearSurface() {
        currentSurface = null
        try {
            activePlayer?.setSurface(null)
        } catch (e: Exception) {
            Log.w(TAG, "Error clearing surface: ${e.message}")
        }
    }

    /**
     * Request playback for a given video in the feed.
     */
    fun playVideo(
        context: Context,
        video: Video,
        muted: Boolean,
        surface: Surface? = currentSurface
    ) {
        currentContext = context.applicationContext
        _isMuted.value = muted

        // If this video is already current and prepared
        if (currentVideo?.id == video.id && activePlayer != null && isPrepared) {
            surface?.let { setSurface(it) }
            applyMuteVolume()
            if (!_isUserPaused.value && isFeedVisible) {
                resume()
            }
            return
        }

        // New video request
        currentVideo = video
        _currentPlayingVideoId.value = video.id
        _isUserPaused.value = false
        _hasError.value = false
        _errorMessage.value = null
        _playbackProgress.value = 0f
        _currentPositionMs.value = 0L
        _durationMs.value = 0L
        isPrepared = false
        _isBuffering.value = true

        surface?.let { currentSurface = it }

        // Check if preloaded player matches this video
        if (preloadedVideo?.id == video.id && preloadPlayer != null) {
            Log.d(TAG, "Promoting preloaded player for video: ${video.id}")
            releaseActivePlayer()
            activePlayer = preloadPlayer
            preloadPlayer = null
            preloadedVideo = null
            isPrepared = true
            _isBuffering.value = false

            setupPlayerListeners(activePlayer!!, video)
            try {
                currentSurface?.let { activePlayer?.setSurface(it) }
                applyMuteVolume()
                if (video.trimStartMs > 0) {
                    activePlayer?.seekTo(video.trimStartMs.toInt())
                }
                if (isFeedVisible && !_isUserPaused.value) {
                    activePlayer?.start()
                    _isPlaying.value = true
                    startProgressTracking()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error starting promoted preloaded player: ${e.message}")
                handlePlaybackFailure("Failed to play preloaded video")
            }
            return
        }

        // Otherwise create new active player
        releaseActivePlayer()

        if (video.videoUrl.isBlank()) {
            handlePlaybackFailure("Video URL is empty")
            return
        }

        val player = createConfiguredPlayer()
        activePlayer = player

        try {
            currentSurface?.let { player.setSurface(it) }
            applyDataSource(context, player, video, isFallback = false)
            setupPlayerListeners(player, video)
            player.prepareAsync()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize active player for ${video.id}: ${e.message}")
            if (!triedFallbackForVideoId.contains(video.id)) {
                triedFallbackForVideoId.add(video.id)
                tryFallbackToLocalVideo(context, video)
            } else {
                handlePlaybackFailure("Unable to load video stream")
            }
        }
    }

    private val triedFallbackForVideoId = mutableSetOf<String>()

    private fun applyDataSource(
        context: Context,
        player: MediaPlayer,
        video: Video,
        isFallback: Boolean
    ) {
        if (isFallback) {
            val afd = try {
                context.resources.openRawResourceFd(com.example.R.raw.sample_video)
            } catch (e: Exception) {
                null
            }
            if (afd != null) {
                player.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                return
            }
        }

        val url = video.videoUrl
        if (url.startsWith("android.resource://") || url.startsWith("content://") || url.startsWith("file://")) {
            player.setDataSource(context.applicationContext, Uri.parse(url))
        } else if (url.startsWith("http://") || url.startsWith("https://")) {
            val headers = mapOf("User-Agent" to "PlayNest/1.0 (Android; Mobile)")
            player.setDataSource(context.applicationContext, Uri.parse(url), headers)
        } else {
            val afd = try {
                context.resources.openRawResourceFd(com.example.R.raw.sample_video)
            } catch (e: Exception) {
                null
            }
            if (afd != null) {
                player.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
            } else {
                player.setDataSource(context.applicationContext, Uri.parse(url))
            }
        }
    }

    private fun tryFallbackToLocalVideo(context: Context, video: Video) {
        releaseActivePlayer()
        try {
            val player = createConfiguredPlayer()
            activePlayer = player
            currentSurface?.let { player.setSurface(it) }
            applyDataSource(context, player, video, isFallback = true)
            setupPlayerListeners(player, video)
            player.prepareAsync()
        } catch (e: Exception) {
            Log.e(TAG, "Local fallback failed for ${video.id}: ${e.message}")
            handlePlaybackFailure("Video playback unavailable")
        }
    }

    private fun setupPlayerListeners(player: MediaPlayer, video: Video) {
        player.setOnPreparedListener { mp ->
            if (activePlayer !== mp || currentVideo?.id != video.id) {
                return@setOnPreparedListener
            }
            isPrepared = true
            _isBuffering.value = false
            _hasError.value = false
            try {
                _durationMs.value = mp.duration.toLong().coerceAtLeast(0L)
            } catch (_: Exception) {}

            applyMuteVolume()

            if (video.trimStartMs > 0) {
                try {
                    mp.seekTo(video.trimStartMs.toInt())
                } catch (_: Exception) {}
            }

            if (isFeedVisible && !_isUserPaused.value) {
                try {
                    mp.start()
                    _isPlaying.value = true
                    startProgressTracking()
                } catch (e: Exception) {
                    Log.e(TAG, "Error on player start: ${e.message}")
                }
            }
        }

        player.setOnInfoListener { _, what, _ ->
            when (what) {
                MediaPlayer.MEDIA_INFO_BUFFERING_START -> _isBuffering.value = true
                MediaPlayer.MEDIA_INFO_BUFFERING_END,
                MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START -> _isBuffering.value = false
            }
            true
        }

        player.setOnCompletionListener { mp ->
            if (!isPrepared) return@setOnCompletionListener
            if (video.trimEndMs > 0 && video.trimEndMs > video.trimStartMs) {
                try {
                    mp.seekTo(video.trimStartMs.toInt())
                    mp.start()
                } catch (_: Exception) {}
            } else {
                // Loop seamlessly
                try {
                    mp.seekTo(0)
                    mp.start()
                } catch (_: Exception) {}
            }
        }

        player.setOnErrorListener { mp, what, extra ->
            Log.w(TAG, "MediaPlayer error on video ${video.id}: what=$what extra=$extra")
            if (activePlayer === mp) {
                val ctx = currentContext
                if (ctx != null && !triedFallbackForVideoId.contains(video.id)) {
                    triedFallbackForVideoId.add(video.id)
                    Log.i(TAG, "Attempting local video fallback for video ${video.id}")
                    scope.launch(Dispatchers.Main) {
                        tryFallbackToLocalVideo(ctx, video)
                    }
                    return@setOnErrorListener true
                }
                handlePlaybackFailure("Video playback unavailable ($what)")
            }
            true
        }
    }

    private fun createConfiguredPlayer(): MediaPlayer {
        return MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            isLooping = true
        }
    }

    private fun handlePlaybackFailure(msg: String) {
        _isBuffering.value = false
        _isPlaying.value = false
        _hasError.value = true
        _errorMessage.value = msg
        stopProgressTracking()
    }

    /**
     * Retry playing the current video if it previously failed.
     */
    fun retryCurrentVideo(context: Context) {
        val vid = currentVideo ?: return
        triedFallbackForVideoId.remove(vid.id)
        _hasError.value = false
        _errorMessage.value = null
        playVideo(context, vid, _isMuted.value, currentSurface)
    }

    /**
     * Pause playback.
     */
    fun pause() {
        try {
            if (isPrepared && activePlayer?.isPlaying == true) {
                activePlayer?.pause()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error pausing player: ${e.message}")
        }
        _isPlaying.value = false
        stopProgressTracking()
    }

    /**
     * Resume playback if prepared and not user-paused.
     */
    fun resume() {
        if (!isPrepared || _isUserPaused.value || !isFeedVisible) return
        try {
            activePlayer?.start()
            _isPlaying.value = true
            startProgressTracking()
        } catch (e: Exception) {
            Log.w(TAG, "Error resuming player: ${e.message}")
        }
    }

    /**
     * User tap on video to toggle play/pause.
     * Returns true if now paused, false if now playing.
     */
    fun toggleUserPlayPause(): Boolean {
        if (_isUserPaused.value) {
            // Unpause
            _isUserPaused.value = false
            resume()
            return false
        } else {
            // Pause
            _isUserPaused.value = true
            pause()
            return true
        }
    }

    /**
     * Update global mute state.
     */
    fun setMuted(muted: Boolean) {
        _isMuted.value = muted
        applyMuteVolume()
    }

    private fun applyMuteVolume() {
        val vol = if (_isMuted.value) 0f else 1f
        try {
            activePlayer?.setVolume(vol, vol)
        } catch (e: Exception) {
            Log.w(TAG, "Error setting volume: ${e.message}")
        }
    }

    /**
     * Preload adjacent video to ensure instantaneous swipe transitions.
     */
    fun preloadNextVideo(context: Context, nextVideo: Video?) {
        if (nextVideo == null || nextVideo.videoUrl.isBlank()) {
            releasePreloadPlayer()
            return
        }

        if (preloadedVideo?.id == nextVideo.id && preloadPlayer != null) {
            // Already preloaded
            return
        }

        releasePreloadPlayer()
        preloadedVideo = nextVideo

        scope.launch(Dispatchers.IO) {
            try {
                val player = createConfiguredPlayer().apply {
                    setVolume(0f, 0f)
                    applyDataSource(context, this, nextVideo, isFallback = false)
                    setOnPreparedListener {
                        Log.d(TAG, "Preloaded video ready: ${nextVideo.id}")
                    }
                    setOnErrorListener { _, _, _ ->
                        scope.launch(Dispatchers.Main) {
                            releasePreloadPlayer()
                        }
                        true
                    }
                    prepareAsync()
                }
                preloadPlayer = player
            } catch (e: Exception) {
                Log.w(TAG, "Failed to preload video ${nextVideo.id}: ${e.message}")
                scope.launch(Dispatchers.Main) {
                    releasePreloadPlayer()
                }
            }
        }
    }

    /**
     * Continuous progress tracking loop.
     */
    private fun startProgressTracking() {
        stopProgressTracking()
        progressJob = scope.launch {
            while (isActive && _isPlaying.value) {
                try {
                    activePlayer?.let { player ->
                        if (isPrepared && player.isPlaying) {
                            val cur = player.currentPosition.toLong()
                            val dur = player.duration.toLong().coerceAtLeast(1L)
                            _currentPositionMs.value = cur
                            _durationMs.value = dur

                            // Handle custom trim range if set
                            val vid = currentVideo
                            if (vid != null && vid.trimEndMs > 0 && vid.trimEndMs > vid.trimStartMs) {
                                if (cur >= vid.trimEndMs) {
                                    player.seekTo(vid.trimStartMs.toInt())
                                }
                                val trimDuration = (vid.trimEndMs - vid.trimStartMs).coerceAtLeast(1L)
                                val trimCurrent = (cur - vid.trimStartMs).coerceIn(0L, trimDuration)
                                _playbackProgress.value = (trimCurrent.toFloat() / trimDuration.toFloat()).coerceIn(0f, 1f)
                            } else {
                                _playbackProgress.value = (cur.toFloat() / dur.toFloat()).coerceIn(0f, 1f)
                            }
                        }
                    }
                } catch (_: Exception) {}
                delay(80)
            }
        }
    }

    private fun stopProgressTracking() {
        progressJob?.cancel()
        progressJob = null
    }

    /**
     * App background event observer handler.
     */
    fun onAppBackgrounded() {
        wasPlayingBeforeBackground = _isPlaying.value
        pause()
    }

    /**
     * App foreground event observer handler.
     */
    fun onAppForegrounded() {
        if (wasPlayingBeforeBackground && !_isUserPaused.value && isFeedVisible) {
            resume()
        }
        wasPlayingBeforeBackground = false
    }

    /**
     * Tab or modal navigation visibility handler.
     */
    fun onFeedVisibilityChanged(isVisible: Boolean) {
        isFeedVisible = isVisible
        if (!isVisible) {
            pause()
        } else {
            if (!_isUserPaused.value && isPrepared) {
                resume()
            }
        }
    }

    private fun releaseActivePlayer() {
        stopProgressTracking()
        val player = activePlayer
        activePlayer = null
        isPrepared = false
        _isPlaying.value = false
        _isBuffering.value = false
        if (player != null) {
            try {
                player.setOnPreparedListener(null)
                player.setOnCompletionListener(null)
                player.setOnErrorListener(null)
                player.setOnInfoListener(null)
            } catch (_: Exception) {}
            try {
                player.reset()
            } catch (_: Exception) {}
            try {
                player.release()
            } catch (_: Exception) {}
        }
    }

    private fun releasePreloadPlayer() {
        val player = preloadPlayer
        preloadPlayer = null
        preloadedVideo = null
        if (player != null) {
            try {
                player.setOnPreparedListener(null)
                player.setOnCompletionListener(null)
                player.setOnErrorListener(null)
                player.setOnInfoListener(null)
            } catch (_: Exception) {}
            try {
                player.reset()
            } catch (_: Exception) {}
            try {
                player.release()
            } catch (_: Exception) {}
        }
    }

    /**
     * Release all resources.
     */
    fun releaseAll() {
        releaseActivePlayer()
        releasePreloadPlayer()
        currentSurface = null
        currentContext = null
        currentVideo = null
        _currentPlayingVideoId.value = null
        _playbackProgress.value = 0f
    }
}
