package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.Locale

object VideoMediaHelper {
    private const val TAG = "VideoMediaHelper"

    /**
     * Retrieves the duration of a video in milliseconds using MediaMetadataRetriever.
     * Returns 0 if unable to retrieve.
     */
    fun getVideoDurationMs(context: Context, videoUri: Uri): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, videoUri)
            val time = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            time?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            Log.w(TAG, "Failed to extract video duration: ${e.message}")
            0L
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }
    }

    /**
     * Extracts a frame bitmap from the video at the given timestamp (in milliseconds).
     */
    fun extractVideoFrame(context: Context, videoUri: Uri, timeMs: Long = 1000L): Bitmap? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, videoUri)
            val timeUs = (timeMs * 1000L).coerceAtLeast(0L)
            retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: retriever.frameAtTime
        } catch (e: Exception) {
            Log.w(TAG, "Failed to extract video frame: ${e.message}")
            null
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }
    }

    /**
     * Saves a Bitmap to the app's internal cache/files directory as a JPEG file
     * and returns the file Uri string.
     */
    fun saveBitmapToFile(context: Context, bitmap: Bitmap, namePrefix: String = "thumb"): String {
        return try {
            val dir = File(context.filesDir, "thumbnails").apply { mkdirs() }
            val file = File(dir, "${namePrefix}_${System.currentTimeMillis()}.jpg")
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out)
            }
            Uri.fromFile(file).toString()
        } catch (e: Exception) {
            Log.w(TAG, "Failed to save bitmap: ${e.message}")
            ""
        }
    }

    /**
     * Copies a content/file URI to the app's internal files storage so it is
     * permanently accessible without expiring picker grants.
     */
    fun copyUriToAppStorage(context: Context, sourceUri: Uri, prefix: String = "video"): String {
        return try {
            if (sourceUri.scheme == "file") {
                return sourceUri.toString()
            }
            val dir = File(context.filesDir, "videos").apply { mkdirs() }
            val file = File(dir, "${prefix}_${System.currentTimeMillis()}.mp4")
            val inputStream: InputStream? = context.contentResolver.openInputStream(sourceUri)
            if (inputStream != null) {
                FileOutputStream(file).use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
                Uri.fromFile(file).toString()
            } else {
                sourceUri.toString()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to copy video to internal storage: ${e.message}")
            sourceUri.toString()
        }
    }

    /**
     * Formats milliseconds into mm:ss format.
     */
    fun formatDurationMs(millis: Long): String {
        val totalSeconds = (millis / 1000).coerceAtLeast(0)
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return String.format(Locale.getDefault(), "%d:%02d", minutes, seconds)
    }
}
