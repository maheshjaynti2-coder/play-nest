package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.User
import com.example.data.model.Video

@Entity(tableName = "videos")
data class VideoEntity(
    @PrimaryKey val id: String,
    val creatorId: String,
    val creatorUsername: String,
    val creatorDisplayName: String,
    val creatorAvatarUrl: String,
    val isCreatorVerified: Boolean,
    val caption: String,
    val hashtagsJoined: String,
    val location: String = "",
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = 0L,
    val musicTitle: String,
    val musicArtist: String,
    val videoUrl: String,
    val thumbnailUrl: String,
    val localThumbnailRes: Int?,
    val likesCount: Long,
    val commentsCount: Long,
    val sharesCount: Long,
    val savesCount: Long,
    val isLiked: Boolean,
    val isSaved: Boolean,
    val isFollowingCreator: Boolean,
    val category: String,
    val viewsCount: Long,
    val createdAt: Long
) {
    fun toVideo(): Video = Video(
        id = id,
        creatorId = creatorId,
        creatorUsername = creatorUsername,
        creatorDisplayName = creatorDisplayName,
        creatorAvatarUrl = creatorAvatarUrl,
        isCreatorVerified = isCreatorVerified,
        caption = caption,
        hashtags = if (hashtagsJoined.isBlank()) emptyList() else hashtagsJoined.split(","),
        location = location,
        trimStartMs = trimStartMs,
        trimEndMs = trimEndMs,
        musicTitle = musicTitle,
        musicArtist = musicArtist,
        videoUrl = videoUrl,
        thumbnailUrl = thumbnailUrl,
        localThumbnailRes = localThumbnailRes,
        likesCount = likesCount,
        commentsCount = commentsCount,
        sharesCount = sharesCount,
        savesCount = savesCount,
        isLiked = isLiked,
        isSaved = isSaved,
        isFollowingCreator = isFollowingCreator,
        category = category,
        viewsCount = viewsCount,
        createdAt = createdAt
    )

    companion object {
        fun fromVideo(v: Video): VideoEntity = VideoEntity(
            id = v.id,
            creatorId = v.creatorId,
            creatorUsername = v.creatorUsername,
            creatorDisplayName = v.creatorDisplayName,
            creatorAvatarUrl = v.creatorAvatarUrl,
            isCreatorVerified = v.isCreatorVerified,
            caption = v.caption,
            hashtagsJoined = v.hashtags.joinToString(","),
            location = v.location,
            trimStartMs = v.trimStartMs,
            trimEndMs = v.trimEndMs,
            musicTitle = v.musicTitle,
            musicArtist = v.musicArtist,
            videoUrl = v.videoUrl,
            thumbnailUrl = v.thumbnailUrl,
            localThumbnailRes = v.localThumbnailRes,
            likesCount = v.likesCount,
            commentsCount = v.commentsCount,
            sharesCount = v.sharesCount,
            savesCount = v.savesCount,
            isLiked = v.isLiked,
            isSaved = v.isSaved,
            isFollowingCreator = v.isFollowingCreator,
            category = v.category,
            viewsCount = v.viewsCount,
            createdAt = v.createdAt
        )
    }
}

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String,
    val username: String,
    val displayName: String,
    val avatarUrl: String,
    val bio: String,
    val isVerified: Boolean,
    val followersCount: Int,
    val followingCount: Int,
    val likesCount: Long,
    val isFollowing: Boolean,
    val isBlocked: Boolean
) {
    fun toUser(): User = User(
        id = id,
        username = username,
        displayName = displayName,
        avatarUrl = avatarUrl,
        bio = bio,
        isVerified = isVerified,
        followersCount = followersCount,
        followingCount = followingCount,
        likesCount = likesCount,
        isFollowing = isFollowing,
        isBlocked = isBlocked
    )

    companion object {
        fun fromUser(u: User): UserEntity = UserEntity(
            id = u.id,
            username = u.username,
            displayName = u.displayName,
            avatarUrl = u.avatarUrl,
            bio = u.bio,
            isVerified = u.isVerified,
            followersCount = u.followersCount,
            followingCount = u.followingCount,
            likesCount = u.likesCount,
            isFollowing = u.isFollowing,
            isBlocked = u.isBlocked
        )
    }
}

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val senderId: String,
    val receiverId: String,
    val message: String,
    val timestamp: String,
    val isSentByMe: Boolean
)
