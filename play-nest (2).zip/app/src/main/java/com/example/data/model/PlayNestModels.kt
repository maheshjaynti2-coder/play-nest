package com.example.data.model

data class User(
    val id: String,
    val username: String,
    val displayName: String,
    val avatarUrl: String,
    val email: String = "",
    val bio: String = "",
    val isVerified: Boolean = false,
    val followersCount: Int = 0,
    val followingCount: Int = 0,
    val likesCount: Long = 0L,
    val createdAt: Long = System.currentTimeMillis(),
    val isFollowing: Boolean = false,
    val isBlocked: Boolean = false
)

data class Video(
    val id: String,
    val creatorId: String,
    val creatorUsername: String,
    val creatorDisplayName: String,
    val creatorAvatarUrl: String,
    val isCreatorVerified: Boolean = false,
    val caption: String,
    val hashtags: List<String> = emptyList(),
    val location: String = "",
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = 0L,
    val musicTitle: String = "Original Audio - Play Nest",
    val musicArtist: String = "Play Nest Originals",
    val videoUrl: String,
    val thumbnailUrl: String = "",
    val localThumbnailRes: Int? = null,
    val likesCount: Long = 0L,
    val commentsCount: Long = 0L,
    val sharesCount: Long = 0L,
    val savesCount: Long = 0L,
    val isLiked: Boolean = false,
    val isSaved: Boolean = false,
    val isFollowingCreator: Boolean = false,
    val category: String = "General",
    val viewsCount: Long = 1200L,
    val createdAt: Long = System.currentTimeMillis()
)

data class Comment(
    val id: String,
    val videoId: String,
    val userId: String,
    val username: String,
    val userAvatarUrl: String,
    val text: String,
    val timestamp: String = "Just now",
    val likesCount: Int = 0,
    val isLiked: Boolean = false,
    val replies: List<CommentReply> = emptyList(),
    val createdAt: Long = System.currentTimeMillis()
)

data class CommentReply(
    val id: String,
    val commentId: String,
    val userId: String,
    val username: String,
    val userAvatarUrl: String,
    val text: String,
    val timestamp: String = "Just now",
    val likesCount: Int = 0,
    val isLiked: Boolean = false
)

enum class NotificationType {
    LIKE, COMMENT, FOLLOW, MENTION, SYSTEM, LIKE_VIDEO, COMMENT_VIDEO, LIKE_COMMENT
}

data class NotificationItem(
    val id: String,
    val type: NotificationType,
    val senderName: String,
    val senderAvatarUrl: String,
    val targetVideoThumb: String? = null,
    val targetVideoRes: Int? = null,
    val message: String,
    val timeAgo: String,
    val isRead: Boolean = false,
    val recipientId: String = "",
    val actorId: String = "",
    val actorUsername: String = "",
    val videoId: String? = null,
    val commentId: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

data class HashtagItem(
    val name: String,
    val videoCount: Long = 0L,
    val viewsCount: Long = 0L,
    val lastUsedAt: Long = System.currentTimeMillis(),
    val isFollowing: Boolean = false
)

data class SearchHistoryItem(
    val id: String,
    val userId: String,
    val query: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class SearchResult(
    val users: List<User> = emptyList(),
    val videos: List<Video> = emptyList(),
    val hashtags: List<HashtagItem> = emptyList()
)

data class SharedVideoPreview(
    val videoId: String = "",
    val thumbnailUrl: String = "",
    val localThumbnailRes: Int? = null,
    val creatorUsername: String = "",
    val caption: String = ""
)

data class ChatMessage(
    val id: String,
    val senderId: String,
    val receiverId: String,
    val message: String,
    val timestamp: String,
    val isSentByMe: Boolean,
    val timestampMs: Long = System.currentTimeMillis(),
    val senderUsername: String = "",
    val senderAvatarUrl: String = "",
    val sharedVideo: SharedVideoPreview? = null,
    val isRead: Boolean = false,
    val status: String = "SENT"
)

data class ChatConversation(
    val id: String,
    val otherUser: User,
    val lastMessage: String,
    val timeAgo: String,
    val unreadCount: Int = 0,
    val lastTimestampMs: Long = System.currentTimeMillis(),
    val isArchived: Boolean = false
)

data class VideoShareRecord(
    val id: String,
    val videoId: String,
    val userId: String,
    val shareType: String,
    val recipientUserId: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

data class SoundTrack(
    val id: String,
    val title: String,
    val artist: String,
    val duration: String,
    val usageCount: String
)

enum class ReportContentType {
    VIDEO, COMMENT, USER, MESSAGE
}

enum class ReportReason(val displayName: String, val description: String) {
    SPAM("Spam", "Harmful commercial spam, scams, or misleading links"),
    HARASSMENT("Harassment or bullying", "Targeted harassment, intimidation, or hateful attacks"),
    HATE_SPEECH("Hate or abusive content", "Attacks based on identity, race, religion, or protected groups"),
    NUDITY("Nudity/sexual content", "Sexually explicit imagery, pornography, or exploitation"),
    VIOLENCE("Violence", "Threats of violence, dangerous acts, or graphic injury"),
    SCAM("Scam/fraud", "Financial fraud, phishing, or impersonation scams"),
    COPYRIGHT("Copyright concern", "Unauthorized use of copyrighted material or music"),
    OTHER("Other", "Any other issue violating Community Guidelines")
}

data class ContentReport(
    val id: String = java.util.UUID.randomUUID().toString(),
    val reporterUserId: String,
    val targetId: String,
    val reportedUserId: String = "",
    val contentType: ReportContentType,
    val reason: String,
    val details: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "PENDING", // PENDING, UNDER_REVIEW, RESOLVED, DISMISSED
    val targetSummary: String = ""
)

enum class PrivacyAudience(val label: String) {
    EVERYONE("Everyone"),
    FOLLOWERS_ONLY("Followers only"),
    NO_ONE("No one")
}

data class UserPrivacySettings(
    val userId: String = "",
    val isPrivateAccount: Boolean = false,
    val allowComments: PrivacyAudience = PrivacyAudience.EVERYONE,
    val allowDirectMessages: PrivacyAudience = PrivacyAudience.EVERYONE,
    val pushNotificationsEnabled: Boolean = true,
    val interactionNotifications: Boolean = true,
    val mentionNotifications: Boolean = true,
    val updatedAt: Long = System.currentTimeMillis()
)

data class BlockedUserRecord(
    val blockerUserId: String,
    val blockedUserId: String,
    val blockedUsername: String,
    val blockedDisplayName: String,
    val blockedAvatarUrl: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

