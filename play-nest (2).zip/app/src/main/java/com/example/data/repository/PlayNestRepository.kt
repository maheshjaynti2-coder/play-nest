package com.example.data.repository

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.Toast
import com.example.R
import com.example.data.local.PlayNestDatabase
import com.example.data.local.VideoEntity
import com.example.data.model.BlockedUserRecord
import com.example.data.model.ChatConversation
import com.example.data.model.ChatMessage
import com.example.data.model.Comment
import com.example.data.model.CommentReply
import com.example.data.model.ContentReport
import com.example.data.model.HashtagItem
import com.example.data.model.NotificationItem
import com.example.data.model.NotificationType
import com.example.data.model.PrivacyAudience
import com.example.data.model.ReportContentType
import com.example.data.model.SearchHistoryItem
import com.example.data.model.SearchResult
import com.example.data.model.SharedVideoPreview
import com.example.data.model.SoundTrack
import com.example.data.model.User
import com.example.data.model.UserPrivacySettings
import com.example.data.model.Video
import com.example.data.model.VideoShareRecord
import com.example.util.VideoMediaHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class PlayNestRepository(
    private val context: Context,
    private val firebaseBackend: FirebasePlayNestBackend = RealFirebasePlayNestBackend(context)
) {
    private val scope = CoroutineScope(Dispatchers.IO)
    private val database = PlayNestDatabase.getDatabase(context)
    private val dao = database.playNestDao()

    // Current logged-in user
    private val _currentUser = MutableStateFlow(
        User(
            id = "user_me",
            username = "alexrivera",
            displayName = "Alex Rivera",
            avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400",
            email = "alex.rivera@playnest.app",
            bio = "Visual artist & motion creator 🎨✨ Exploring vibrant worlds on Play Nest",
            isVerified = true,
            followersCount = 18400,
            followingCount = 342,
            likesCount = 98200L
        )
    )
    val currentUser: StateFlow<User> = _currentUser.asStateFlow()

    // Auth status flow: null means loading/checking, false means logged out, true means logged in
    private val _isAuthenticated = MutableStateFlow<Boolean?>(null)
    val isAuthenticated: StateFlow<Boolean?> = _isAuthenticated.asStateFlow()

    // Video Feed
    private val _videos = MutableStateFlow<List<Video>>(emptyList())
    val videos: StateFlow<List<Video>> = _videos.asStateFlow()

    // Comments map: videoId -> List<Comment>
    private val _comments = MutableStateFlow<Map<String, List<Comment>>>(emptyMap())
    val comments: StateFlow<Map<String, List<Comment>>> = _comments.asStateFlow()

    // Notifications
    private val _notifications = MutableStateFlow<List<NotificationItem>>(emptyList())
    val notifications: StateFlow<List<NotificationItem>> = _notifications.asStateFlow()

    // Real Search & History Flows
    private val _searchResults = MutableStateFlow(SearchResult())
    val searchResults: StateFlow<SearchResult> = _searchResults.asStateFlow()

    private val _searchHistory = MutableStateFlow<List<SearchHistoryItem>>(emptyList())
    val searchHistory: StateFlow<List<SearchHistoryItem>> = _searchHistory.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    private val _searchError = MutableStateFlow<String?>(null)
    val searchError: StateFlow<String?> = _searchError.asStateFlow()

    // Trending Hashtags
    private val _trendingHashtagItems = MutableStateFlow<List<HashtagItem>>(emptyList())
    val trendingHashtagItems: StateFlow<List<HashtagItem>> = _trendingHashtagItems.asStateFlow()

    private val _trendingHashtagsList = MutableStateFlow<List<Pair<String, String>>>(
        listOf(
            "#PlayNestBeat" to "1.4M views",
            "#NeonVibes" to "980K views",
            "#DanceChallenge" to "2.2M views",
            "#CyberCity" to "650K views",
            "#SkateLife" to "820K views",
            "#FoodieTok" to "1.1M views",
            "#GamingHighlights" to "3.4M views",
            "#TravelDiaries" to "740K views"
        )
    )
    val trendingHashtags: StateFlow<List<Pair<String, String>>> = _trendingHashtagsList.asStateFlow()

    // Chat Conversations & Messages
    private val _conversations = MutableStateFlow<List<ChatConversation>>(emptyList())
    val conversations: StateFlow<List<ChatConversation>> = _conversations.asStateFlow()

    private val _chatMessages = MutableStateFlow<Map<String, List<ChatMessage>>>(emptyMap())
    val chatMessages: StateFlow<Map<String, List<ChatMessage>>> = _chatMessages.asStateFlow()

    // Realtime Firestore Subscriptions for DMs and Video Shares
    private var conversationsSubscription: FirestoreSubscription? = null
    private val activeMessageSubscriptions = mutableMapOf<String, FirestoreSubscription>()

    // Discover Creators
    private val _creators = MutableStateFlow<List<User>>(emptyList())
    val creators: StateFlow<List<User>> = _creators.asStateFlow()

    // Safety & Moderation Flows
    private val _blockedUsers = MutableStateFlow<List<BlockedUserRecord>>(emptyList())
    val blockedUsers: StateFlow<List<BlockedUserRecord>> = _blockedUsers.asStateFlow()

    private val _userReports = MutableStateFlow<List<ContentReport>>(emptyList())
    val userReports: StateFlow<List<ContentReport>> = _userReports.asStateFlow()

    private val _privacySettings = MutableStateFlow(UserPrivacySettings())
    val privacySettings: StateFlow<UserPrivacySettings> = _privacySettings.asStateFlow()

    // Sound Tracks
    val soundTracks = listOf(
        SoundTrack("sound_1", "Neon Heartbeat (Club Mix)", "DJ Pulse", "0:45", "148.2K videos"),
        SoundTrack("sound_2", "Cybernetic Horizon", "Vapor Wave", "0:30", "94.6K videos"),
        SoundTrack("sound_3", "Summer Sunset Acoustic", "Maya Vibe", "0:50", "230.1K videos"),
        SoundTrack("sound_4", "Tokyo Night Drive", "Synth Runner", "0:35", "82.4K videos"),
        SoundTrack("sound_5", "Play Nest Anthem 2026", "Original Audio", "1:00", "512.9K videos"),
        SoundTrack("sound_6", "Hyperpop Bounce", "Charly Glitch", "0:25", "41.5K videos")
    )

    init {
        seedInitialData()
        checkAuthState()
    }

    fun checkAuthState() {
        scope.launch {
            try {
                val user = firebaseBackend.getCurrentUser()
                if (user != null) {
                    _currentUser.value = user
                    _isAuthenticated.value = true
                    syncUserSocialData(user.id)
                } else {
                    _isAuthenticated.value = false
                    syncUserSocialData(_currentUser.value.id)
                }
            } catch (e: Exception) {
                _isAuthenticated.value = false
            }
        }
    }

    suspend fun signIn(email: String, pass: String): Result<User> {
        val result = firebaseBackend.signInWithEmail(email, pass)
        if (result.isSuccess) {
            val user = result.getOrNull()!!
            _currentUser.value = user
            _isAuthenticated.value = true
            syncUserSocialData(user.id)
        }
        return result
    }

    suspend fun signUp(email: String, pass: String, username: String, displayName: String): Result<User> {
        val result = firebaseBackend.signUpWithEmail(email, pass, username, displayName)
        if (result.isSuccess) {
            val user = result.getOrNull()!!
            _currentUser.value = user
            _isAuthenticated.value = true
            syncUserSocialData(user.id)
        }
        return result
    }

    suspend fun sendPasswordReset(email: String): Result<Unit> {
        return firebaseBackend.sendPasswordResetEmail(email)
    }

    suspend fun logOut() {
        firebaseBackend.signOut()
        _isAuthenticated.value = false
    }

    private fun seedInitialData() {
        val initialCreators = listOf(
            User(
                id = "user_luna",
                username = "lunavibes",
                displayName = "Luna Star",
                avatarUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400",
                bio = "Futuristic city explorer & digital nomad 🌌",
                isVerified = true,
                followersCount = 89400,
                followingCount = 142,
                likesCount = 345000L
            ),
            User(
                id = "user_kai",
                username = "kaineon",
                displayName = "Kai Neon",
                avatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
                bio = "Street choreography & neon dance battles 🔥⚡",
                isVerified = true,
                followersCount = 120500,
                followingCount = 310,
                likesCount = 890000L
            ),
            User(
                id = "user_maya",
                username = "mayaskate",
                displayName = "Maya Chen",
                avatarUrl = "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400",
                bio = "Chasing coastal sunsets and skate spots 🛹🌴",
                isVerified = false,
                followersCount = 45200,
                followingCount = 190,
                likesCount = 210000L
            ),
            User(
                id = "user_dj",
                username = "djpulse",
                displayName = "DJ Pulse",
                avatarUrl = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400",
                bio = "Electronic producer & sound designer 🎧 Official Play Nest Sound Creator",
                isVerified = true,
                followersCount = 230000,
                followingCount = 85,
                likesCount = 1400000L
            ),
            User(
                id = "user_elena",
                username = "elenaroam",
                displayName = "Elena Woods",
                avatarUrl = "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=400",
                bio = "Travel adventurer | 48 countries and counting ✈️🗺️",
                isVerified = true,
                followersCount = 76300,
                followingCount = 215,
                likesCount = 430000L
            )
        )
        _creators.value = initialCreators

        // Reliable Google test video stream clips with rich fallbacks
        val v1 = Video(
            id = "vid_1",
            creatorId = "user_luna",
            creatorUsername = "lunavibes",
            creatorDisplayName = "Luna Star",
            creatorAvatarUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400",
            isCreatorVerified = true,
            caption = "Neon rain falling across the cyberpunk district 🌧️✨ The reflections on the glass towers are insane!",
            hashtags = listOf("#PlayNestBeat", "#NeonVibes", "#CyberCity", "#Aesthetic"),
            musicTitle = "Cybernetic Horizon (Club Mix)",
            musicArtist = "DJ Pulse",
            videoUrl = "https://raw.githubusercontent.com/intel-iot-devkit/sample-videos/master/one-by-one-person-detection.mp4",
            thumbnailUrl = "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?w=800",
            localThumbnailRes = R.drawable.thumb_neon_city,
            likesCount = 38420L,
            commentsCount = 1240L,
            sharesCount = 5600L,
            savesCount = 9200L,
            isLiked = false,
            isSaved = false,
            category = "Travel",
            viewsCount = 280000L
        )

        val v2 = Video(
            id = "vid_2",
            creatorId = "user_kai",
            creatorUsername = "kaineon",
            creatorDisplayName = "Kai Neon",
            creatorAvatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
            isCreatorVerified = true,
            caption = "New dance combo unlocked! Who's taking on the #DanceChallenge this weekend? Hit the + to join the crew! 🔥⚡",
            hashtags = listOf("#DanceChallenge", "#PlayNestBeat", "#Freestyle", "#UrbanDance"),
            musicTitle = "Neon Heartbeat (Club Mix)",
            musicArtist = "DJ Pulse",
            videoUrl = "https://raw.githubusercontent.com/mediaelement/mediaelement-files/master/big_buck_bunny.mp4",
            thumbnailUrl = "https://images.unsplash.com/photo-1547153760-18fc86324498?w=800",
            localThumbnailRes = R.drawable.thumb_street_dance,
            likesCount = 89200L,
            commentsCount = 3450L,
            sharesCount = 14200L,
            savesCount = 18900L,
            isLiked = true,
            isSaved = true,
            category = "Music",
            viewsCount = 650000L
        )

        val v3 = Video(
            id = "vid_3",
            creatorId = "user_maya",
            creatorUsername = "mayaskate",
            creatorDisplayName = "Maya Chen",
            creatorAvatarUrl = "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400",
            isCreatorVerified = false,
            caption = "Golden hour skate session along the pacific highway 🛹🌅 Never want this feeling to end!",
            hashtags = listOf("#SkateLife", "#GoldenHour", "#SunsetVibes", "#California"),
            musicTitle = "Summer Sunset Acoustic",
            musicArtist = "Maya Vibe",
            videoUrl = "https://raw.githubusercontent.com/mediaelement/mediaelement-files/master/echo-hereweare.mp4",
            thumbnailUrl = "https://images.unsplash.com/photo-1520045892732-304bc3ac1577?w=800",
            localThumbnailRes = R.drawable.thumb_sunset_skate,
            likesCount = 24150L,
            commentsCount = 890L,
            sharesCount = 3100L,
            savesCount = 6400L,
            isLiked = false,
            isSaved = false,
            category = "Sports",
            viewsCount = 195000L
        )

        val v4 = Video(
            id = "vid_4",
            creatorId = "user_dj",
            creatorUsername = "djpulse",
            creatorDisplayName = "DJ Pulse",
            creatorAvatarUrl = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400",
            isCreatorVerified = true,
            caption = "Dropping the live remix synth drop! Turn the bass all the way up 🎧🔊 Let me know which track I should flip next.",
            hashtags = listOf("#PlayNestBeat", "#MusicProducer", "#Synthwave", "#EDM"),
            musicTitle = "Play Nest Anthem 2026",
            musicArtist = "DJ Pulse",
            videoUrl = "https://raw.githubusercontent.com/intel-iot-devkit/sample-videos/master/person-bicycle-car-detection.mp4",
            thumbnailUrl = "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=800",
            localThumbnailRes = R.drawable.thumb_neon_city,
            likesCount = 54900L,
            commentsCount = 2100L,
            sharesCount = 8700L,
            savesCount = 11200L,
            isLiked = false,
            isSaved = false,
            category = "Music",
            viewsCount = 410000L
        )

        val v5 = Video(
            id = "vid_5",
            creatorId = "user_me",
            creatorUsername = "alexrivera",
            creatorDisplayName = "Alex Rivera",
            creatorAvatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400",
            isCreatorVerified = true,
            caption = "My first exclusive short video on Play Nest! Blending 3D motion graphics with glowing neon gradients. ✨🚀",
            hashtags = listOf("#MotionArt", "#PlayNestCreator", "#CreativeCode", "#Design"),
            musicTitle = "Tokyo Night Drive",
            musicArtist = "Synth Runner",
            videoUrl = "https://raw.githubusercontent.com/intel-iot-devkit/sample-videos/master/face-demographics-walking-and-pause.mp4",
            thumbnailUrl = "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800",
            localThumbnailRes = R.drawable.thumb_street_dance,
            likesCount = 15300L,
            commentsCount = 670L,
            sharesCount = 2300L,
            savesCount = 4100L,
            isLiked = true,
            isSaved = false,
            category = "Fashion",
            viewsCount = 120000L
        )

        _videos.value = listOf(v1, v2, v3, v4, v5)

        // Seed Comments
        val c1 = Comment(
            id = "c_1",
            videoId = "vid_1",
            userId = "user_kai",
            username = "kaineon",
            userAvatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
            text = "The color grading in this is unreal! What camera did you use?",
            timestamp = "2h ago",
            likesCount = 42,
            isLiked = false,
            replies = listOf(
                CommentReply(
                    id = "r_1",
                    commentId = "c_1",
                    userId = "user_luna",
                    username = "lunavibes",
                    userAvatarUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400",
                    text = "Sony A7S III with a 35mm f/1.4 prime lens! ✨",
                    timestamp = "1h ago",
                    likesCount = 18,
                    isLiked = true
                )
            )
        )

        val c2 = Comment(
            id = "c_2",
            videoId = "vid_1",
            userId = "user_dj",
            username = "djpulse",
            userAvatarUrl = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400",
            text = "Loving the track choice in the background 🔥 Play Nest vibes all day!",
            timestamp = "3h ago",
            likesCount = 89,
            isLiked = true
        )

        val c3 = Comment(
            id = "c_3",
            videoId = "vid_2",
            userId = "user_maya",
            username = "mayaskate",
            userAvatarUrl = "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400",
            text = "That spin at 0:08 was so clean!! 🔥",
            timestamp = "4h ago",
            likesCount = 115,
            isLiked = false
        )

        _comments.value = mapOf(
            "vid_1" to listOf(c1, c2),
            "vid_2" to listOf(c3),
            "vid_3" to emptyList(),
            "vid_4" to emptyList(),
            "vid_5" to emptyList()
        )

        // Seed Notifications
        _notifications.value = listOf(
            NotificationItem(
                id = "n_1",
                type = NotificationType.LIKE,
                senderName = "Luna Star",
                senderAvatarUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400",
                targetVideoRes = R.drawable.thumb_street_dance,
                message = "liked your video",
                timeAgo = "15m ago"
            ),
            NotificationItem(
                id = "n_2",
                type = NotificationType.COMMENT,
                senderName = "Kai Neon",
                senderAvatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
                targetVideoRes = R.drawable.thumb_street_dance,
                message = "commented: \"Super creative animation!\"",
                timeAgo = "1h ago"
            ),
            NotificationItem(
                id = "n_3",
                type = NotificationType.FOLLOW,
                senderName = "DJ Pulse",
                senderAvatarUrl = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400",
                message = "started following you",
                timeAgo = "3h ago"
            ),
            NotificationItem(
                id = "n_4",
                type = NotificationType.SYSTEM,
                senderName = "Play Nest Team",
                senderAvatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400",
                message = "Welcome to Play Nest! Explore trending sounds and creator challenges.",
                timeAgo = "1d ago"
            )
        )

        // Seed Conversations
        _conversations.value = listOf(
            ChatConversation(
                id = "conv_luna",
                otherUser = initialCreators[0],
                lastMessage = "Let's collaborate on the next cyberpunk edit!",
                timeAgo = "10:45 AM",
                unreadCount = 1
            ),
            ChatConversation(
                id = "conv_kai",
                otherUser = initialCreators[1],
                lastMessage = "Sent you the audio track for the dance loop.",
                timeAgo = "Yesterday",
                unreadCount = 0
            ),
            ChatConversation(
                id = "conv_dj",
                otherUser = initialCreators[3],
                lastMessage = "Thanks for featuring my sound! 🔥",
                timeAgo = "2d ago",
                unreadCount = 0
            )
        )

        _chatMessages.value = mapOf(
            "user_luna" to listOf(
                ChatMessage("m_1", "user_luna", "user_me", "Hey Alex! Loved your motion graphics video on Play Nest.", "10:30 AM", false),
                ChatMessage("m_2", "user_me", "user_luna", "Thanks Luna! Your city drone shots were pure magic.", "10:38 AM", true),
                ChatMessage("m_3", "user_luna", "user_me", "Let's collaborate on the next cyberpunk edit!", "10:45 AM", false)
            ),
            "user_kai" to listOf(
                ChatMessage("m_4", "user_kai", "user_me", "Sent you the audio track for the dance loop.", "Yesterday", false)
            ),
            "user_dj" to listOf(
                ChatMessage("m_5", "user_dj", "user_me", "Thanks for featuring my sound! 🔥", "2d ago", false)
            )
        )

        // Seed Room DB asynchronously
        scope.launch {
            try {
                dao.insertVideos(_videos.value.map { VideoEntity.fromVideo(it) })
            } catch (_: Exception) { }
        }
    }

    // Likes - immediate UI update, Room persistence, and real Firestore sync
    fun toggleLike(videoId: String) {
        var targetLikedState = false
        _videos.update { list ->
            list.map { video ->
                if (video.id == videoId) {
                    val newLiked = !video.isLiked
                    targetLikedState = newLiked
                    val newCount = if (newLiked) video.likesCount + 1 else (video.likesCount - 1).coerceAtLeast(0)
                    scope.launch {
                        try {
                            dao.updateLikeStatus(videoId, newLiked, newCount)
                        } catch (_: Exception) { }
                    }
                    video.copy(isLiked = newLiked, likesCount = newCount)
                } else video
            }
        }

        val me = _currentUser.value
        scope.launch {
            try {
                firebaseBackend.updateLikeInFirestore(videoId, me.id, targetLikedState)
                if (targetLikedState) {
                    val targetVideo = _videos.value.find { it.id == videoId }
                    if (targetVideo != null && targetVideo.creatorId != me.id) {
                        val notif = NotificationItem(
                            id = "n_like_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}",
                            type = NotificationType.LIKE_VIDEO,
                            senderName = me.displayName,
                            senderAvatarUrl = me.avatarUrl,
                            targetVideoThumb = targetVideo.thumbnailUrl,
                            targetVideoRes = targetVideo.localThumbnailRes,
                            message = "liked your video",
                            timeAgo = "Just now",
                            recipientId = targetVideo.creatorId,
                            isRead = false,
                            videoId = targetVideo.id
                        )
                        firebaseBackend.createNotificationInFirestore(notif)
                    }
                }
            } catch (e: Exception) {
                Log.w("PlayNestRepository", "updateLikeInFirestore failed: ${e.message}")
            }
        }
    }

    // Bookmark / Save
    fun toggleSave(videoId: String) {
        _videos.update { list ->
            list.map { video ->
                if (video.id == videoId) {
                    val newSaved = !video.isSaved
                    val newCount = if (newSaved) video.savesCount + 1 else (video.savesCount - 1).coerceAtLeast(0)
                    scope.launch {
                        try {
                            dao.updateSaveStatus(videoId, newSaved, newCount)
                        } catch (_: Exception) { }
                    }
                    video.copy(isSaved = newSaved, savesCount = newCount)
                } else video
            }
        }
    }

    // Follow / Unfollow Creator - immediate UI update and real Firestore sync
    fun toggleFollowCreator(creatorId: String) {
        var targetFollowState = false
        _creators.update { list ->
            list.map { user ->
                if (user.id == creatorId) {
                    val newFollowing = !user.isFollowing
                    targetFollowState = newFollowing
                    val newFollowers = if (newFollowing) user.followersCount + 1 else (user.followersCount - 1).coerceAtLeast(0)
                    user.copy(isFollowing = newFollowing, followersCount = newFollowers)
                } else user
            }
        }

        _videos.update { list ->
            list.map { video ->
                if (video.creatorId == creatorId) {
                    video.copy(isFollowingCreator = targetFollowState)
                } else video
            }
        }

        // Update current user following count
        _currentUser.update { me ->
            me.copy(followingCount = if (targetFollowState) me.followingCount + 1 else (me.followingCount - 1).coerceAtLeast(0))
        }

        val me = _currentUser.value
        scope.launch {
            try {
                firebaseBackend.updateFollowInFirestore(creatorId, me.id, targetFollowState)
                if (targetFollowState && creatorId != me.id) {
                    val notif = NotificationItem(
                        id = "n_follow_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}",
                        type = NotificationType.FOLLOW,
                        senderName = me.displayName,
                        senderAvatarUrl = me.avatarUrl,
                        message = "started following you",
                        timeAgo = "Just now",
                        recipientId = creatorId,
                        isRead = false
                    )
                    firebaseBackend.createNotificationInFirestore(notif)
                }
            } catch (e: Exception) {
                Log.w("PlayNestRepository", "updateFollowInFirestore failed: ${e.message}")
            }
        }
    }

    // Add comment - updates UI immediately and saves to Firestore
    fun addComment(videoId: String, text: String) {
        if (text.isBlank()) return
        val me = _currentUser.value
        val newComment = Comment(
            id = "c_${System.currentTimeMillis()}",
            videoId = videoId,
            userId = me.id,
            username = me.username,
            userAvatarUrl = me.avatarUrl,
            text = text.trim(),
            timestamp = "Just now",
            likesCount = 0,
            isLiked = false,
            createdAt = System.currentTimeMillis()
        )

        _comments.update { map ->
            val existing = map[videoId] ?: emptyList()
            map + (videoId to (listOf(newComment) + existing))
        }

        _videos.update { list ->
            list.map { v ->
                if (v.id == videoId) v.copy(commentsCount = v.commentsCount + 1) else v
            }
        }

        scope.launch {
            try {
                firebaseBackend.addCommentToFirestore(newComment)
                val targetVideo = _videos.value.find { it.id == videoId }
                if (targetVideo != null && targetVideo.creatorId != me.id) {
                    val notif = NotificationItem(
                        id = "n_com_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}",
                        type = NotificationType.COMMENT_VIDEO,
                        senderName = me.displayName,
                        senderAvatarUrl = me.avatarUrl,
                        targetVideoThumb = targetVideo.thumbnailUrl,
                        targetVideoRes = targetVideo.localThumbnailRes,
                        message = "commented: \"${text.trim().take(35)}\"",
                        timeAgo = "Just now",
                        recipientId = targetVideo.creatorId,
                        isRead = false,
                        videoId = targetVideo.id
                    )
                    firebaseBackend.createNotificationInFirestore(notif)
                }
            } catch (e: Exception) {
                Log.w("PlayNestRepository", "addCommentToFirestore failed: ${e.message}")
            }
        }
    }

    // Delete comment - owner-only verification and Firestore update
    fun deleteComment(videoId: String, commentId: String) {
        val me = _currentUser.value
        val list = _comments.value[videoId] ?: return
        val comment = list.find { it.id == commentId } ?: return

        if (comment.userId.isNotBlank() && comment.userId != me.id) {
            Log.w("PlayNestRepository", "Security check failed: user ${me.id} is not owner of comment $commentId")
            return
        }

        _comments.update { map ->
            val existing = map[videoId] ?: emptyList()
            map + (videoId to existing.filterNot { it.id == commentId })
        }

        _videos.update { list ->
            list.map { v ->
                if (v.id == videoId) v.copy(commentsCount = (v.commentsCount - 1).coerceAtLeast(0)) else v
            }
        }

        scope.launch {
            try {
                firebaseBackend.deleteCommentFromFirestore(commentId, videoId, me.id)
            } catch (e: Exception) {
                Log.w("PlayNestRepository", "deleteCommentFromFirestore failed: ${e.message}")
            }
        }
    }

    // Load real comments from Firestore for video
    fun loadCommentsForVideo(videoId: String) {
        scope.launch {
            try {
                val result = firebaseBackend.fetchCommentsForVideo(videoId)
                result.getOrNull()?.let { remoteList ->
                    if (remoteList.isNotEmpty()) {
                        _comments.update { map ->
                            val current = map[videoId] ?: emptyList()
                            val combined = (remoteList + current).distinctBy { it.id }.sortedByDescending { it.createdAt }
                            map + (videoId to combined)
                        }
                        _videos.update { list ->
                            list.map { v ->
                                if (v.id == videoId) v.copy(commentsCount = remoteList.size.toLong().coerceAtLeast(v.commentsCount)) else v
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w("PlayNestRepository", "loadCommentsForVideo failed: ${e.message}")
            }
        }
    }

    // Add reply to comment
    fun addReply(videoId: String, commentId: String, text: String) {
        if (text.isBlank()) return
        val me = _currentUser.value
        val newReply = CommentReply(
            id = "r_${System.currentTimeMillis()}",
            commentId = commentId,
            userId = me.id,
            username = me.username,
            userAvatarUrl = me.avatarUrl,
            text = text.trim(),
            timestamp = "Just now",
            likesCount = 0,
            isLiked = false
        )

        _comments.update { map ->
            val list = map[videoId] ?: emptyList()
            val updatedList = list.map { c ->
                if (c.id == commentId) {
                    c.copy(replies = c.replies + newReply)
                } else c
            }
            map + (videoId to updatedList)
        }
    }

    // Like Comment
    fun toggleLikeComment(videoId: String, commentId: String) {
        var targetLiked = false
        _comments.update { map ->
            val list = map[videoId] ?: emptyList()
            val updated = list.map { c ->
                if (c.id == commentId) {
                    val newLiked = !c.isLiked
                    targetLiked = newLiked
                    val newCount = if (newLiked) c.likesCount + 1 else (c.likesCount - 1).coerceAtLeast(0)
                    c.copy(isLiked = newLiked, likesCount = newCount)
                } else c
            }
            map + (videoId to updated)
        }

        val me = _currentUser.value
        scope.launch {
            try {
                firebaseBackend.toggleLikeCommentInFirestore(videoId, commentId, me.id, targetLiked)
                if (targetLiked) {
                    val comment = _comments.value[videoId]?.find { it.id == commentId }
                    if (comment != null && comment.userId.isNotBlank() && comment.userId != me.id) {
                        val targetVideo = _videos.value.find { it.id == videoId }
                        val notif = NotificationItem(
                            id = "n_likecom_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}",
                            type = NotificationType.LIKE_COMMENT,
                            senderName = me.displayName,
                            senderAvatarUrl = me.avatarUrl,
                            targetVideoThumb = targetVideo?.thumbnailUrl,
                            targetVideoRes = targetVideo?.localThumbnailRes,
                            message = "liked your comment: \"${comment.text.take(30)}\"",
                            timeAgo = "Just now",
                            recipientId = comment.userId,
                            isRead = false,
                            videoId = videoId
                        )
                        firebaseBackend.createNotificationInFirestore(notif)
                    }
                }
            } catch (e: Exception) {
                Log.w("PlayNestRepository", "toggleLikeComment failed: ${e.message}")
            }
        }
    }

    // Sync all user social data (likes, follows, profile, videos, notifications, search) from Firestore
    fun syncUserSocialData(userId: String) {
        scope.launch {
            try {
                // 1. Sync user's likes from Firestore
                val likesResult = firebaseBackend.getUserLikedVideoIds(userId)
                val likedIds = likesResult.getOrDefault(emptySet())
                if (likedIds.isNotEmpty()) {
                    _videos.update { list ->
                        list.map { v ->
                            if (likedIds.contains(v.id)) v.copy(isLiked = true) else v
                        }
                    }
                }

                // 2. Sync user's following list from Firestore
                val followingResult = firebaseBackend.getUserFollowingIds(userId)
                val followingIds = followingResult.getOrDefault(emptySet())
                if (followingIds.isNotEmpty()) {
                    _creators.update { list ->
                        list.map { c ->
                            if (followingIds.contains(c.id)) c.copy(isFollowing = true) else c
                        }
                    }
                    _videos.update { list ->
                        list.map { v ->
                            if (followingIds.contains(v.creatorId)) v.copy(isFollowingCreator = true) else v
                        }
                    }
                    _currentUser.update { me ->
                        me.copy(followingCount = followingIds.size.coerceAtLeast(me.followingCount))
                    }
                }

                // 3. Sync real profile stats from Firestore
                val profileResult = firebaseBackend.fetchUserProfileFromFirestore(userId)
                profileResult.getOrNull()?.let { remoteUser ->
                    _currentUser.update { current ->
                        current.copy(
                            followersCount = remoteUser.followersCount,
                            followingCount = remoteUser.followingCount,
                            likesCount = remoteUser.likesCount,
                            bio = remoteUser.bio.ifBlank { current.bio },
                            displayName = remoteUser.displayName.ifBlank { current.displayName }
                        )
                    }
                }

                // 4. Sync videos from Firestore
                val videosResult = firebaseBackend.syncVideosFromFirestore()
                videosResult.getOrNull()?.let { remoteVideos ->
                    if (remoteVideos.isNotEmpty()) {
                        _videos.update { current ->
                            val currentMap = current.associateBy { it.id }.toMutableMap()
                            for (rv in remoteVideos) {
                                currentMap[rv.id] = rv.copy(
                                    isLiked = likedIds.contains(rv.id),
                                    isFollowingCreator = followingIds.contains(rv.creatorId)
                                )
                            }
                            currentMap.values.toList()
                        }
                    }
                }

                // 5. Sync notifications, search history, and trending hashtags
                loadNotifications(userId)
                loadSearchHistory(userId)
                loadTrendingHashtags()

                // 6. Connect real-time Firestore Direct Message conversations
                startListeningToConversations(userId)

                // 7. Sync Safety: blocked users, reports, and privacy settings
                loadBlockedUsers(userId)
                loadReports(userId)
                loadPrivacySettings(userId)
            } catch (e: Exception) {
                Log.w("PlayNestRepository", "Error syncing social data: ${e.message}")
            }
        }
    }

    // Create / Publish Video with real progress reporting and local storage persistence
    suspend fun publishVideoWithProgress(
        caption: String,
        hashtags: List<String>,
        location: String = "",
        videoUri: String,
        thumbnailUri: String,
        musicTitle: String,
        musicArtist: String,
        category: String,
        trimStartMs: Long = 0L,
        trimEndMs: Long = 0L,
        onProgress: (Float, String) -> Unit = { _, _ -> }
    ): Result<Video> {
        return try {
            onProgress(0.10f, "Preparing video file...")
            val me = _currentUser.value

            // Persist video locally in internal storage so the URI won't expire across sessions
            val parsedUri = if (videoUri.isNotBlank()) Uri.parse(videoUri) else null
            val persistedVideoUri = if (parsedUri != null && videoUri.startsWith("content://")) {
                VideoMediaHelper.copyUriToAppStorage(context, parsedUri, "playnest_vid")
            } else {
                videoUri.ifBlank { "https://commondatastream.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4" }
            }

            // Ensure thumbnail exists - generate frame if blank
            onProgress(0.30f, "Generating video cover frame...")
            var finalThumbUri = thumbnailUri
            if (finalThumbUri.isBlank() && persistedVideoUri.isNotBlank() && !persistedVideoUri.startsWith("http")) {
                try {
                    val frameBitmap = VideoMediaHelper.extractVideoFrame(
                        context,
                        Uri.parse(persistedVideoUri),
                        if (trimStartMs > 0) trimStartMs else 1000L
                    )
                    if (frameBitmap != null) {
                        finalThumbUri = VideoMediaHelper.saveBitmapToFile(context, frameBitmap, "cover")
                    }
                } catch (_: Exception) {}
            }

            // Cloud storage upload hook
            onProgress(0.50f, "Uploading to Play Nest Cloud...")
            val uploadResult = firebaseBackend.uploadVideoFile(
                persistedVideoUri,
                "videos/vid_${System.currentTimeMillis()}.mp4"
            ) { progressVal ->
                val scaled = 0.50f + (progressVal * 0.35f)
                val percent = (scaled * 100).toInt()
                onProgress(scaled, "Uploading to Play Nest ($percent%)...")
            }

            onProgress(0.90f, "Finalizing short video...")
            val cloudVideoUrl = uploadResult.getOrDefault(persistedVideoUri)

            val newVideo = Video(
                id = "vid_${System.currentTimeMillis()}",
                creatorId = me.id,
                creatorUsername = me.username,
                creatorDisplayName = me.displayName,
                creatorAvatarUrl = me.avatarUrl,
                isCreatorVerified = me.isVerified,
                caption = caption,
                hashtags = hashtags,
                location = location,
                trimStartMs = trimStartMs,
                trimEndMs = trimEndMs,
                musicTitle = musicTitle.ifBlank { "Original Audio - ${me.displayName}" },
                musicArtist = musicArtist.ifBlank { me.displayName },
                videoUrl = cloudVideoUrl,
                thumbnailUrl = finalThumbUri,
                localThumbnailRes = R.drawable.thumb_street_dance,
                likesCount = 0L,
                commentsCount = 0L,
                sharesCount = 0L,
                savesCount = 0L,
                isLiked = false,
                isSaved = false,
                isFollowingCreator = false,
                category = category,
                viewsCount = 1L,
                createdAt = System.currentTimeMillis()
            )

            // Firestore sync hook
            try {
                firebaseBackend.publishVideoToFirestore(newVideo)
            } catch (_: Exception) {}

            // Prepend to video feed StateFlow so it appears immediately at index 0
            _videos.update { listOf(newVideo) + it }

            // Add notification
            val notif = NotificationItem(
                id = "n_${System.currentTimeMillis()}",
                type = NotificationType.SYSTEM,
                senderName = "Play Nest Studio",
                senderAvatarUrl = me.avatarUrl,
                targetVideoThumb = finalThumbUri.ifBlank { null },
                targetVideoRes = R.drawable.thumb_street_dance,
                message = "Your video has been published to the Play Nest feed!",
                timeAgo = "Just now"
            )
            _notifications.update { listOf(notif) + it }

            // Local database insert
            try {
                dao.insertVideo(VideoEntity.fromVideo(newVideo))
            } catch (_: Exception) {}

            onProgress(1.0f, "Video posted successfully! 🎉")
            Result.success(newVideo)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Synchronous convenience wrapper for backward compatibility
    fun publishVideo(
        caption: String,
        hashtags: List<String>,
        videoUri: String,
        thumbnailUri: String,
        musicTitle: String,
        musicArtist: String,
        category: String,
        location: String = "",
        trimStartMs: Long = 0L,
        trimEndMs: Long = 0L
    ): Video {
        val me = _currentUser.value
        val newVideo = Video(
            id = "vid_${System.currentTimeMillis()}",
            creatorId = me.id,
            creatorUsername = me.username,
            creatorDisplayName = me.displayName,
            creatorAvatarUrl = me.avatarUrl,
            isCreatorVerified = me.isVerified,
            caption = caption,
            hashtags = hashtags,
            location = location,
            trimStartMs = trimStartMs,
            trimEndMs = trimEndMs,
            musicTitle = musicTitle.ifBlank { "Original Audio - ${me.displayName}" },
            musicArtist = musicArtist.ifBlank { me.displayName },
            videoUrl = videoUri.ifBlank { "https://raw.githubusercontent.com/intel-iot-devkit/sample-videos/master/one-by-one-person-detection.mp4" },
            thumbnailUrl = thumbnailUri,
            localThumbnailRes = R.drawable.thumb_street_dance,
            likesCount = 0L,
            commentsCount = 0L,
            sharesCount = 0L,
            savesCount = 0L,
            isLiked = false,
            isSaved = false,
            isFollowingCreator = false,
            category = category,
            viewsCount = 1L,
            createdAt = System.currentTimeMillis()
        )

        _videos.update { listOf(newVideo) + it }

        // Add to notifications
        val notif = NotificationItem(
            id = "n_${System.currentTimeMillis()}",
            type = NotificationType.SYSTEM,
            senderName = "Play Nest Studio",
            senderAvatarUrl = me.avatarUrl,
            targetVideoRes = R.drawable.thumb_street_dance,
            message = "Your video has been published to the Play Nest feed!",
            timeAgo = "Just now"
        )
        _notifications.update { listOf(notif) + it }

        scope.launch {
            try {
                dao.insertVideo(VideoEntity.fromVideo(newVideo))
            } catch (_: Exception) { }
        }

        return newVideo
    }

    // Real-time conversations and messages management
    fun startListeningToConversations(userId: String) {
        conversationsSubscription?.close()
        conversationsSubscription = firebaseBackend.listenToConversationsInFirestore(userId) { list ->
            if (list.isNotEmpty()) {
                _conversations.value = list
            }
        }
    }

    fun subscribeToMessages(conversationId: String, otherUserId: String) {
        activeMessageSubscriptions[conversationId]?.close()
        activeMessageSubscriptions[conversationId] = firebaseBackend.listenToMessagesInFirestore(
            conversationId,
            _currentUser.value.id
        ) { msgs ->
            if (msgs.isNotEmpty()) {
                _chatMessages.update { map ->
                    map + (otherUserId to msgs)
                }
            }
        }
    }

    fun startConversationWithUser(otherUser: User, onReady: (ChatConversation) -> Unit) {
        val me = _currentUser.value
        scope.launch {
            val result = firebaseBackend.getOrCreateConversationInFirestore(me.id, otherUser)
            val conv = result.getOrNull() ?: run {
                val sortedIds = listOf(me.id, otherUser.id).sorted()
                val convId = "dm_${sortedIds.joinToString("_")}"
                ChatConversation(
                    id = convId,
                    otherUser = otherUser,
                    lastMessage = "Say hi to ${otherUser.displayName} 👋",
                    timeAgo = "Just now",
                    unreadCount = 0
                )
            }
            _conversations.update { list ->
                if (list.none { it.id == conv.id }) listOf(conv) + list else list
            }
            subscribeToMessages(conv.id, otherUser.id)
            onReady(conv)
        }
    }

    // Send direct message (supports text and rich video cards)
    fun sendDirectMessage(receiverId: String, text: String, sharedVideo: SharedVideoPreview? = null) {
        if (text.isBlank() && sharedVideo == null) return
        if (isUserBlocked(receiverId)) {
            Toast.makeText(context, "Cannot send message: This user is blocked.", Toast.LENGTH_SHORT).show()
            return
        }
        val me = _currentUser.value
        val timeNow = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
        val msgId = "msg_${UUID.randomUUID()}"
        val msg = ChatMessage(
            id = msgId,
            senderId = me.id,
            receiverId = receiverId,
            message = text.trim(),
            timestamp = timeNow,
            isSentByMe = true,
            timestampMs = System.currentTimeMillis(),
            senderUsername = me.username,
            senderAvatarUrl = me.avatarUrl,
            sharedVideo = sharedVideo,
            status = "SENT"
        )

        // 1. Optimistic UI update
        _chatMessages.update { map ->
            val list = map[receiverId] ?: emptyList()
            map + (receiverId to (list + msg))
        }

        val displayLast = when {
            sharedVideo != null -> "🎬 ${sharedVideo.caption.take(24)}"
            else -> text.trim()
        }

        _conversations.update { list ->
            val idx = list.indexOfFirst { it.otherUser.id == receiverId }
            if (idx >= 0) {
                list.map { conv ->
                    if (conv.otherUser.id == receiverId) {
                        conv.copy(
                            lastMessage = displayLast,
                            timeAgo = "Just now",
                            lastTimestampMs = System.currentTimeMillis()
                        )
                    } else conv
                }
            } else {
                val otherUser = _creators.value.find { it.id == receiverId }
                    ?: User(
                        id = receiverId,
                        username = "creator",
                        displayName = "Play Nest Creator",
                        avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400"
                    )
                val convId = "dm_${listOf(me.id, receiverId).sorted().joinToString("_")}"
                listOf(
                    ChatConversation(
                        id = convId,
                        otherUser = otherUser,
                        lastMessage = displayLast,
                        timeAgo = "Just now",
                        unreadCount = 0,
                        lastTimestampMs = System.currentTimeMillis()
                    )
                ) + list
            }
        }

        // 2. Persist to Firestore
        scope.launch {
            try {
                val otherUser = _creators.value.find { it.id == receiverId }
                    ?: _conversations.value.find { it.otherUser.id == receiverId }?.otherUser
                    ?: User(id = receiverId, username = "creator", displayName = "Play Nest Creator", avatarUrl = "")
                val sortedIds = listOf(me.id, receiverId).sorted()
                val convId = "dm_${sortedIds.joinToString("_")}"
                firebaseBackend.sendMessageToFirestore(convId, msg, otherUser)
            } catch (e: Exception) {
                Log.w("PlayNestRepo", "Failed to send message to Firestore: ${e.message}")
            }
        }
    }

    fun markConversationAsRead(conversationId: String, otherUserId: String) {
        _conversations.update { list ->
            list.map { conv ->
                if (conv.id == conversationId || conv.otherUser.id == otherUserId) {
                    conv.copy(unreadCount = 0)
                } else conv
            }
        }
        scope.launch {
            try {
                firebaseBackend.markConversationAsReadInFirestore(conversationId, _currentUser.value.id)
            } catch (_: Exception) {}
        }
    }

    fun deleteConversation(conversationId: String) {
        _conversations.update { list ->
            list.filter { it.id != conversationId }
        }
        scope.launch {
            try {
                firebaseBackend.deleteConversationInFirestore(conversationId, _currentUser.value.id)
            } catch (_: Exception) {}
        }
    }

    // Update profile
    fun updateProfile(displayName: String, username: String, bio: String, avatarUrl: String) {
        val updated = _currentUser.value.copy(
            displayName = displayName.ifBlank { _currentUser.value.displayName },
            username = username.ifBlank { _currentUser.value.username },
            bio = bio,
            avatarUrl = avatarUrl.ifBlank { _currentUser.value.avatarUrl }
        )
        _currentUser.value = updated
        scope.launch {
            try {
                firebaseBackend.updateUserProfile(updated)
            } catch (_: Exception) {}
        }
    }

    // Share Video via standard Android share sheet with Deep Link and Firestore tracking
    fun shareVideo(video: Video) {
        val shareLink = "https://playnest.app/video/${video.id}"
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(
                Intent.EXTRA_TEXT,
                "Check out this short video by @${video.creatorUsername} on Play Nest: \"${video.caption}\"\n$shareLink\n#PlayNest"
            )
            type = "text/plain"
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        val shareIntent = Intent.createChooser(sendIntent, "Share video via").apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(shareIntent)

        // Track share count in Firestore (prevent duplicate updates)
        scope.launch {
            val result = firebaseBackend.recordVideoShareInFirestore(
                videoId = video.id,
                userId = _currentUser.value.id,
                shareType = "NATIVE_SHARE",
                recipientUserId = null
            )
            val updatedCount = result.getOrNull() ?: (video.sharesCount + 1)
            _videos.update { list ->
                list.map { v ->
                    if (v.id == video.id) v.copy(sharesCount = updatedCount) else v
                }
            }
        }
    }

    // Copy Video Link with Toast and Firestore tracking
    fun copyVideoLink(video: Video) {
        val shareLink = "https://playnest.app/video/${video.id}"
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Play Nest Video", shareLink)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "Link copied to clipboard: $shareLink", Toast.LENGTH_SHORT).show()

        scope.launch {
            val result = firebaseBackend.recordVideoShareInFirestore(
                videoId = video.id,
                userId = _currentUser.value.id,
                shareType = "COPY_LINK",
                recipientUserId = null
            )
            val updatedCount = result.getOrNull() ?: (video.sharesCount + 1)
            _videos.update { list ->
                list.map { v ->
                    if (v.id == video.id) v.copy(sharesCount = updatedCount) else v
                }
            }
        }
    }

    // Share Video directly to another Play Nest user via DM
    fun shareVideoToPlayNestUser(video: Video, recipientUser: User) {
        val preview = SharedVideoPreview(
            videoId = video.id,
            thumbnailUrl = video.videoUrl,
            localThumbnailRes = video.localThumbnailRes,
            creatorUsername = video.creatorUsername,
            caption = video.caption
        )
        sendDirectMessage(
            receiverId = recipientUser.id,
            text = "Shared a video: \"${video.caption}\"",
            sharedVideo = preview
        )
        Toast.makeText(context, "Video shared with @${recipientUser.username}!", Toast.LENGTH_SHORT).show()

        scope.launch {
            val result = firebaseBackend.recordVideoShareInFirestore(
                videoId = video.id,
                userId = _currentUser.value.id,
                shareType = "PLAYNEST_DM",
                recipientUserId = recipientUser.id
            )
            val updatedCount = result.getOrNull() ?: (video.sharesCount + 1)
            _videos.update { list ->
                list.map { v ->
                    if (v.id == video.id) v.copy(sharesCount = updatedCount) else v
                }
            }
        }
    }

    // =========================================================================
    // REAL SAFETY: REPORT & BLOCK SYSTEM & PRIVACY SETTINGS
    // =========================================================================

    // Block User
    fun blockUser(userId: String) {
        val targetUser = _creators.value.find { it.id == userId } ?: User(
            id = userId,
            username = "user_$userId",
            displayName = "Blocked User",
            avatarUrl = ""
        )
        blockUser(targetUser)
    }

    fun blockUser(user: User) {
        val currentUserId = _currentUser.value.id
        scope.launch {
            try {
                firebaseBackend.blockUserInFirestore(currentUserId, user)
                val newRecord = BlockedUserRecord(
                    blockerUserId = currentUserId,
                    blockedUserId = user.id,
                    blockedUsername = user.username,
                    blockedDisplayName = user.displayName,
                    blockedAvatarUrl = user.avatarUrl
                )
                _blockedUsers.update { list ->
                    (listOf(newRecord) + list.filterNot { it.blockedUserId == user.id })
                }
                _creators.update { list ->
                    list.map { if (it.id == user.id) it.copy(isBlocked = true) else it }
                }
                // Filter out their videos from feed
                _videos.update { list ->
                    list.filter { it.creatorId != user.id }
                }
            } catch (e: Exception) {
                Log.e("PlayNestRepository", "Error blocking user: ${e.message}")
            }
        }
    }

    fun unblockUser(blockedUserId: String, onResult: (Boolean) -> Unit = {}) {
        val currentUserId = _currentUser.value.id
        scope.launch {
            try {
                firebaseBackend.unblockUserInFirestore(currentUserId, blockedUserId)
                _blockedUsers.update { list ->
                    list.filterNot { it.blockedUserId == blockedUserId }
                }
                _creators.update { list ->
                    list.map { if (it.id == blockedUserId) it.copy(isBlocked = false) else it }
                }
                // Re-sync videos if needed
                firebaseBackend.syncVideosFromFirestore().getOrNull()?.let { remoteVideos ->
                    val blockedIds = _blockedUsers.value.map { it.blockedUserId }.toSet()
                    _videos.update {
                        remoteVideos.filter { v -> v.creatorId !in blockedIds }
                    }
                }
                onResult(true)
            } catch (e: Exception) {
                Log.e("PlayNestRepository", "Error unblocking user: ${e.message}")
                onResult(false)
            }
        }
    }

    fun isUserBlocked(userId: String): Boolean {
        val currentUserId = _currentUser.value.id
        return _blockedUsers.value.any {
            (it.blockerUserId == currentUserId && it.blockedUserId == userId) ||
            (it.blockerUserId == userId && it.blockedUserId == currentUserId)
        }
    }

    fun loadBlockedUsers(userId: String = _currentUser.value.id) {
        scope.launch {
            try {
                val res = firebaseBackend.fetchBlockedUsersFromFirestore(userId)
                res.getOrNull()?.let { list ->
                    _blockedUsers.value = list
                    val blockedIds = list.map { it.blockedUserId }.toSet()
                    _videos.update { vList ->
                        vList.filter { it.creatorId !in blockedIds }
                    }
                }
            } catch (e: Exception) {
                Log.w("PlayNestRepository", "loadBlockedUsers error: ${e.message}")
            }
        }
    }

    // Report Content
    fun reportContent(contentId: String, reason: String, details: String) {
        submitReport(
            targetId = contentId,
            contentType = ReportContentType.VIDEO,
            reason = reason,
            details = details
        )
    }

    fun submitReport(
        targetId: String,
        contentType: ReportContentType,
        reason: String,
        details: String = "",
        reportedUserId: String = "",
        targetSummary: String = "",
        onResult: (Boolean, String) -> Unit = { _, _ -> }
    ) {
        val reporterId = _currentUser.value.id
        scope.launch {
            try {
                val alreadyReported = firebaseBackend.hasAlreadyReported(reporterId, targetId)
                if (alreadyReported) {
                    onResult(false, "You have already submitted a report for this content. Our team is currently reviewing it.")
                    return@launch
                }

                val report = ContentReport(
                    id = "rep_${UUID.randomUUID()}",
                    reporterUserId = reporterId,
                    targetId = targetId,
                    reportedUserId = reportedUserId,
                    contentType = contentType,
                    reason = reason,
                    details = details,
                    timestamp = System.currentTimeMillis(),
                    status = "PENDING",
                    targetSummary = targetSummary.ifBlank { "${contentType.name.lowercase().replaceFirstChar { it.uppercase() }} $targetId" }
                )

                val res = firebaseBackend.submitReportToFirestore(report)
                if (res.isSuccess) {
                    _userReports.update { listOf(report) + it }
                    val notif = NotificationItem(
                        id = "n_report_${System.currentTimeMillis()}",
                        type = NotificationType.SYSTEM,
                        senderName = "Play Nest Trust & Safety",
                        senderAvatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400",
                        message = "Thank you for reporting. Your report regarding '$reason' was received. Our team is reviewing this content under our community safety guidelines.",
                        timeAgo = "Just now"
                    )
                    _notifications.update { listOf(notif) + it }
                    onResult(true, "Thank you for reporting. Our Trust & Safety team is reviewing this.")
                } else {
                    onResult(false, "Could not submit report. Please try again.")
                }
            } catch (e: Exception) {
                Log.e("PlayNestRepository", "submitReport error: ${e.message}")
                onResult(false, "An error occurred while reporting: ${e.message}")
            }
        }
    }

    fun loadReports(userId: String = _currentUser.value.id) {
        scope.launch {
            try {
                val res = firebaseBackend.fetchReportsByReporter(userId)
                res.getOrNull()?.let { list ->
                    _userReports.value = list
                }
            } catch (e: Exception) {
                Log.w("PlayNestRepository", "loadReports error: ${e.message}")
            }
        }
    }

    // Privacy Settings
    fun loadPrivacySettings(userId: String = _currentUser.value.id) {
        scope.launch {
            try {
                val res = firebaseBackend.fetchPrivacySettings(userId)
                res.getOrNull()?.let { settings ->
                    _privacySettings.value = settings
                }
            } catch (e: Exception) {
                Log.w("PlayNestRepository", "loadPrivacySettings error: ${e.message}")
            }
        }
    }

    fun updatePrivacySettings(settings: UserPrivacySettings, onComplete: (Boolean) -> Unit = {}) {
        _privacySettings.value = settings
        scope.launch {
            try {
                val res = firebaseBackend.savePrivacySettings(settings)
                onComplete(res.isSuccess)
            } catch (e: Exception) {
                Log.e("PlayNestRepository", "updatePrivacySettings error: ${e.message}")
                onComplete(false)
            }
        }
    }

    // Safe Account Deletion
    suspend fun deleteAccount(password: String? = null): Result<Unit> {
        val res = firebaseBackend.deleteAccount(password)
        if (res.isSuccess) {
            _currentUser.value = User(
                id = "user_guest",
                username = "guest",
                displayName = "Guest User",
                avatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400",
                email = "",
                bio = "Welcome to Play Nest"
            )
            _isAuthenticated.value = false
            _blockedUsers.value = emptyList()
            _userReports.value = emptyList()
            _privacySettings.value = UserPrivacySettings()
        }
        return res
    }

    // -------------------------------------------------------------
    // REAL NOTIFICATIONS (FIRESTORE)
    // -------------------------------------------------------------
    fun loadNotifications(userId: String = _currentUser.value.id) {
        scope.launch {
            try {
                val res = firebaseBackend.fetchNotificationsFromFirestore(userId)
                res.getOrNull()?.let { remoteList ->
                    if (remoteList.isNotEmpty()) {
                        _notifications.update { current ->
                            (remoteList + current).distinctBy { it.id }.sortedByDescending { it.id }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w("PlayNestRepository", "loadNotifications error: ${e.message}")
            }
        }
    }

    fun markNotificationAsRead(notificationId: String) {
        val userId = _currentUser.value.id
        _notifications.update { list ->
            list.map { if (it.id == notificationId) it.copy(isRead = true) else it }
        }
        scope.launch {
            try {
                firebaseBackend.markNotificationAsReadInFirestore(notificationId)
            } catch (e: Exception) {
                Log.w("PlayNestRepository", "markNotificationAsRead error: ${e.message}")
            }
        }
    }

    fun markAllNotificationsAsRead(userId: String = _currentUser.value.id) {
        _notifications.update { list ->
            list.map { it.copy(isRead = true) }
        }
        scope.launch {
            try {
                firebaseBackend.markAllNotificationsAsReadInFirestore(userId)
            } catch (e: Exception) {
                Log.w("PlayNestRepository", "markAllNotificationsAsRead error: ${e.message}")
            }
        }
    }

    // -------------------------------------------------------------
    // REAL SEARCH & SEARCH HISTORY (FIRESTORE)
    // -------------------------------------------------------------
    fun performSearch(query: String) {
        val cleanQuery = query.trim()
        if (cleanQuery.isBlank()) {
            _searchResults.value = SearchResult()
            _isSearching.value = false
            _searchError.value = null
            loadSearchHistory()
            return
        }

        scope.launch {
            _isSearching.value = true
            _searchError.value = null
            try {
                val firestoreRes = firebaseBackend.searchInFirestore(cleanQuery).getOrDefault(SearchResult())
                val queryLower = cleanQuery.lowercase(Locale.ROOT).removePrefix("#")

                // Merge matching creators locally
                val localUsers = _creators.value.filter {
                    it.username.contains(queryLower, ignoreCase = true) ||
                    it.displayName.contains(queryLower, ignoreCase = true)
                }
                val blockedIds = _blockedUsers.value.map { it.blockedUserId }.toSet()
                val mergedUsers = (firestoreRes.users + localUsers).distinctBy { it.id }.filter { it.id !in blockedIds }

                // Merge matching videos locally
                val localVideos = _videos.value.filter { v ->
                    v.caption.contains(queryLower, ignoreCase = true) ||
                    v.creatorUsername.contains(queryLower, ignoreCase = true) ||
                    v.creatorDisplayName.contains(queryLower, ignoreCase = true) ||
                    v.hashtags.any { it.contains(queryLower, ignoreCase = true) }
                }
                val mergedVideos = (firestoreRes.videos + localVideos).distinctBy { it.id }.filter { it.creatorId !in blockedIds }

                // Merge matching hashtags locally
                val localTags = _videos.value.flatMap { it.hashtags }
                    .map { it.removePrefix("#").lowercase(Locale.ROOT) }
                    .filter { it.contains(queryLower) }
                    .distinct()
                    .map { tagName ->
                        val count = _videos.value.count { v ->
                            v.hashtags.any { it.removePrefix("#").equals(tagName, ignoreCase = true) }
                        }.toLong()
                        HashtagItem(
                            name = tagName,
                            videoCount = count.coerceAtLeast(1L),
                            viewsCount = count * 125000L + 1500L
                        )
                    }
                val mergedHashtags = (firestoreRes.hashtags + localTags).distinctBy { it.name.lowercase(Locale.ROOT) }

                _searchResults.value = SearchResult(
                    users = mergedUsers,
                    videos = mergedVideos,
                    hashtags = mergedHashtags
                )

                // Save search history
                val historyItem = SearchHistoryItem(
                    id = UUID.randomUUID().toString(),
                    userId = _currentUser.value.id,
                    query = cleanQuery,
                    timestamp = System.currentTimeMillis()
                )
                _searchHistory.update { current ->
                    (listOf(historyItem) + current.filterNot { it.query.equals(cleanQuery, ignoreCase = true) }).take(15)
                }
                try {
                    firebaseBackend.saveSearchHistoryItemInFirestore(historyItem)
                } catch (_: Exception) {}
            } catch (e: Exception) {
                _searchError.value = e.message ?: "Failed to execute search"
            } finally {
                _isSearching.value = false
            }
        }
    }

    fun loadSearchHistory(userId: String = _currentUser.value.id) {
        scope.launch {
            try {
                val res = firebaseBackend.fetchSearchHistoryFromFirestore(userId)
                res.getOrNull()?.let { list ->
                    if (list.isNotEmpty()) {
                        _searchHistory.value = list
                    }
                }
            } catch (e: Exception) {
                Log.w("PlayNestRepository", "loadSearchHistory error: ${e.message}")
            }
        }
    }

    fun removeSearchHistoryItem(id: String) {
        val userId = _currentUser.value.id
        _searchHistory.update { list -> list.filterNot { it.id == id } }
        scope.launch {
            try {
                firebaseBackend.removeSearchHistoryItemFromFirestore(id, userId)
            } catch (_: Exception) {}
        }
    }

    fun clearSearchHistory() {
        val userId = _currentUser.value.id
        _searchHistory.value = emptyList()
        scope.launch {
            try {
                firebaseBackend.clearSearchHistoryInFirestore(userId)
            } catch (_: Exception) {}
        }
    }

    // -------------------------------------------------------------
    // REAL TRENDING HASHTAGS & HASHTAG VIDEOS (FIRESTORE)
    // -------------------------------------------------------------
    fun loadTrendingHashtags() {
        scope.launch {
            try {
                val res = firebaseBackend.fetchTrendingHashtagsFromFirestore(15)
                res.getOrNull()?.let { remoteTags ->
                    if (remoteTags.isNotEmpty()) {
                        _trendingHashtagItems.value = remoteTags
                        _trendingHashtagsList.value = remoteTags.map { item ->
                            "#${item.name}" to "${formatNumber(item.viewsCount)} views"
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w("PlayNestRepository", "loadTrendingHashtags error: ${e.message}")
            }
        }
    }

    suspend fun fetchVideosByHashtag(tag: String): List<Video> {
        val cleanTag = tag.trim().removePrefix("#").lowercase(Locale.ROOT)
        val localMatches = _videos.value.filter { v ->
            v.hashtags.any { it.removePrefix("#").equals(cleanTag, ignoreCase = true) }
        }
        return try {
            val remoteMatches = firebaseBackend.fetchVideosByHashtagFromFirestore(cleanTag).getOrDefault(emptyList())
            (remoteMatches + localMatches).distinctBy { it.id }
        } catch (_: Exception) {
            localMatches
        }
    }

    private fun formatNumber(count: Long): String {
        return when {
            count >= 1_000_000 -> String.format(Locale.US, "%.1fM", count / 1_000_000.0)
            count >= 1_000 -> String.format(Locale.US, "%.1fK", count / 1_000.0)
            else -> count.toString()
        }
    }
}
