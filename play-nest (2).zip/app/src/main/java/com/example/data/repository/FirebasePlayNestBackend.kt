package com.example.data.repository

import com.example.data.model.Comment
import com.example.data.model.User
import com.example.data.model.Video

/**
 * Clean architectural abstraction prepared for Firebase Services.
 * Connects to Firebase Authentication, Cloud Firestore ("users", "videos", "likes", "comments", "follows"),
 * and Firebase Cloud Storage.
 */
interface FirebasePlayNestBackend {
    suspend fun signInWithEmail(email: String, password: String): Result<User>
    suspend fun signUpWithEmail(email: String, password: String, username: String, displayName: String): Result<User>
    suspend fun sendPasswordResetEmail(email: String): Result<Unit>
    suspend fun signOut()
    suspend fun getCurrentUser(): User?
    suspend fun updateUserProfile(user: User): Result<User>
    suspend fun fetchUserProfileFromFirestore(userId: String): Result<User?>

    suspend fun uploadVideoFile(
        videoUriString: String,
        path: String,
        onProgress: (Float) -> Unit = {}
    ): Result<String>
    suspend fun uploadThumbnail(imageUriString: String, path: String): Result<String>

    suspend fun syncVideosFromFirestore(): Result<List<Video>>
    suspend fun publishVideoToFirestore(video: Video): Result<Unit>

    // Real Social Interactions in Firestore
    suspend fun updateLikeInFirestore(videoId: String, userId: String, isLiked: Boolean): Result<Unit>
    suspend fun getUserLikedVideoIds(userId: String): Result<Set<String>>

    suspend fun fetchCommentsForVideo(videoId: String): Result<List<Comment>>
    suspend fun addCommentToFirestore(comment: Comment): Result<Comment>
    suspend fun deleteCommentFromFirestore(commentId: String, videoId: String, userId: String): Result<Unit>
    suspend fun toggleLikeCommentInFirestore(videoId: String, commentId: String, userId: String, isLiked: Boolean): Result<Unit>

    suspend fun updateFollowInFirestore(targetUserId: String, currentUserId: String, isFollowing: Boolean): Result<Unit>
    suspend fun getUserFollowingIds(currentUserId: String): Result<Set<String>>

    // Real Notifications in Firestore ("notifications")
    suspend fun fetchNotificationsFromFirestore(userId: String): Result<List<com.example.data.model.NotificationItem>>
    suspend fun createNotificationInFirestore(notification: com.example.data.model.NotificationItem): Result<Unit>
    suspend fun markNotificationAsReadInFirestore(notificationId: String): Result<Unit>
    suspend fun markAllNotificationsAsReadInFirestore(userId: String): Result<Unit>

    // Real Search & History in Firestore ("users", "videos", "hashtags", "search_history")
    suspend fun searchInFirestore(query: String): Result<com.example.data.model.SearchResult>
    suspend fun fetchSearchHistoryFromFirestore(userId: String): Result<List<com.example.data.model.SearchHistoryItem>>
    suspend fun saveSearchHistoryItemInFirestore(item: com.example.data.model.SearchHistoryItem): Result<Unit>
    suspend fun removeSearchHistoryItemFromFirestore(id: String, userId: String): Result<Unit>
    suspend fun clearSearchHistoryInFirestore(userId: String): Result<Unit>

    // Real Hashtags in Firestore ("hashtags")
    suspend fun fetchTrendingHashtagsFromFirestore(limit: Long = 10): Result<List<com.example.data.model.HashtagItem>>
    suspend fun fetchVideosByHashtagFromFirestore(hashtag: String, limit: Long = 30): Result<List<Video>>
    suspend fun recordHashtagUsageInFirestore(hashtags: List<String>): Result<Unit>

    // Real Video Shares in Firestore ("video_shares")
    suspend fun recordVideoShareInFirestore(
        videoId: String,
        userId: String,
        shareType: String,
        recipientUserId: String? = null
    ): Result<Long>

    // Real One-to-One Messaging in Firestore ("conversations", "messages")
    suspend fun getOrCreateConversationInFirestore(
        currentUserId: String,
        otherUser: User
    ): Result<com.example.data.model.ChatConversation>

    suspend fun fetchConversationsFromFirestore(
        userId: String
    ): Result<List<com.example.data.model.ChatConversation>>

    suspend fun sendMessageToFirestore(
        conversationId: String,
        message: com.example.data.model.ChatMessage,
        otherUser: User
    ): Result<Unit>

    suspend fun markConversationAsReadInFirestore(
        conversationId: String,
        userId: String
    ): Result<Unit>

    suspend fun deleteConversationInFirestore(
        conversationId: String,
        userId: String
    ): Result<Unit>

    fun listenToConversationsInFirestore(
        userId: String,
        onUpdate: (List<com.example.data.model.ChatConversation>) -> Unit
    ): FirestoreSubscription

    fun listenToMessagesInFirestore(
        conversationId: String,
        currentUserId: String,
        onUpdate: (List<com.example.data.model.ChatMessage>) -> Unit
    ): FirestoreSubscription

    // Safety & Reports in Firestore ("reports")
    suspend fun submitReportToFirestore(report: com.example.data.model.ContentReport): Result<Unit>
    suspend fun hasAlreadyReported(reporterUserId: String, targetId: String): Boolean
    suspend fun fetchReportsByReporter(reporterUserId: String): Result<List<com.example.data.model.ContentReport>>

    // Safety & Blocks in Firestore ("blocked_users")
    suspend fun blockUserInFirestore(blockerUserId: String, blockedUser: User): Result<Unit>
    suspend fun unblockUserInFirestore(blockerUserId: String, blockedUserId: String): Result<Unit>
    suspend fun fetchBlockedUsersFromFirestore(blockerUserId: String): Result<List<com.example.data.model.BlockedUserRecord>>
    suspend fun isUserBlocked(blockerUserId: String, targetUserId: String): Boolean

    // Privacy & Safety Settings in Firestore ("user_privacy_settings")
    suspend fun fetchPrivacySettings(userId: String): Result<com.example.data.model.UserPrivacySettings>
    suspend fun savePrivacySettings(settings: com.example.data.model.UserPrivacySettings): Result<Unit>

    // Safe Permanent Account Deletion
    suspend fun deleteAccount(password: String? = null): Result<Unit>
}

fun interface FirestoreSubscription {
    fun close()
}

/**
 * Standard in-memory fallback implementation adhering to all Firebase interaction contracts.
 */
class DefaultFirebasePlayNestBackend : FirebasePlayNestBackend {
    private var simulatedLoggedInUser: User? = null
    private val inMemoryLikes = mutableSetOf<String>() // format: "${videoId}_${userId}"
    private val inMemoryFollows = mutableSetOf<String>() // format: "${followerId}_${followingId}"
    private val inMemoryComments = mutableMapOf<String, MutableList<Comment>>() // videoId -> comments
    private val inMemoryNotifications = mutableListOf<com.example.data.model.NotificationItem>()
    private val inMemorySearchHistory = mutableListOf<com.example.data.model.SearchHistoryItem>()
    private val inMemoryHashtags = mutableMapOf<String, com.example.data.model.HashtagItem>()
    private val inMemoryShares = mutableListOf<com.example.data.model.VideoShareRecord>()
    private val inMemoryConversations = mutableListOf<com.example.data.model.ChatConversation>()
    private val inMemoryMessages = mutableMapOf<String, MutableList<com.example.data.model.ChatMessage>>()

    override suspend fun signInWithEmail(email: String, password: String): Result<User> {
        val user = User(
            id = "user_me",
            username = email.substringBefore("@").lowercase(),
            displayName = email.substringBefore("@").replaceFirstChar { it.uppercase() },
            avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300",
            bio = "Creating magic on Play Nest! ✨",
            isVerified = true,
            followersCount = 1420,
            followingCount = 280,
            likesCount = 24500L
        )
        simulatedLoggedInUser = user
        return Result.success(user)
    }

    override suspend fun signUpWithEmail(
        email: String,
        password: String,
        username: String,
        displayName: String
    ): Result<User> {
        val user = User(
            id = "user_${System.currentTimeMillis()}",
            username = username.lowercase().trim(),
            displayName = displayName.ifBlank { username },
            avatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=300",
            bio = "New creator on Play Nest 🚀",
            isVerified = false,
            followersCount = 0,
            followingCount = 0,
            likesCount = 0L
        )
        simulatedLoggedInUser = user
        return Result.success(user)
    }

    override suspend fun sendPasswordResetEmail(email: String): Result<Unit> = Result.success(Unit)

    override suspend fun signOut() {
        simulatedLoggedInUser = null
    }

    override suspend fun getCurrentUser(): User? = simulatedLoggedInUser

    override suspend fun updateUserProfile(user: User): Result<User> {
        simulatedLoggedInUser = user
        return Result.success(user)
    }

    override suspend fun fetchUserProfileFromFirestore(userId: String): Result<User?> {
        return Result.success(simulatedLoggedInUser?.takeIf { it.id == userId })
    }

    override suspend fun uploadVideoFile(
        videoUriString: String,
        path: String,
        onProgress: (Float) -> Unit
    ): Result<String> {
        for (step in listOf(0.20f, 0.45f, 0.70f, 0.90f, 1.0f)) {
            kotlinx.coroutines.delay(80)
            onProgress(step)
        }
        return Result.success(videoUriString)
    }

    override suspend fun uploadThumbnail(imageUriString: String, path: String): Result<String> {
        return Result.success(imageUriString)
    }

    override suspend fun syncVideosFromFirestore(): Result<List<Video>> = Result.success(emptyList())

    override suspend fun publishVideoToFirestore(video: Video): Result<Unit> = Result.success(Unit)

    override suspend fun updateLikeInFirestore(
        videoId: String,
        userId: String,
        isLiked: Boolean
    ): Result<Unit> {
        val key = "${videoId}_${userId}"
        if (isLiked) inMemoryLikes.add(key) else inMemoryLikes.remove(key)
        return Result.success(Unit)
    }

    override suspend fun getUserLikedVideoIds(userId: String): Result<Set<String>> {
        val prefix = "_${userId}"
        val likedVideoIds = inMemoryLikes
            .filter { it.endsWith(prefix) }
            .map { it.substringBefore(prefix) }
            .toSet()
        return Result.success(likedVideoIds)
    }

    override suspend fun fetchCommentsForVideo(videoId: String): Result<List<Comment>> {
        return Result.success(inMemoryComments[videoId]?.toList() ?: emptyList())
    }

    override suspend fun addCommentToFirestore(comment: Comment): Result<Comment> {
        val list = inMemoryComments.getOrPut(comment.videoId) { mutableListOf() }
        list.add(0, comment)
        return Result.success(comment)
    }

    override suspend fun deleteCommentFromFirestore(
        commentId: String,
        videoId: String,
        userId: String
    ): Result<Unit> {
        val list = inMemoryComments[videoId] ?: return Result.success(Unit)
        val comment = list.find { it.id == commentId }
        if (comment != null) {
            if (comment.userId != userId) {
                return Result.failure(SecurityException("Users can only delete their own comments"))
            }
            list.remove(comment)
        }
        return Result.success(Unit)
    }

    override suspend fun toggleLikeCommentInFirestore(
        videoId: String,
        commentId: String,
        userId: String,
        isLiked: Boolean
    ): Result<Unit> {
        return Result.success(Unit)
    }

    override suspend fun updateFollowInFirestore(
        targetUserId: String,
        currentUserId: String,
        isFollowing: Boolean
    ): Result<Unit> {
        val key = "${currentUserId}_${targetUserId}"
        if (isFollowing) inMemoryFollows.add(key) else inMemoryFollows.remove(key)
        return Result.success(Unit)
    }

    override suspend fun getUserFollowingIds(currentUserId: String): Result<Set<String>> {
        val prefix = "${currentUserId}_"
        val followingIds = inMemoryFollows
            .filter { it.startsWith(prefix) }
            .map { it.substringAfter(prefix) }
            .toSet()
        return Result.success(followingIds)
    }

    override suspend fun fetchNotificationsFromFirestore(userId: String): Result<List<com.example.data.model.NotificationItem>> {
        val list = inMemoryNotifications.filter { it.recipientId == userId || it.recipientId.isBlank() }
            .sortedByDescending { it.timestamp }
        return Result.success(list)
    }

    override suspend fun createNotificationInFirestore(notification: com.example.data.model.NotificationItem): Result<Unit> {
        inMemoryNotifications.removeAll { it.id == notification.id }
        inMemoryNotifications.add(0, notification)
        return Result.success(Unit)
    }

    override suspend fun markNotificationAsReadInFirestore(notificationId: String): Result<Unit> {
        val idx = inMemoryNotifications.indexOfFirst { it.id == notificationId }
        if (idx >= 0) {
            inMemoryNotifications[idx] = inMemoryNotifications[idx].copy(isRead = true)
        }
        return Result.success(Unit)
    }

    override suspend fun markAllNotificationsAsReadInFirestore(userId: String): Result<Unit> {
        for (i in inMemoryNotifications.indices) {
            if (inMemoryNotifications[i].recipientId == userId || inMemoryNotifications[i].recipientId.isBlank()) {
                inMemoryNotifications[i] = inMemoryNotifications[i].copy(isRead = true)
            }
        }
        return Result.success(Unit)
    }

    override suspend fun searchInFirestore(query: String): Result<com.example.data.model.SearchResult> {
        return Result.success(com.example.data.model.SearchResult())
    }

    override suspend fun fetchSearchHistoryFromFirestore(userId: String): Result<List<com.example.data.model.SearchHistoryItem>> {
        return Result.success(inMemorySearchHistory.filter { it.userId == userId }.sortedByDescending { it.timestamp })
    }

    override suspend fun saveSearchHistoryItemInFirestore(item: com.example.data.model.SearchHistoryItem): Result<Unit> {
        inMemorySearchHistory.removeAll { it.userId == item.userId && it.query.equals(item.query, ignoreCase = true) }
        inMemorySearchHistory.add(0, item)
        return Result.success(Unit)
    }

    override suspend fun removeSearchHistoryItemFromFirestore(id: String, userId: String): Result<Unit> {
        inMemorySearchHistory.removeAll { it.id == id && it.userId == userId }
        return Result.success(Unit)
    }

    override suspend fun clearSearchHistoryInFirestore(userId: String): Result<Unit> {
        inMemorySearchHistory.removeAll { it.userId == userId }
        return Result.success(Unit)
    }

    override suspend fun fetchTrendingHashtagsFromFirestore(limit: Long): Result<List<com.example.data.model.HashtagItem>> {
        return Result.success(inMemoryHashtags.values.sortedByDescending { it.videoCount }.take(limit.toInt()))
    }

    override suspend fun fetchVideosByHashtagFromFirestore(hashtag: String, limit: Long): Result<List<Video>> {
        return Result.success(emptyList())
    }

    override suspend fun recordHashtagUsageInFirestore(hashtags: List<String>): Result<Unit> {
        for (tag in hashtags) {
            val normalized = tag.trim().removePrefix("#").lowercase()
            val existing = inMemoryHashtags[normalized]
            val newCount = (existing?.videoCount ?: 0L) + 1L
            inMemoryHashtags[normalized] = com.example.data.model.HashtagItem(
                name = normalized,
                videoCount = newCount,
                viewsCount = (existing?.viewsCount ?: 0L) + 1500L,
                lastUsedAt = System.currentTimeMillis()
            )
        }
        return Result.success(Unit)
    }

    override suspend fun recordVideoShareInFirestore(
        videoId: String,
        userId: String,
        shareType: String,
        recipientUserId: String?
    ): Result<Long> {
        val shareRecord = com.example.data.model.VideoShareRecord(
            id = "share_${System.currentTimeMillis()}",
            videoId = videoId,
            userId = userId,
            shareType = shareType,
            recipientUserId = recipientUserId,
            timestamp = System.currentTimeMillis()
        )
        inMemoryShares.add(shareRecord)
        val currentCount = inMemoryShares.count { it.videoId == videoId }.toLong()
        return Result.success(currentCount)
    }

    override suspend fun getOrCreateConversationInFirestore(
        currentUserId: String,
        otherUser: User
    ): Result<com.example.data.model.ChatConversation> {
        val convId = "dm_${listOf(currentUserId, otherUser.id).sorted().joinToString("_")}"
        val existing = inMemoryConversations.find { it.id == convId }
        if (existing != null) {
            return Result.success(existing.copy(isArchived = false))
        }
        val newConv = com.example.data.model.ChatConversation(
            id = convId,
            otherUser = otherUser,
            lastMessage = "Say hi to ${otherUser.displayName} 👋",
            timeAgo = "Just now",
            unreadCount = 0,
            lastTimestampMs = System.currentTimeMillis()
        )
        inMemoryConversations.add(0, newConv)
        return Result.success(newConv)
    }

    override suspend fun fetchConversationsFromFirestore(
        userId: String
    ): Result<List<com.example.data.model.ChatConversation>> {
        return Result.success(inMemoryConversations.filter { !it.isArchived })
    }

    override suspend fun sendMessageToFirestore(
        conversationId: String,
        message: com.example.data.model.ChatMessage,
        otherUser: User
    ): Result<Unit> {
        val list = inMemoryMessages.getOrPut(conversationId) { mutableListOf() }
        list.add(message)

        val idx = inMemoryConversations.indexOfFirst { it.id == conversationId }
        val displayLastMsg = when {
            message.sharedVideo != null -> "🎬 Video: ${message.sharedVideo.caption.take(24)}"
            else -> message.message
        }
        if (idx >= 0) {
            inMemoryConversations[idx] = inMemoryConversations[idx].copy(
                lastMessage = displayLastMsg,
                timeAgo = "Just now",
                lastTimestampMs = System.currentTimeMillis(),
                isArchived = false
            )
        } else {
            inMemoryConversations.add(
                0,
                com.example.data.model.ChatConversation(
                    id = conversationId,
                    otherUser = otherUser,
                    lastMessage = displayLastMsg,
                    timeAgo = "Just now",
                    unreadCount = 0,
                    lastTimestampMs = System.currentTimeMillis()
                )
            )
        }
        return Result.success(Unit)
    }

    override suspend fun markConversationAsReadInFirestore(
        conversationId: String,
        userId: String
    ): Result<Unit> {
        val idx = inMemoryConversations.indexOfFirst { it.id == conversationId }
        if (idx >= 0) {
            inMemoryConversations[idx] = inMemoryConversations[idx].copy(unreadCount = 0)
        }
        val msgs = inMemoryMessages[conversationId]
        msgs?.forEachIndexed { i, m ->
            if (m.receiverId == userId) {
                msgs[i] = m.copy(isRead = true, status = "READ")
            }
        }
        return Result.success(Unit)
    }

    override suspend fun deleteConversationInFirestore(
        conversationId: String,
        userId: String
    ): Result<Unit> {
        val idx = inMemoryConversations.indexOfFirst { it.id == conversationId }
        if (idx >= 0) {
            inMemoryConversations[idx] = inMemoryConversations[idx].copy(isArchived = true)
        }
        return Result.success(Unit)
    }

    override fun listenToConversationsInFirestore(
        userId: String,
        onUpdate: (List<com.example.data.model.ChatConversation>) -> Unit
    ): FirestoreSubscription {
        onUpdate(inMemoryConversations.filter { !it.isArchived })
        return FirestoreSubscription {}
    }

    override fun listenToMessagesInFirestore(
        conversationId: String,
        currentUserId: String,
        onUpdate: (List<com.example.data.model.ChatMessage>) -> Unit
    ): FirestoreSubscription {
        val msgs = (inMemoryMessages[conversationId] ?: emptyList()).map {
            it.copy(isSentByMe = it.senderId == currentUserId)
        }
        onUpdate(msgs)
        return FirestoreSubscription {}
    }

    private val inMemoryReports = mutableListOf<com.example.data.model.ContentReport>()
    private val inMemoryBlocked = mutableListOf<com.example.data.model.BlockedUserRecord>()
    private val inMemorySettings = mutableMapOf<String, com.example.data.model.UserPrivacySettings>()

    override suspend fun submitReportToFirestore(report: com.example.data.model.ContentReport): Result<Unit> {
        val exists = inMemoryReports.any { it.reporterUserId == report.reporterUserId && it.targetId == report.targetId }
        if (!exists) {
            inMemoryReports.add(0, report)
        }
        return Result.success(Unit)
    }

    override suspend fun hasAlreadyReported(reporterUserId: String, targetId: String): Boolean {
        return inMemoryReports.any { it.reporterUserId == reporterUserId && it.targetId == targetId }
    }

    override suspend fun fetchReportsByReporter(reporterUserId: String): Result<List<com.example.data.model.ContentReport>> {
        val list = inMemoryReports.filter { it.reporterUserId == reporterUserId }
        return Result.success(list)
    }

    override suspend fun blockUserInFirestore(blockerUserId: String, blockedUser: User): Result<Unit> {
        if (inMemoryBlocked.none { it.blockerUserId == blockerUserId && it.blockedUserId == blockedUser.id }) {
            inMemoryBlocked.add(
                com.example.data.model.BlockedUserRecord(
                    blockerUserId = blockerUserId,
                    blockedUserId = blockedUser.id,
                    blockedUsername = blockedUser.username,
                    blockedDisplayName = blockedUser.displayName,
                    blockedAvatarUrl = blockedUser.avatarUrl
                )
            )
        }
        return Result.success(Unit)
    }

    override suspend fun unblockUserInFirestore(blockerUserId: String, blockedUserId: String): Result<Unit> {
        inMemoryBlocked.removeAll { it.blockerUserId == blockerUserId && it.blockedUserId == blockedUserId }
        return Result.success(Unit)
    }

    override suspend fun fetchBlockedUsersFromFirestore(blockerUserId: String): Result<List<com.example.data.model.BlockedUserRecord>> {
        return Result.success(inMemoryBlocked.filter { it.blockerUserId == blockerUserId })
    }

    override suspend fun isUserBlocked(blockerUserId: String, targetUserId: String): Boolean {
        return inMemoryBlocked.any {
            (it.blockerUserId == blockerUserId && it.blockedUserId == targetUserId) ||
            (it.blockerUserId == targetUserId && it.blockedUserId == blockerUserId)
        }
    }

    override suspend fun fetchPrivacySettings(userId: String): Result<com.example.data.model.UserPrivacySettings> {
        val settings = inMemorySettings[userId] ?: com.example.data.model.UserPrivacySettings(userId = userId)
        return Result.success(settings)
    }

    override suspend fun savePrivacySettings(settings: com.example.data.model.UserPrivacySettings): Result<Unit> {
        inMemorySettings[settings.userId] = settings
        return Result.success(Unit)
    }

    override suspend fun deleteAccount(password: String?): Result<Unit> {
        val user = simulatedLoggedInUser ?: return Result.success(Unit)
        inMemorySettings.remove(user.id)
        inMemoryBlocked.removeAll { it.blockerUserId == user.id || it.blockedUserId == user.id }
        inMemoryReports.removeAll { it.reporterUserId == user.id }
        simulatedLoggedInUser = null
        return Result.success(Unit)
    }
}
