package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        VideoEntity::class,
        UserEntity::class,
        ChatMessageEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class PlayNestDatabase : RoomDatabase() {
    abstract fun playNestDao(): PlayNestDao

    companion object {
        @Volatile
        private var INSTANCE: PlayNestDatabase? = null

        fun getDatabase(context: Context): PlayNestDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PlayNestDatabase::class.java,
                    "play_nest_database"
                )
                    .fallbackToDestructiveMigration(dropAllTables = false)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
