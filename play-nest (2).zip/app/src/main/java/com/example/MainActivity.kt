package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.ViewModelProvider
import com.example.ui.PlayNestApp
import com.example.ui.theme.PlayNestTheme
import com.example.ui.viewmodel.PlayNestViewModel
import com.example.ui.viewmodel.PlayNestViewModelFactory

class MainActivity : ComponentActivity() {
    private lateinit var viewModel: PlayNestViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val factory = PlayNestViewModelFactory(applicationContext)
        viewModel = ViewModelProvider(this, factory)[PlayNestViewModel::class.java]

        handleIntentData(intent)

        setContent {
            PlayNestTheme {
                PlayNestApp(viewModel = viewModel)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntentData(intent)
    }

    private fun handleIntentData(intent: Intent?) {
        val data = intent?.data ?: return
        // Matches https://playnest.app/video/{id} or playnest://video/{id}
        val videoId = when {
            data.scheme == "playnest" && data.host == "video" -> {
                data.pathSegments.firstOrNull() ?: data.lastPathSegment
            }
            data.host == "playnest.app" && data.pathSegments.contains("video") -> {
                val idx = data.pathSegments.indexOf("video")
                data.pathSegments.getOrNull(idx + 1)
            }
            else -> null
        }

        if (!videoId.isNullOrBlank()) {
            viewModel.navigateToVideoById(videoId)
        }
    }
}
